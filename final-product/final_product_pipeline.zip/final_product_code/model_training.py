"""
Model Training Module
Handles XGBoost classifier training for nighttime glucose event prediction.

This module provides utilities for:
- Processing night segments with physiological ODE simulations
- Extracting comprehensive features from glucose time-series data
- Selecting most predictive features using Random Forest importance
- Training separate XGBoost classifiers for hypoglycemia and hyperglycemia
- Handling class imbalance with appropriate weighting strategies

The training pipeline:
1. Load patient data from XML files
2. Segment data into individual nights
3. Compute historical ODE prediction residuals
4. Generate hybrid feature vectors (pre-night + physiological simulation)
5. Select top N most important features
6. Train weighted XGBoost classifiers
7. Return trained models with feature selection info
"""

import numpy as np
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
from pathlib import Path

from config import GRID_MIN, XGBOOST_PARAMS
from data_processing import load_xml, extract_events, extract_night_segments, extract_pre_night_data
from ode_models import estimate_parameters_from_data, predict_glucose_trajectory
from feature_engineering import (
    calculate_insulin_on_board, calculate_carbs_on_board, 
    calculate_recent_insulin, create_features, night_level_features,
    create_pre_night_features_with_residuals, compute_residual_history
)


# ================================================================
# NIGHT SEGMENT PROCESSING
# ================================================================

def process_night_segment(night_data, fit_params=True,
                          glucose_events_all=None, meals_all=None, bolus_all=None):
    """
    Process a single night segment to generate features and predictions.
    
    Performs complete processing of a nighttime glucose monitoring period,
    including parameter estimation, glucose trajectory simulation, and feature
    engineering. Prevents data leakage by optionally estimating physiological
    parameters only from historical data before the night begins.
    
    The processing pipeline:
        1. Extract night events and convert to relative time coordinates
        2. Interpolate CGM measurements to regular time grid
        3. Estimate physiological parameters (optionally from historical data)
        4. Simulate glucose trajectory using extended ODE model
        5. Compute IOB, COB, and other derived quantities
        6. Generate comprehensive feature matrix for prediction
        7. Calculate residuals between actual CGM and model predictions
    
    Parameters:
        night_data (dict): Dictionary containing night segment data with keys:
            'start_time' (datetime): Start of night period
            'end_time' (datetime): End of night period
            'glucose' (list of tuples): CGM readings as [(timestamp, value_mg_dL), ...]
            'meals' (list of tuples): Meal events as [(timestamp, carbs_grams), ...]
            'bolus' (list of tuples): Bolus doses as [(timestamp, dose_units), ...]
            'basal' (list of tuples): Basal rates as [(timestamp, rate_units_per_hour), ...]
            'date' (datetime.date): Date of the night
        fit_params (bool, optional): Whether to estimate physiological parameters
            from data. If True and historical data provided, uses only past data
            to prevent leakage. Default: True
        glucose_events_all (list of tuples, optional): All historical CGM data as
            [(timestamp, value), ...] for parameter estimation
        meals_all (list of tuples, optional): All historical meal data as
            [(timestamp, carbs), ...] for parameter estimation
        bolus_all (list of tuples, optional): All historical bolus data as
            [(timestamp, dose), ...] for parameter estimation
        
    Returns:
        dict: Processed night segment with keys:
            't_eval' (array): Time grid (minutes since start)
            't0' (datetime): Night start time
            'G_cgm' (array): Interpolated CGM measurements (mg/dL)
            'G_pred' (array): Simulated glucose trajectory (mg/dL)
            'features' (array): Feature matrix (n_times, 32)
            'residuals' (array): Prediction errors (CGM - predicted)
            'bergman_params' (dict): Estimated physiological parameters
            'meal_params' (None): Placeholder for meal-specific parameters
            'date' (datetime.date): Date of the night
    """
    # Extract night timing
    t0 = night_data['start_time']
    t_end = night_data['end_time']
    duration_min = (t_end - t0).total_seconds() / 60.0

    # Create time grid for features and plots (e.g., every 5 minutes)
    t_eval = np.arange(0, duration_min, GRID_MIN).astype(float)
    # Ensure we include the final time point
    if t_eval[-1] < duration_min:
        t_eval = np.append(t_eval, duration_min)

    # Convert event timestamps to minutes relative to night start (t0)
    # This simplifies calculations for IOB/COB and feature engineering
    meals_min = [((tm - t0).total_seconds() / 60.0, carbs) for tm, carbs in night_data['meals']]
    bolus_min = [((tm - t0).total_seconds() / 60.0, dose) for tm, dose in night_data['bolus']]
    basal_min = [((tm - t0).total_seconds() / 60.0, rate) for tm, rate in night_data['basal']]

    # If no basal rate specified, use default of 1.0 U/hr
    if not basal_min:
        basal_min = [(0.0, 1.0)]

    # Interpolate CGM measurements to regular time grid
    # This provides glucose values at consistent intervals for feature computation
    G0 = night_data['glucose'][0][1]  # Initial glucose for ODE simulation
    t_cgm = np.array([(ts - t0).total_seconds() / 60.0 for ts, _ in night_data['glucose']])
    G_vals = np.array([val for _, val in night_data['glucose']])
    G_cgm = np.interp(t_eval, t_cgm, G_vals)

    # ===== PHYSIOLOGICAL PARAMETER ESTIMATION =====
    if fit_params:
        # If historical data is provided, estimate parameters from past data only
        # This prevents data leakage by not using the current night for parameter estimation
        if glucose_events_all is not None:
            # Use ONLY data from before the night starts
            glucose_hist = [
                {"time": ts, "value": val}
                for ts, val in glucose_events_all
                if ts < t0
            ]
            meals_hist = [
                {"time": ts, "carbs": carbs, "gi": 55.0, "type": "unknown"}
                for ts, carbs in (meals_all or [])
                if ts < t0
            ]
            bolus_hist = [
                {"time": ts, "dose": dose, "type": "rapid"}
                for ts, dose in (bolus_all or [])
                if ts < t0
            ]

            # Estimate patient-specific parameters from historical data
            physio_params = estimate_parameters_from_data(
                glucose_hist, meals_hist, bolus_hist
            )
        else:
            # Fallback: estimate from current night only (causes some data leakage)
            # This is used when we don't have sufficient historical data
            glucose_events_night = [
                {"time": ts, "value": val} for ts, val in night_data['glucose']
            ]
            meals_night = [
                {"time": ts, "carbs": carbs, "gi": 55.0, "type": "unknown"}
                for ts, carbs in night_data['meals']
            ]
            bolus_night = [
                {"time": ts, "dose": dose, "type": "rapid"}
                for ts, dose in night_data['bolus']
            ]

            physio_params = estimate_parameters_from_data(
                glucose_events_night, meals_night, bolus_night
            )
    else:
        # Use fixed default parameters (no patient-specific estimation)
        from config import PHYSIOLOGICAL_DEFAULTS
        physio_params = PHYSIOLOGICAL_DEFAULTS.copy()

    # ===== GLUCOSE TRAJECTORY SIMULATION =====
    # Format meal and bolus events for ODE simulator
    # The simulator expects dictionaries with specific keys
    meals_night = [
        {"time": ts, "carbs": carbs, "gi": 55.0, "type": "unknown"}
        for ts, carbs in night_data['meals']
    ]
    bolus_night = [
        {"time": ts, "dose": dose, "type": "rapid"}
        for ts, dose in night_data['bolus']
    ]

    # Run physiological ODE simulation to predict glucose trajectory
    times_sim, G_sim = predict_glucose_trajectory(
        t0, t_end, G0,
        meals_night, bolus_night,
        physio_params,
        dt_min=1.0  # 1-minute time step for smooth simulation
    )
    
    # Interpolate simulation results to match feature time grid
    t_sim_min = np.array([(ts - t0).total_seconds() / 60.0 for ts in times_sim])
    G_pred = np.interp(t_eval, t_sim_min, G_sim)

    # ===== FEATURE COMPUTATION =====
    # Calculate insulin on board, carbs on board, and recent insulin
    IOB = calculate_insulin_on_board(t_eval, bolus_min, basal_min)
    COB = calculate_carbs_on_board(t_eval, meals_min)
    recent_ins = calculate_recent_insulin(t_eval, bolus_min, basal_min)
    
    # Generate comprehensive feature matrix (32 features at each time point)
    F = create_features(t_eval, G_pred, IOB, COB, recent_ins, t0, meals_min, bolus_min)

    # ===== RESIDUAL COMPUTATION =====
    # Calculate prediction errors: actual CGM - predicted glucose
    # Positive residual = model underestimated (predicted too low)
    # Negative residual = model overestimated (predicted too high)
    residuals = G_cgm - G_pred

    return {
        't_eval': t_eval,
        't0': t0,
        'G_cgm': G_cgm,
        'G_pred': G_pred,
        'features': F,
        'residuals': residuals,
        'bergman_params': physio_params,
        'meal_params': None,  # Placeholder for future meal-specific parameters
        'date': night_data['date']
    }


def get_night_labels(night_segment):
    """
    Extract binary hypoglycemia and hyperglycemia labels from a night segment.
    
    Analyzes all glucose measurements during a night period and determines
    whether any hypoglycemic (< 70 mg/dL) or hyperglycemic (> 180 mg/dL)
    events occurred. Also prints diagnostic information about the night's
    glucose range for monitoring label distribution.
    
    These labels serve as ground truth for training and evaluating the
    predictive models. The binary labels indicate whether ANY event occurred
    during the night, not the frequency or severity.
    
    Clinical thresholds:
        - Hypoglycemia: < 70 mg/dL (dangerously low glucose)
        - Hyperglycemia: > 180 mg/dL (dangerously high glucose)
    
    Parameters:
        night_segment (dict): Dictionary containing night data with keys:
            'glucose' (list of tuples): Glucose measurements as [(timestamp, value), ...]
            'date' (datetime.date): Date of the night
        
    Returns:
        tuple: Two integers (hypo, hyper) where:
            hypo (int): 1 if any glucose < 70 mg/dL occurred, 0 otherwise
            hyper (int): 1 if any glucose > 180 mg/dL occurred, 0 otherwise
    """
    # Extract all glucose values from the night
    G = np.array([val for _, val in night_segment['glucose']])
    
    # Check if any reading crossed clinical thresholds
    hypo = int(np.any(G < 70))    # 1 if any hypo event occurred
    hyper = int(np.any(G > 180))  # 1 if any hyper event occurred

    # Print diagnostic info for monitoring label distribution
    # Useful for detecting data quality issues or imbalanced classes
    print(f"Night {night_segment['date']}: "
          f"Min={np.min(G):.1f}, Max={np.max(G):.1f}, "
          f"hypo={hypo}, hyper={hyper}")
    
    return hypo, hyper


# ================================================================
# FEATURE SELECTION
# ================================================================

def select_top_features(X, y, n_features=50):
    """
    Select most important features using Random Forest feature importance.
    
    Performs feature selection by training a Random Forest classifier and
    ranking features by their importance scores (Gini importance). This reduces
    the feature space to the top N most predictive features, which can:
        - Reduce overfitting by removing noisy features
        - Speed up training and inference
        - Improve model interpretability
        - Potentially improve generalization performance
    
    Uses a quick Random Forest (100 trees) to estimate feature importance.
    The Gini importance measures the mean decrease in impurity when splitting
    on each feature - higher values indicate features that contribute more to
    prediction accuracy.
    
    Parameters:
        X (array): Feature matrix of shape (n_samples, n_features)
        y (array): Target labels of shape (n_samples,)
        n_features (int, optional): Number of top features to select. Default: 50
        
    Returns:
        array: Indices of the top n_features most important features,
            sorted by importance in ascending order. These indices can be used
            to slice the feature matrix: X[:, top_indices]
    """
    print(f"\nFeature Selection: Reducing from {X.shape[1]} to {n_features} features...")
    
    # Train Random Forest for feature importance estimation
    # Using 100 trees provides stable importance estimates without being too slow
    rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    rf.fit(X, y)
    
    # Extract feature importances (Gini importance)
    importances = rf.feature_importances_
    
    # Get indices of top N features (sorted by importance)
    top_indices = np.argsort(importances)[-n_features:]
    
    # Print summary statistics
    print(f"Selected top {n_features} features")
    print(f"   Cumulative importance: {importances[top_indices].sum():.2%}")
    
    return top_indices


# ================================================================
# MODEL TRAINING
# ================================================================

def train_combined_model_with_residuals(training_file, N_features=40):
    """
    Train XGBoost classifiers for nighttime hypoglycemia and hyperglycemia prediction.
    
    Builds a hybrid prediction model that combines pre-night state features with
    physiological simulation features, including novel residual-based features that
    capture ODE model prediction quality. The training process:
        1. Loads patient data and segments into nights
        2. Computes historical residuals for each day by simulating glucose with ODE
        3. Generates comprehensive feature vectors including residual features
        4. Performs feature selection to identify most predictive features
        5. Trains separate XGBoost classifiers for hypo and hyper prediction
        6. Applies class weighting to handle imbalanced datasets
    
    Feature engineering includes:
        - 26 pre-night features (14 physiological + 12 residual-based)
        - 72 night-level physiological simulation features
        - Total: 98 features before selection
    
    The residual features are a novel contribution that capture how well the
    physiological ODE model tracks each patient's glucose historically, providing
    insight into model uncertainty and systematic biases.
    
    Parameters:
        training_file (str or Path): Path to XML file containing training patient data
            with glucose readings, meals, bolus doses, and basal rates
        N_features (int, optional): Number of top features to select for each classifier
            using mutual information. Default: 40
        
    Returns:
        dict or None: Training results dictionary with keys:
            'trained' (dict): Contains trained models and feature selection info:
                'clf_hypo' (XGBClassifier): Trained hypoglycemia classifier
                'clf_hyper' (XGBClassifier): Trained hyperglycemia classifier
                'top_features_hypo' (array or None): Indices of selected features for hypo
                'top_features_hyper' (array or None): Indices of selected features for hyper
            'residual_history' (dict): Mapping from date to residual arrays for historical reference
            Returns None if insufficient nights (<3) or no valid training samples
    """
    # ===== LOAD AND SEGMENT DATA =====
    root = load_xml(training_file)
    glucose_events, meals, bolus, basal = extract_events(root)
    night_segments = extract_night_segments(glucose_events, meals, bolus, basal)

    # Need at least 3 nights for meaningful training
    if len(night_segments) < 3:
        print("Too few nights to train on.")
        return None

    print(f"Training on {len(night_segments)} nights in {Path(training_file).name}")

    # ===== COMPUTE HISTORICAL RESIDUALS =====
    # For each day, simulate glucose with ODE and compute residuals
    # These residuals become features that capture model quality
    print("  Computing historical residuals...")
    residual_history = compute_residual_history(
        glucose_events, meals, bolus, basal, night_segments
    )
    print(f"  Computed residuals for {len(residual_history)} days")

    # ===== FEATURE GENERATION =====
    # Lists to accumulate features and labels
    X = []          # Feature vectors
    y_hypo = []     # Hypoglycemia labels
    y_hyper = []    # Hyperglycemia labels

    for night in night_segments:
        date = night['date']

        # Step 1: Get historical residuals for this date
        hist_residuals = residual_history.get(date, None)

        # Step 2: Extract pre-night data (day before the night)
        glucose_day, meals_day, bolus_day, basal_day = extract_pre_night_data(
            glucose_events, meals, bolus, basal, date
        )
        
        # Step 3: Generate pre-night features WITH residual features
        F_pre = create_pre_night_features_with_residuals(
            glucose_day, meals_day, bolus_day, basal_day,
            historical_residuals=hist_residuals
        )
        
        if F_pre is None:
            continue  # Skip this night if insufficient pre-night data

        # Step 4: Run physiological simulation over the night
        proc = process_night_segment(
            night,
            fit_params=True,  # Estimate patient-specific parameters
            glucose_events_all=glucose_events,
            meals_all=meals,
            bolus_all=bolus
        )
        if proc is None:
            continue  # Skip if simulation failed

        # Step 5: Generate night-level aggregate features from simulation
        # Uses only first 15 minutes to prevent data leakage
        nf = night_level_features(proc['t_eval'], proc['features'], proc['G_pred'], cutoff_min=15)

        # Step 6: Combine pre-night and night simulation features
        F_hybrid = np.concatenate([F_pre, nf])

        # Step 7: Get ground truth labels
        hypo, hyper = get_night_labels(night)

        # Store features and labels
        X.append(F_hybrid)
        y_hypo.append(hypo)
        y_hyper.append(hyper)

    # Convert lists to numpy arrays
    X = np.array(X)
    y_hypo = np.array(y_hypo)
    y_hyper = np.array(y_hyper)

    # ===== FEATURE SELECTION =====
    # Select top N most important features for each classifier
    if X.shape[1] > N_features:
        top_features_hypo = select_top_features(X, y_hypo, n_features=N_features)
        top_features_hyper = select_top_features(X, y_hyper, n_features=N_features)
        
        # Apply feature selection
        X_hypo = X[:, top_features_hypo]
        X_hyper = X[:, top_features_hyper]
    else:
        # Use all features if we have fewer than N_features
        X_hypo = X
        X_hyper = X
        top_features_hypo = None
        top_features_hyper = None

    # ===== DATA DISTRIBUTION CHECK =====
    # Print statistics to monitor class balance
    print(f"\nTRAINING DATA DISTRIBUTION:")
    print(f"   Total nights: {len(X)}")
    print(f"   Hypo labels: {np.sum(y_hypo)} positive / {len(y_hypo)} total = {np.mean(y_hypo)*100:.1f}%")
    print(f"   Hyper labels: {np.sum(y_hyper)} positive / {len(y_hyper)} total = {np.mean(y_hyper)*100:.1f}%")
    
    # Warn if hyperglycemia is suspiciously common (>90% of nights)
    if np.mean(y_hyper) > 0.90:
        print(f"     WARNING: {np.mean(y_hyper)*100:.1f}% of nights labeled as hyper!")
        print(f"     This is abnormally high - check label generation logic!")

    # ===== CLASS IMBALANCE HANDLING =====
    # Calculate class weights for hypoglycemia classifier
    # scale_pos_weight = (# negative examples) / (# positive examples)
    # This helps XGBoost handle imbalanced datasets
    n_pos_hypo = np.sum(y_hypo == 1)
    n_neg_hypo = np.sum(y_hypo == 0)
    if n_pos_hypo > 0:
        scale_pos_weight_hypo = n_neg_hypo / n_pos_hypo
    else:
        scale_pos_weight_hypo = 1.0

    print(f"HYPO: {n_pos_hypo} pos, {n_neg_hypo} neg, scale_pos_weight={scale_pos_weight_hypo:.2f}")
    print(f"Training samples (nights): {len(X)}")
    
    # Check if we have any training samples
    if len(X) == 0:
        return None

    # ===== CLASSIFIER TRAINING =====
    # Initialize XGBoost classifiers with parameters from config
    # Hypoglycemia classifier uses class weighting to handle imbalance
    clf_hypo = xgb.XGBClassifier(
        **XGBOOST_PARAMS,
        scale_pos_weight=scale_pos_weight_hypo  # Weight positive class higher
    )
    
    # Hyperglycemia classifier uses standard parameters (usually more balanced)
    clf_hyper = xgb.XGBClassifier(**XGBOOST_PARAMS)

    # Train both classifiers
    clf_hypo.fit(X_hypo, y_hypo)
    clf_hyper.fit(X_hyper, y_hyper)

    # ===== RETURN RESULTS =====
    # Package trained models and metadata
    return {
        'trained': {
            "clf_hypo": clf_hypo,
            "clf_hyper": clf_hyper,
            "top_features_hypo": top_features_hypo,
            "top_features_hyper": top_features_hyper
        },
        'residual_history': residual_history  # Pass this to test set for consistency
    }