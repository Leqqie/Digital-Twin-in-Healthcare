"""
Data Processing Module
Handles XML loading, event extraction, and night segmentation.

This module provides utilities for:
- Loading patient diabetes data from XML files
- Extracting glucose, meal, insulin, and basal rate events
- Segmenting data into nighttime periods for analysis
- Preparing data for model training and prediction
"""

import xml.etree.ElementTree as ET
from datetime import datetime, timedelta


def load_xml(file_path):
    """
    Load and parse an XML file containing diabetes management data.
    
    Parameters:
        file_path (str or Path): Path to the XML file to be loaded
        
    Returns:
        xml.etree.ElementTree.Element: Root element of the parsed XML tree
    """
    tree = ET.parse(file_path)
    return tree.getroot()


def extract_events(root):
    """
    Extract all diabetes-related events from a parsed XML structure.
    
    Parses the XML tree to extract continuous glucose monitoring (CGM) readings,
    meal events with carbohydrate content, insulin bolus doses, and basal insulin
    rates. All timestamps are converted to datetime objects for time-series analysis.
    
    Parameters:
        root (xml.etree.ElementTree.Element): Root element of the parsed XML tree
        
    Returns:
        tuple: Four-element tuple containing:
            - glucose_events (list of tuples): List of (timestamp, glucose_value) pairs,
              sorted chronologically. Glucose values in mg/dL.
            - meals (list of tuples): List of (timestamp, carbs) pairs. Carbs in grams.
            - bolus (list of tuples): List of (timestamp, dose) pairs. Dose in units.
            - basal (list of tuples): List of (timestamp, rate) pairs. Rate in units/hour.
    """
    # Extract glucose readings from CGM
    glucose_events = []
    for e in root.findall("glucose_level/event"):
        ts = datetime.strptime(e.attrib["ts"], "%d-%m-%Y %H:%M:%S")
        glucose_events.append((ts, float(e.attrib["value"])))
    glucose_events.sort()  # Ensure chronological order for time-series analysis

    # Extract meal events with carbohydrate content
    meals = []
    for e in root.findall("meal/event"):
        ts = datetime.strptime(e.attrib["ts"], "%d-%m-%Y %H:%M:%S")
        carbs = float(e.attrib.get("carbs", 0.0))  # Default to 0 if missing
        meals.append((ts, carbs))

    # Extract insulin bolus doses
    bolus = []
    for e in root.findall("bolus/event"):
        ts = datetime.strptime(e.attrib["ts_begin"], "%d-%m-%Y %H:%M:%S")
        dose = float(e.attrib.get("dose", 0.0))  # Default to 0 if missing
        bolus.append((ts, dose))

    # Extract basal insulin rates (background insulin infusion)
    basal = []
    for e in root.findall("basal/event"):
        ts = datetime.strptime(e.attrib["ts"], "%d-%m-%Y %H:%M:%S")
        basal.append((ts, float(e.attrib.get("value", 0.0))))

    return glucose_events, meals, bolus, basal


def extract_night_segments(glucose_events, meals, bolus, basal,
                           night_start_hour=0,
                           night_end_hour=8):
    """
    Segment continuous diabetes data into individual nighttime periods for analysis.
    
    Identifies and extracts all complete nighttime periods (default: 00:00-08:00) from
    the full dataset. Each night is labeled by its calendar date and includes all
    glucose readings and treatment events that occurred during that period. Only nights
    with sufficient CGM data (>10 readings) are retained.
    
    Night labeling convention: A night is labeled by the date it starts. For example,
    the night of 2025-01-14 runs from 2025-01-14 00:00 to 2025-01-14 08:00.
    
    Parameters:
        glucose_events (list of tuples): CGM readings as (timestamp, value) pairs
        meals (list of tuples): Meal events as (timestamp, carbs) pairs
        bolus (list of tuples): Bolus events as (timestamp, dose) pairs
        basal (list of tuples): Basal rate events as (timestamp, rate) pairs
        night_start_hour (int, optional): Hour when night period begins (0-23). Default: 0
        night_end_hour (int, optional): Hour when night period ends (0-23). Default: 8
        
    Returns:
        list of dict: List of night segment dictionaries, each containing:
            - date (datetime.date): Date label for the night
            - start_time (datetime): Timestamp of first glucose reading in the night
            - end_time (datetime): Timestamp of last glucose reading in the night
            - glucose (list of tuples): All (timestamp, value) pairs during the night
            - meals (list of tuples): All meal events during the night
            - bolus (list of tuples): All bolus events during the night
            - basal (list of tuples): Basal rates active at night start
    """
    if not glucose_events:
        return []

    # Dictionary to accumulate events for each night
    # Key: date, Value: dict with lists of glucose/meals/bolus/basal
    nights = {}

    # First pass: group glucose readings by night date
    for ts, val in glucose_events:
        hour = ts.hour
        # Check if timestamp falls within nighttime hours
        if night_start_hour <= hour < night_end_hour:  # e.g., 0 <= hour < 8
            # Use the date of the timestamp as the night label
            # (since night starts at 00:00 of that date)
            night_date = ts.date()
            
            # Initialize night entry if not seen before
            if night_date not in nights:
                nights[night_date] = {
                    'glucose': [],
                    'meals': [],
                    'bolus': [],
                    'basal': []
                }
            nights[night_date]['glucose'].append((ts, val))

    # Second pass: assign meals/bolus/basal to their respective nights
    for night_date in nights.keys():
        # Define exact time boundaries for this night
        night_start = datetime.combine(night_date, datetime.min.time().replace(hour=night_start_hour))
        night_end = datetime.combine(night_date, datetime.min.time().replace(hour=night_end_hour))

        # Find meals that occurred during this night
        for ts, carbs in meals:
            if night_start <= ts < night_end:
                nights[night_date]['meals'].append((ts, carbs))

        # Find bolus doses administered during this night
        for ts, dose in bolus:
            if night_start <= ts < night_end:
                nights[night_date]['bolus'].append((ts, dose))

        # For basal: find the most recent rate change before/at night start
        # This represents the basal rate active during the night
        for ts, rate in basal:
            if ts <= night_start:
                nights[night_date]['basal'].append((ts, rate))

    # Third pass: filter and format nights with sufficient data
    night_segments = []
    for night_date in sorted(nights.keys()):
        # Only keep nights with >10 glucose readings (enough for reliable analysis)
        if len(nights[night_date]['glucose']) > 10:
            night_segments.append({
                'date': night_date,
                'start_time': nights[night_date]['glucose'][0][0],  # First glucose timestamp
                'end_time': nights[night_date]['glucose'][-1][0],   # Last glucose timestamp
                **nights[night_date]  # Unpack glucose/meals/bolus/basal lists
            })
    
    return night_segments


def extract_pre_night_data(glucose_events, meals, bolus, basal, date):
    """
    Extract all data from the day before midnight for nighttime risk prediction.
    
    Filters all glucose, meal, bolus, and basal data from the 24-hour period
    before midnight of the specified date. This data is used to characterize
    the patient's state before entering the nighttime period for risk prediction.
    
    The time window spans from midnight of the previous day (00:00) to midnight
    of the specified date (00:00), capturing the full day before the night begins.
    
    Example: For night date 2025-01-15, extracts data from:
        - Start: 2025-01-14 00:00:00
        - End:   2025-01-15 00:00:00 (exclusive)
    
    Parameters:
        glucose_events (list of tuples): All glucose measurements as 
            [(timestamp, value_mg_dL), ...]
        meals (list of tuples): All meal events as [(timestamp, carbs_grams), ...]
        bolus (list of tuples): All bolus doses as [(timestamp, dose_units), ...]
        basal (list of tuples): All basal rate changes as 
            [(timestamp, rate_units_per_hour), ...]
        date (datetime.date): Date of the night for which to extract pre-night data
        
    Returns:
        tuple: Four filtered lists (glucose, meals_day, bolus_day, basal_day)
            containing only the events from the day before midnight of the specified date
    """
    # Define the 24-hour window: from previous midnight to current midnight
    prev_midnight = datetime.combine(date, datetime.min.time())  # Start of 'date' day
    midnight = prev_midnight + timedelta(days=1)  # Start of next day (exclusive)

    # Filter each event type to the 24-hour window
    # This captures the full day's behavior leading up to the night
    glucose = [(ts, val) for ts, val in glucose_events if prev_midnight <= ts < midnight]
    meals_day = [(ts, carbs) for ts, carbs in meals if prev_midnight <= ts < midnight]
    bolus_day = [(ts, dose) for ts, dose in bolus if prev_midnight <= ts < midnight]
    basal_day = [(ts, rate) for ts, rate in basal if prev_midnight <= ts < midnight]

    return glucose, meals_day, bolus_day, basal_day


def get_night_labels(night_segment):
    """
    Extract binary hypoglycemia and hyperglycemia labels from a night segment.
    
    Analyzes all glucose measurements during a night period and determines
    whether any hypoglycemic (< 70 mg/dL) or hyperglycemic (> 180 mg/dL)
    events occurred. Also prints diagnostic information about the night's
    glucose range.
    
    These labels are used as ground truth for training and evaluating the
    predictive models.
    
    Clinical thresholds:
        - Hypoglycemia: < 70 mg/dL (dangerously low glucose)
        - Hyperglycemia: > 180 mg/dL (dangerously high glucose)
    
    Parameters:
        night_segment (dict): Dictionary containing night data with keys:
            'glucose' (list of tuples): Glucose measurements as [(timestamp, value), ...]
            'date' (datetime.date): Date of the night
        
    Returns:
        tuple: Two integers (hypo, hyper) where:
            hypo (int): 1 if any glucose < 70 mg/dL occurred, 0 otherwise
            hyper (int): 1 if any glucose > 180 mg/dL occurred, 0 otherwise
    """
    import numpy as np
    
    # Extract all glucose values from the night
    G = np.array([val for _, val in night_segment['glucose']])
    
    # Check if any reading crossed clinical thresholds
    hypo = int(np.any(G < 70))    # 1 if any hypo event occurred
    hyper = int(np.any(G > 180))  # 1 if any hyper event occurred

    # Print diagnostic info for monitoring label distribution
    # Useful for detecting data quality issues or imbalanced classes
    print(f"Night {night_segment['date']}: "
          f"Min={np.min(G):.1f}, Max={np.max(G):.1f}, "
          f"hypo={hypo}, hyper={hyper}")
    
    return hypo, hyper