"""
XML Data Reader Module, used only in GUI.py now.
Handles loading and parsing of diabetes patient data from XML files.

This module provides utilities for:
- Loading XML files containing patient diabetes management data
- Extracting patient metadata (ID, weight, insulin type)
- Parsing all event types dynamically from XML structure
- Filtering and displaying events by type and timestamp
"""

import xml.etree.ElementTree as ET


def load_xml(file_path):
    """
    Load and parse an XML file containing patient diabetes data.
    
    Reads the XML file from disk and parses it into an ElementTree structure
    that can be queried and processed. This is the entry point for all XML
    data loading operations.
    """
    tree = ET.parse(file_path)
    return tree.getroot()


def get_patient_info(root):
    """
    Extract general patient information from the XML root element.
    
    Retrieves patient metadata stored as attributes on the root element.
    This information is typically consistent across the entire dataset and
    provides context for interpreting the event data.
    """
    # Extract attributes from root element
    # Returns None if attribute is not present
    patient_id = root.attrib.get("id")
    weight = root.attrib.get("weight")
    insulin_type = root.attrib.get("insulin_type")
    
    return patient_id, weight, insulin_type


def extract_events(root, tags=None):
    """
    Extract all events from the XML file, organized by event type.
    
    Dynamically parses all event categories and their attributes from the XML
    structure. This function is flexible and doesn't require prior knowledge
    of the XML schema - it automatically detects all event types and their
    attributes.
    
    Event types commonly found in diabetes data:
        - glucose_level: CGM measurements with timestamp and value
        - meal: Meal events with carbs, type, and timestamp
        - bolus: Insulin bolus doses with timestamp, dose, and type
        - basal: Basal insulin rates with timestamp and value
        - exercise: Physical activity with intensity and duration
        - sleep: Sleep periods with quality and timestamps
        - finger_stick: Manual blood glucose tests
        - hypo_event: Recorded hypoglycemic events
    """
    # Initialize dictionary to store events by type
    data = {}

    # If no specific tags requested, automatically detect all available tags
    if tags is None:
        # Get unique set of all child element tag names
        # This discovers the schema dynamically without hardcoding
        tags = list({child.tag for child in root})

    # Process each event type
    for tag in tags:
        data[tag] = []  # Initialize list for this event type
        
        # Find the parent element for this event type (e.g., <glucose_level>)
        for element in root.findall(tag):
            # Find all <event> elements within this parent
            for event in element.findall("event"):
                # Collect all attributes dynamically
                # This works regardless of which attributes are present
                event_data = dict(event.attrib)
                data[tag].append(event_data)

    return data


def print_tag(data, tag, time_filter=None):
    """
    Print events of a specific type, optionally filtered by timestamp.
    
    Displays all events of a given type in a readable format. Useful for
    debugging, data exploration, and validation. Can filter to show only
    events at a specific time.
    
    The function dynamically displays all attributes present in each event,
    making it flexible for different event types with varying attributes.
    """
    print(f"\n<{tag}>:")

    # Check if this event type exists in the data
    if tag not in data:
        print("  (No events found)")
        return

    # Process each event of this type
    for event in data[tag]:
        # If time filter is specified, check if this event matches
        if time_filter:
            # Look for any attribute key that contains "ts" or "time"
            matched = False
            for key, value in event.items():
                # Check if this is a time-related attribute
                if "ts" in key or "time" in key:
                    # Check if the value matches the filter
                    if value == time_filter:
                        matched = True
                        break
            
            # Skip this event if it doesn't match the time filter
            if not matched:
                continue

        # Format event attributes for display
        # Creates a comma-separated string of all key-value pairs
        attr_str = ", ".join([f"{key}: {value}" for key, value in event.items()])
        print(f"  {attr_str}")