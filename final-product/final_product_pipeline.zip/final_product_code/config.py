"""
Configuration file for nighttime glucose prediction model.
Contains all global constants, default parameters, and settings.
"""

import warnings
warnings.filterwarnings('ignore')

# ================================================================
# GLOBAL CONSTANTS
# ================================================================
BODY_WEIGHT = 99.0  # kg

# Conversion factors
G2MMOL = 1000.0 / 180.0
MMOL2MGDL = 18.0

# Time grid settings
GRID_MIN = 5.0          # 5-min grid
NIGHT_START_HOUR = 0    # 00:00
NIGHT_END_HOUR = 8      # 08:00

# Visualization settings
SHOW_PLOTS = False

# ================================================================
# DEFAULT PHYSIOLOGICAL PARAMETERS
# ================================================================

# Baseline values
Gb = 100.0  # mg/dL
Ib = 10.0   # mU/L

# Default physiological parameters dictionary
PHYSIOLOGICAL_DEFAULTS = {
    "Gb": 100.0,
    "SG": 0.02,
    "k_abs": 0.03,
    "kI": 0.0116,  # ln(2)/60
    "kX": 0.01,
    "p2": 0.03,
    "p3": 0.0005,
    "Ib": 10.0
}

# ================================================================
# PATIENT IDS
# ================================================================
PATIENT_IDS = ['540', '544', '552', '559', '563', '567', '570', '575', '584', '588', '591', '596']

# ================================================================
# MODEL TRAINING PARAMETERS
# ================================================================
HYPO_THRESHOLD = 0.2    # Probability threshold for hypoglycemia prediction
HYPER_THRESHOLD = 0.5   # Probability threshold for hyperglycemia prediction

# XGBoost parameters
XGBOOST_PARAMS = {
    'n_estimators': 300,
    'max_depth': 4,
    'learning_rate': 0.03,
    'eval_metric': 'logloss',
    'random_state': 42
}