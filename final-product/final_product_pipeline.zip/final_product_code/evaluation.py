"""
Evaluation Module
Assesses model performance on test data and generates comprehensive reports.

This module provides utilities for:
- Evaluating trained models on held-out test nights
- Computing classification metrics (accuracy, precision, recall, F1, AUC)
- Generating confusion matrices and performance statistics
- Creating detailed text reports for model assessment
"""

import numpy as np
from pathlib import Path
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    roc_auc_score, confusion_matrix
)

from config import HYPO_THRESHOLD, HYPER_THRESHOLD
from data_processing import load_xml, extract_events, extract_night_segments, extract_pre_night_data
from model_training import process_night_segment, get_night_labels
from feature_engineering import (
    night_level_features, create_pre_night_features_with_residuals,
    compute_residual_history
)
from ode_models import predict_glucose_trajectory


# ================================================================
# TEST SET EVALUATION
# ================================================================

def evaluate_on_all_nights_with_residuals(test_file, trained, train_residual_history):
    """
    Evaluate trained classifiers on test set with residual-based features.
    
    Performs comprehensive evaluation of the trained hypoglycemia and hyperglycemia
    prediction models on a test patient dataset. For each night in the test set:
        1. Computes fresh residuals from test data (no data leakage)
        2. Generates pre-night and physiological simulation features
        3. Applies feature selection from training
        4. Predicts hypoglycemia and hyperglycemia probabilities
        5. Stores predictions and ground truth for final metrics
    
    Key features:
        - Residuals computed independently for test set
        - Feature selection consistency with training
        - Detailed per-night prediction logging
    
    Parameters:
        test_file (str or Path): Path to XML file containing test patient data
        trained (dict): Dictionary of trained models from train_combined_model_with_residuals,
            containing keys:
                'clf_hypo' (XGBClassifier): Trained hypoglycemia classifier
                'clf_hyper' (XGBClassifier): Trained hyperglycemia classifier
                'top_features_hypo' (numpy.ndarray or None): Indices of selected features
                'top_features_hyper' (numpy.ndarray or None): Indices of selected features
        train_residual_history (dict): Historical residuals from training set (currently unused,
            kept for API compatibility)
        
    Returns:
        list or None: List of result dictionaries, one per successfully evaluated night,
            each containing:
                'date' (datetime.date): Date of the night
                'p_hypo' (float): Predicted hypoglycemia probability [0, 1]
                'p_hyper' (float): Predicted hyperglycemia probability [0, 1]
                'true_hypo' (int): Ground truth hypoglycemia label (0 or 1)
                'true_hyper' (int): Ground truth hyperglycemia label (0 or 1)
                'night_data' (dict): Complete night segment data
                'predicted_trajectory' (tuple): (times, glucose_values) from ODE simulation
            Returns None if no valid night segments found
    """
    # Load and parse test data
    root = load_xml(test_file)
    glucose_events, meals, bolus, basal = extract_events(root)
    night_segments = extract_night_segments(glucose_events, meals, bolus, basal)

    if not night_segments:
        print("No night segments in testfile.")
        return None

    print(f"\n→ Evaluation of {len(night_segments)} nights in {Path(test_file).name}")

    # Compute residuals for TEST set independently (prevents data leakage)
    # These measure how well the ODE model tracked glucose in the test patient's history
    print("  Computing test set residuals...")
    test_residual_history = compute_residual_history(
        glucose_events, meals, bolus, basal, night_segments
    )
    print(f"  ✓ Computed residuals for {len(test_residual_history)} test days")

    # Extract feature selection indices from training
    # These tell us which features to use for each classifier
    top_features_hypo = trained.get("top_features_hypo", None)
    top_features_hyper = trained.get("top_features_hyper", None)
    
    if top_features_hypo is not None:
        print(f"   Using {len(top_features_hypo)} selected features for Hypo prediction")
    if top_features_hyper is not None:
        print(f"   Using {len(top_features_hyper)} selected features for Hyper prediction")

    results = []

    # Process each night in the test set
    for night in night_segments:
        date = night['date']

        # Get ODE residuals for this specific night's preceding day
        hist_residuals = test_residual_history.get(date, None)

        # Step 1: Extract pre-night data (the day before midnight)
        glucose_day, meals_day, bolus_day, basal_day = extract_pre_night_data(
            glucose_events, meals, bolus, basal, date
        )
        
        # Step 2: Generate pre-night features INCLUDING residual-based features
        # These capture the patient's state and ODE model quality before bedtime
        F_pre = create_pre_night_features_with_residuals(
            glucose_day, meals_day, bolus_day, basal_day,
            historical_residuals=hist_residuals
        )
        
        if F_pre is None:
            continue  # Skip this night if insufficient pre-night data

        # Step 3: Run physiological simulation for the night period
        # This generates time-series features from the ODE model
        proc = process_night_segment(
            night,
            fit_params=True,  # Estimate patient-specific parameters
            glucose_events_all=glucose_events,
            meals_all=meals,
            bolus_all=bolus
        )
        if proc is None:
            continue  # Skip if simulation failed

        # Step 4: Generate night-level aggregate features from simulation
        # Uses only first 15 minutes to prevent data leakage
        nf = night_level_features(proc['t_eval'], proc['features'], proc['G_pred'], cutoff_min=15)

        # Step 5: Combine pre-night and night simulation features into hybrid vector
        F_hybrid = np.concatenate([F_pre, nf]).reshape(1, -1)
        
        # Step 6: Apply feature selection (use same features as training)
        if top_features_hypo is not None:
            F_hypo = F_hybrid[:, top_features_hypo]
        else:
            F_hypo = F_hybrid  # Use all features if no selection
            
        if top_features_hyper is not None:
            F_hyper = F_hybrid[:, top_features_hyper]
        else:
            F_hyper = F_hybrid

        # Step 7: Get ground truth labels from actual glucose measurements
        true_hypo, true_hyper = get_night_labels(night)

        # Step 8: Generate probability predictions from trained classifiers
        # predict_proba returns [P(class=0), P(class=1)] - we want P(class=1)
        p_hypo = trained["clf_hypo"].predict_proba(F_hypo)[0, 1]
        p_hyper = trained["clf_hyper"].predict_proba(F_hyper)[0, 1]

        # Log predictions for monitoring
        print(f"Night {date} → P(hypo)={p_hypo:.2f}  P(hyper)={p_hyper:.2f} "
              f"| True: hypo={true_hypo}, hyper={true_hyper}")

        # Step 9: Generate complete predicted glucose trajectory for visualization
        # This runs the full ODE simulation across the entire night
        t0 = night['start_time']
        t_end = night['end_time']
        G0 = night['glucose'][0][1]  # Initial glucose value
        
        # Format meal and bolus events for ODE simulator
        meals_night = [
            {"time": ts, "carbs": carbs, "gi": 55.0, "type": "unknown"}
            for ts, carbs in night['meals']
        ]
        bolus_night = [
            {"time": ts, "dose": dose, "type": "rapid"}
            for ts, dose in night['bolus']
        ]
        
        # Run ODE simulation
        times_sim, G_sim = predict_glucose_trajectory(
            t0, t_end, G0,
            meals_night, bolus_night,
            proc['bergman_params'],  # Use patient-specific parameters
            dt_min=1.0
        )
        
        predicted_trajectory = (times_sim, G_sim)

        # Step 10: Store all results for this night
        results.append({
            "date": date,
            "p_hypo": p_hypo,
            "p_hyper": p_hyper,
            "true_hypo": true_hypo,
            "true_hyper": true_hyper,
            "night_data": night,
            "predicted_trajectory": predicted_trajectory
        })

    return results


# ================================================================
# METRICS COMPUTATION
# ================================================================

def evaluate_final_metrics(summary):
    """
    Compute and display comprehensive evaluation metrics for nighttime glucose predictions.
    
    Performs complete evaluation of model performance across all test nights,
    including classification metrics and confusion matrices. Evaluates both
    hypoglycemia and hyperglycemia predictions separately.
    
    Metrics computed for each condition:
        - Accuracy: Overall correct prediction rate
        - Precision: Positive predictive value (PPV)
        - Recall: Sensitivity / True positive rate
        - F1-score: Harmonic mean of precision and recall
        - Confusion matrix: 2x2 table of predictions vs ground truth
        - AUC-ROC: Area under receiver operating characteristic curve
    
    Decision thresholds (from config.py):
        - Hypoglycemia: HYPO_THRESHOLD (typically 0.2 = 20%)
        - Hyperglycemia: HYPER_THRESHOLD (typically 0.5 = 50%)
    
    Parameters:
        summary (list of dict): List of result dictionaries from evaluate_on_all_nights_with_residuals,
            each containing:
                'true_hypo' (int): Ground truth hypoglycemia label (0 or 1)
                'true_hyper' (int): Ground truth hyperglycemia label (0 or 1)
                'p_hypo' (float): Predicted hypoglycemia probability [0, 1]
                'p_hyper' (float): Predicted hyperglycemia probability [0, 1]
        
    Returns:
        None: Prints metrics to console
    """
    print("\n============================")
    print("   FINAL MODEL EVALUATION")
    print("============================")

    # Extract predictions and ground truth for hypoglycemia
    y_true_hypo  = [r['true_hypo'] for r in summary]
    y_score_hypo = [r['p_hypo'] for r in summary]  # Continuous probabilities
    # Convert probabilities to binary predictions using threshold
    y_pred_hypo  = [1 if p > HYPO_THRESHOLD else 0 for p in y_score_hypo]

    # Extract predictions and ground truth for hyperglycemia
    y_true_hyper  = [r['true_hyper'] for r in summary]
    y_pred_hyper  = [1 if r['p_hyper'] > HYPER_THRESHOLD else 0 for r in summary]
    y_score_hyper = [r['p_hyper'] for r in summary]  # Continuous probabilities

    # ===== HYPOGLYCEMIA METRICS =====
    print("\n--- HYPO PREDICTION ---")
    print("Accuracy :", accuracy_score(y_true_hypo, y_pred_hypo))
    print("Precision:", precision_score(y_true_hypo, y_pred_hypo, zero_division=0))
    print("Recall   :", recall_score(y_true_hypo, y_pred_hypo, zero_division=0))
    print("F1-score :", f1_score(y_true_hypo, y_pred_hypo, zero_division=0))
    print("Confusion Matrix:\n", confusion_matrix(y_true_hypo, y_pred_hypo))
    
    # AUC requires both positive and negative examples
    try:
        print("AUC:", roc_auc_score(y_true_hypo, y_score_hypo))
    except:
        print("AUC cannot be calculated (no variation in labels)")

    # ===== HYPERGLYCEMIA METRICS =====
    print("\n--- HYPER PREDICTION ---")
    print("Accuracy :", accuracy_score(y_true_hyper, y_pred_hyper))
    print("Precision:", precision_score(y_true_hyper, y_pred_hyper, zero_division=0))
    print("Recall   :", recall_score(y_true_hyper, y_pred_hyper, zero_division=0))
    print("F1-score :", f1_score(y_true_hyper, y_pred_hyper, zero_division=0))
    print("Confusion Matrix:\n", confusion_matrix(y_true_hyper, y_pred_hyper))
    
    try:
        print("AUC:", roc_auc_score(y_true_hyper, y_score_hyper))
    except:
        print("AUC cannot be calculated (no variation in labels)")


def generate_summary_report(summary, output_file="model_report.txt"):
    """
    Generate comprehensive text report of model performance and statistics.
    
    Creates a detailed evaluation report including per-patient statistics,
    classification metrics, confusion matrices, and overall performance summary.
    The report is formatted for readability and provides a complete record of
    model evaluation results.
    
    Report sections include:
        1. Header with generation timestamp and total nights evaluated
        2. Per-patient breakdown (nights analyzed, event frequencies)
        3. Hypoglycemia prediction metrics (accuracy, precision, recall, F1, AUC)
        4. Hyperglycemia prediction metrics (same metrics as above)
        5. Confusion matrices for both conditions
        6. Summary statistics (event rates, average risks)
    
    Thresholds used:
        - Hypoglycemia: HYPO_THRESHOLD from config.py
        - Hyperglycemia: HYPER_THRESHOLD from config.py
    
    Parameters:
        summary (list of dict): Evaluation results from evaluate_on_all_nights_with_residuals,
            each containing:
                'patient_id' (str or int): Patient identifier
                'date' (datetime.date): Night date
                'true_hypo' (int): Ground truth hypoglycemia label (0 or 1)
                'true_hyper' (int): Ground truth hyperglycemia label (0 or 1)
                'p_hypo' (float): Predicted hypoglycemia probability [0, 1]
                'p_hyper' (float): Predicted hyperglycemia probability [0, 1]
        output_file (str, optional): Path for the output text file. Default: "model_report.txt"
        
    Returns:
        None: Writes formatted report to output_file and prints confirmation message
    """
    from datetime import datetime
    
    with open(output_file, 'w') as f:
        # ===== HEADER =====
        f.write("="*70 + "\n")
        f.write("   NIGHTTIME GLUCOSE PREDICTION MODEL - EVALUATION REPORT\n")
        f.write("="*70 + "\n\n")
        
        f.write(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Nights Evaluated: {len(summary)}\n\n")
        
        # ===== PER-PATIENT BREAKDOWN =====
        f.write("--- PER-PATIENT STATISTICS ---\n\n")
        # Get unique patient IDs from results
        patients = sorted(set(r['patient_id'] for r in summary))
        
        for pid in patients:
            # Filter results for this patient
            patient_results = [r for r in summary if r['patient_id'] == pid]
            n_nights = len(patient_results)
            n_hypo = sum(r['true_hypo'] for r in patient_results)
            n_hyper = sum(r['true_hyper'] for r in patient_results)
            
            f.write(f"Patient {pid}:\n")
            f.write(f"  Nights analyzed: {n_nights}\n")
            f.write(f"  Hypoglycemia events: {n_hypo} ({n_hypo/n_nights*100:.1f}%)\n")
            f.write(f"  Hyperglycemia events: {n_hyper} ({n_hyper/n_nights*100:.1f}%)\n\n")
        
        # ===== HYPOGLYCEMIA METRICS =====
        y_true_hypo = [r['true_hypo'] for r in summary]
        y_score_hypo = [r['p_hypo'] for r in summary]
        # Apply threshold to convert probabilities to binary predictions
        y_pred_hypo = [1 if p > HYPO_THRESHOLD else 0 for p in y_score_hypo]
        
        f.write("\n--- HYPOGLYCEMIA PREDICTION METRICS ---\n\n")
        f.write(f"Threshold: {HYPO_THRESHOLD}\n")
        f.write(f"Accuracy:  {accuracy_score(y_true_hypo, y_pred_hypo):.3f}\n")
        f.write(f"Precision: {precision_score(y_true_hypo, y_pred_hypo, zero_division=0):.3f}\n")
        f.write(f"Recall:    {recall_score(y_true_hypo, y_pred_hypo, zero_division=0):.3f}\n")
        f.write(f"F1-Score:  {f1_score(y_true_hypo, y_pred_hypo, zero_division=0):.3f}\n")
        
        # Format confusion matrix for text output
        cm_hypo = confusion_matrix(y_true_hypo, y_pred_hypo)
        f.write(f"\nConfusion Matrix:\n")
        f.write(f"                Predicted Negative  Predicted Positive\n")
        f.write(f"Actual Negative        {cm_hypo[0,0]:4d}              {cm_hypo[0,1]:4d}\n")
        f.write(f"Actual Positive        {cm_hypo[1,0]:4d}              {cm_hypo[1,1]:4d}\n")
        
        # AUC calculation (may fail if labels don't vary)
        try:
            auc_hypo = roc_auc_score(y_true_hypo, y_score_hypo)
            f.write(f"\nAUC-ROC: {auc_hypo:.3f}\n")
        except:
            f.write(f"\nAUC-ROC: Could not be calculated\n")
        
        # ===== HYPERGLYCEMIA METRICS =====
        y_true_hyper = [r['true_hyper'] for r in summary]
        y_score_hyper = [r['p_hyper'] for r in summary]
        y_pred_hyper = [1 if p > HYPER_THRESHOLD else 0 for p in y_score_hyper]
        
        f.write("\n\n--- HYPERGLYCEMIA PREDICTION METRICS ---\n\n")
        f.write(f"Threshold: {HYPER_THRESHOLD}\n")
        f.write(f"Accuracy:  {accuracy_score(y_true_hyper, y_pred_hyper):.3f}\n")
        f.write(f"Precision: {precision_score(y_true_hyper, y_pred_hyper, zero_division=0):.3f}\n")
        f.write(f"Recall:    {recall_score(y_true_hyper, y_pred_hyper, zero_division=0):.3f}\n")
        f.write(f"F1-Score:  {f1_score(y_true_hyper, y_pred_hyper, zero_division=0):.3f}\n")
        
        cm_hyper = confusion_matrix(y_true_hyper, y_pred_hyper)
        f.write(f"\nConfusion Matrix:\n")
        f.write(f"                Predicted Negative  Predicted Positive\n")
        f.write(f"Actual Negative        {cm_hyper[0,0]:4d}              {cm_hyper[0,1]:4d}\n")
        f.write(f"Actual Positive        {cm_hyper[1,0]:4d}              {cm_hyper[1,1]:4d}\n")
        
        try:
            auc_hyper = roc_auc_score(y_true_hyper, y_score_hyper)
            f.write(f"\nAUC-ROC: {auc_hyper:.3f}\n")
        except:
            f.write(f"\nAUC-ROC: Could not be calculated\n")
        
        # ===== SUMMARY STATISTICS =====
        f.write("\n\n--- SUMMARY STATISTICS ---\n\n")
        # Overall event frequencies
        f.write(f"Total nights with hypoglycemia:  {sum(y_true_hypo)} ({sum(y_true_hypo)/len(y_true_hypo)*100:.1f}%)\n")
        f.write(f"Total nights with hyperglycemia: {sum(y_true_hyper)} ({sum(y_true_hyper)/len(y_true_hyper)*100:.1f}%)\n")
        
        # Average predicted risks across all nights
        f.write(f"\nAverage predicted hypoglycemia risk:  {np.mean(y_score_hypo)*100:.1f}%\n")
        f.write(f"Average predicted hyperglycemia risk: {np.mean(y_score_hyper)*100:.1f}%\n")
        
        # ===== FOOTER =====
        f.write("\n" + "="*70 + "\n")
        f.write("                         END OF REPORT\n")
        f.write("="*70 + "\n")
    
    print(f"\n📄 Report saved to: {output_file}")