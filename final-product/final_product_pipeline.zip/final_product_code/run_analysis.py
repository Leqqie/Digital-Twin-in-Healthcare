"""
Main Analysis Runner
Primary entry point for nighttime glucose prediction model training and evaluation.

This is the only file you need to run to execute the complete analysis pipeline.

The pipeline performs:
1. Patient-specific model training with residual-based features
2. Feature importance analysis and visualization
3. Test set evaluation with trajectory predictions
4. Cross-patient performance aggregation
5. Comprehensive metrics computation and reporting
6. Generation of all visualizations and reports

Usage:
    1. Update the paths in the __main__ section to point to your data
    2. Run the file
    3. Results will be saved to the specified output directory

Directory structure expected:
    Training: {train_dir}/{patient_id}-ws-training.xml
    Testing:  {test_dir}/{patient_id}-ws-testing.xml
    Output:   {results_dir}/*.png and {results_dir}/model_report.txt
"""

from pathlib import Path

# Import configuration
from config import PATIENT_IDS

# Import processing modules
from model_training import train_combined_model_with_residuals
from evaluation import evaluate_on_all_nights_with_residuals, evaluate_final_metrics, generate_summary_report
from visualization import plot_feature_importance, visualize_metrics, plot_predicted_trajectory_with_actual
from feature_engineering import get_feature_names_with_residuals


def main(train_dir, test_dir, results_dir, n_features):
    """
    Main pipeline for training and evaluating nighttime glucose prediction models.
    
    Orchestrates the complete workflow for all patients in the dataset:
        1. Validates input directories and configuration
        2. Iterates through all patient IDs from config
        3. For each patient:
           a. Loads training and testing XML files
           b. Trains patient-specific XGBoost models with residual features
           c. Generates feature importance visualizations
           d. Evaluates models on test nights
           e. Creates trajectory plots for high-risk/event nights
        4. Aggregates results across all patients
        5. Computes comprehensive evaluation metrics
        6. Generates visualizations (ROC, PR curves, confusion matrices)
        7. Creates detailed text report
    
    The pipeline implements per-patient training to enable personalized predictions
    and prevent cross-patient data leakage. Each patient's model is trained only
    on their historical data.
    
    Parameters:
        train_dir (str or Path): Path to directory containing training XML files
            Expected naming: "{patient_id}-ws-training.xml"
        test_dir (str or Path): Path to directory containing testing XML files
            Expected naming: "{patient_id}-ws-testing.xml"
        results_dir (str or Path): Path to directory for saving all outputs
            Will be created if it doesn't exist
        n_features (int): Number of top features to select for each classifier
            Typical values: 25-50 features
        
    Returns:
        Prints progress to console, saves all outputs to results_dir
    """
    # Convert paths to Path objects for robust path handling
    train_dir = Path(train_dir) 
    test_dir = Path(test_dir)
    results_dir = Path(results_dir)

    # Validate input directories exist
    if not train_dir.exists():
        print(f"    ERROR: Train directory does not exist: {train_dir}")
        return
    if not test_dir.exists():
        print(f"    ERROR: Test directory does not exist: {test_dir}")
        return

    # Display pipeline configuration
    print("\n" + "="*70)
    print("   NIGHTTIME GLUCOSE PREDICTION - ANALYSIS PIPELINE")
    print("="*70)
    print(f"\n  Configuration:")
    print(f"    Training data: {train_dir}")
    print(f"    Testing data:  {test_dir}")
    print(f"    Output directory: {results_dir}")
    print(f"    Patients: {len(PATIENT_IDS)} ({', '.join(PATIENT_IDS)})")
    print(f"    Feature selection: Top {n_features} features per classifier")
    
    print("\n" + "="*70)
    print("   STARTING TRAINING PHASE")
    print("="*70 + "\n")

    # Initialize results accumulator
    # Each entry will contain predictions, ground truth, and metadata for one night
    summary = []

    # Process each patient sequentially
    for pid in PATIENT_IDS:
        print("\n" + "="*70)
        print(f"   PATIENT {pid}")
        print("="*70)

        # Construct file paths for this patient
        train_file = train_dir / f"{pid}-ws-training.xml"
        test_file  = test_dir  / f"{pid}-ws-testing.xml"

        # Check if both training and testing files exist
        if not train_file.exists():
            print(f"    WARNING: No training file found: {train_file}")
            print(f"    Skipping patient {pid}")
            continue
        if not test_file.exists():
            print(f"    WARNING: No testing file found: {test_file}")
            print(f"    Skipping patient {pid}")
            continue

        print(f"    Training file: {train_file.name}")
        print(f"    Testing file:  {test_file.name}")

        # ===== STEP 1: TRAIN MODELS =====
        print(f"\n  Step 1/3: Training models...")
        # Train both hypoglycemia and hyperglycemia classifiers
        trained_result = train_combined_model_with_residuals(
            str(train_file), 
            N_features=n_features
        )
        
        # Check if training succeeded
        if trained_result is None:
            print(f"    WARNING: Training failed for patient {pid}")
            print(f"    Possible causes: insufficient data, all same label, errors in processing")
            print(f"    Skipping patient {pid}")
            continue
        
        # Unpack training results
        trained = trained_result['trained']  # Contains clf_hypo, clf_hyper, feature indices
        train_residual_history = trained_result['residual_history']  # Historical ODE errors
        
        print(f"    Training completed successfully")

        # ===== STEP 2: FEATURE IMPORTANCE VISUALIZATION =====
        print(f"\n  Step 2/3: Generating feature importance plots...")
        # Get human-readable feature names
        feature_names = get_feature_names_with_residuals()
        
        # Create and save feature importance plot
        # Shows top 20 features for both hypo and hyper prediction
        plot_feature_importance(
            trained, 
            feature_names=feature_names, 
            patient_id=pid,
            save_dir=results_dir
        )

        # ===== STEP 3: EVALUATE ON TEST SET =====
        print(f"\n  Step 3/3: Evaluating on test set...")
        # Evaluate trained models on held-out test nights
        results = evaluate_on_all_nights_with_residuals(
            str(test_file), 
            trained, 
            train_residual_history
        )
        
        # Check if evaluation succeeded
        if results:
            print(f"    Evaluated {len(results)} test nights")
            
            # ===== GENERATE TRAJECTORY PLOTS FOR INTERESTING NIGHTS =====
            # Create detailed visualizations for nights that meet any of these criteria:
            # 1. High hypoglycemia risk (p_hypo > 0.2)
            # 2. Elevated hyperglycemia risk (p_hyper > 0.4, using 0.4 instead of 0.5 
            #    to catch borderline cases)
            # 3. Actual hypoglycemia occurred (true_hypo == 1)
            # 4. Actual hyperglycemia occurred (true_hyper == 1)
            #
            # This selective plotting reduces output volume while ensuring we visualize
            # all clinically relevant or challenging cases
            for r in results:
                if r['p_hypo'] > 0.2 or r['p_hyper'] > 0.4 or \
                   r['true_hypo'] == 1 or r['true_hyper'] == 1:
                    plot_predicted_trajectory_with_actual(
                        r['predicted_trajectory'],      # (times, glucose_values) from ODE
                        r['night_data']['glucose'],     # Actual CGM measurements
                        r['p_hypo'],                    # Predicted hypo probability
                        r['p_hyper'],                   # Predicted hyper probability
                        r['true_hypo'],                 # Ground truth hypo label
                        r['true_hyper'],                # Ground truth hyper label
                        r['date'],                      # Night date
                        r['night_data']['start_time'],  # Night start time for x-axis
                        save_dir=results_dir,
                        patient_id=pid
                    )
            
            # Add patient ID to each result and append to summary
            # This enables per-patient analysis in the final report
            for r in results:
                summary.append({
                    'patient_id': pid,
                    **r  # Unpack all result fields (date, predictions, labels, etc.)
                })
        else:
            print(f"    WARNING: No valid results for patient {pid}")
            print(f"    Possible causes: no test nights with sufficient data")

    # ===== CHECK IF WE HAVE ANY RESULTS =====
    if not summary:
        print("\n" + "="*70)
        print("   ERROR: No results to evaluate")
        print("="*70)
        print("\n  No patients were successfully processed.")
        print("    Check that:")
        print("    1. Training and testing files exist for at least one patient")
        print("    2. Files contain sufficient data (>3 nights)")
        print("    3. Patient IDs in config match filenames")
        print("\n  Exiting.")
        return

    # ===== AGGREGATE RESULTS SUMMARY =====
    print("\n" + "="*70)
    print("   FINAL RESULTS SUMMARY")
    print("="*70)
    print(f"\n  Total nights evaluated: {len(summary)}")
    print(f"    Patients included: {len(set(r['patient_id'] for r in summary))}")
    
    # Calculate overall statistics
    total_hypo_events = sum(r['true_hypo'] for r in summary)
    total_hyper_events = sum(r['true_hyper'] for r in summary)
    print(f"    Hypoglycemia events: {total_hypo_events} ({total_hypo_events/len(summary)*100:.1f}%)")
    print(f"    Hyperglycemia events: {total_hyper_events} ({total_hyper_events/len(summary)*100:.1f}%)")

    # Display sample of results (first 10 nights)
    print("\n  Sample predictions (first 10 nights):")
    for r in summary[:10]:
        print(f"    Patient {r['patient_id']} | {r['date']} | "
              f"True: Hypo={r['true_hypo']} Hyper={r['true_hyper']} | "
              f"Pred: P(hypo)={r['p_hypo']:.2f} P(hyper)={r['p_hyper']:.2f}")
    
    if len(summary) > 10:
        print(f"    ... and {len(summary) - 10} more nights")

    # ===== COMPUTE EVALUATION METRICS =====
    print("\n" + "="*70)
    print("   COMPUTING EVALUATION METRICS")
    print("="*70)
    evaluate_final_metrics(summary)

    # ===== GENERATE VISUALIZATIONS =====
    print("\n" + "="*70)
    print("   GENERATING VISUALIZATIONS")
    print("="*70)
    visualize_metrics(summary, save_dir=results_dir)

    # ===== GENERATE TEXT REPORT =====
    print("\n" + "="*70)
    print("   GENERATING SUMMARY REPORT")
    print("="*70)
    generate_summary_report(summary, f'{results_dir}/model_report.txt')

    # ===== COMPLETION MESSAGE =====
    print("\n" + "="*70)
    print("   ANALYSIS COMPLETE")
    print("="*70)
    print(f"\n  All outputs saved to: {results_dir}")
    print(f"\n  Generated files:")
    print(f"    Text report: model_report.txt")
    print(f"    Visualizations: *.png")
    print("\n  Analysis completed successfully!\n")


if __name__ == "__main__":
    """
    Entry point when running the script directly.
    
    Configuration:
    1. Update the directory paths below to match your data location
    2. Adjust N_FEATURES if desired (25-50 recommended)
    3. Ensure PATIENT_IDS in config.py matches available data files
    4. Run the file
    
    The script will:
    - Train models for each patient
    - Evaluate on test data
    - Save all results (plots and report) to SAVE_DIR
    """
    
    # ===== CONFIGURATION - UPDATE THESE PATHS =====
    
    # Directory containing training XML files
    # Expected files: {patient_id}-ws-training.xml
    TRAIN_DIR = r"C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\Dataset_XML\Training"
    
    # Directory containing testing XML files
    # Expected files: {patient_id}-ws-testing.xml
    TEST_DIR = r"C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\Dataset_XML\Testing"
    
    # Directory for saving all results
    # Will be created if it doesn't exist
    SAVE_DIR = r"C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\night_predictions_25"
    
    # Number of top features to select for each classifier
    N_FEATURES = 25
    
    # ===== RUN ANALYSIS PIPELINE =====
    main(
        train_dir=TRAIN_DIR, 
        test_dir=TEST_DIR, 
        results_dir=SAVE_DIR, 
        n_features=N_FEATURES
    )