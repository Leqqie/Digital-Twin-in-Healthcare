"""
Digital Twin for Diabetes - GUI Application

A comprehensive patient data visualization tool for diabetes management.
Provides interactive visualization of:
- Glucose monitoring data (CGM and finger stick)
- Insulin therapy (bolus and basal)
- Meals, exercise, and sleep patterns
- Hypoglycemic event tracking

Features:
- Multi-patient support with easy switching
- Day-by-day and full timeline visualization
- Unit conversion (mg/dL ↔ mmol/L)
- Navigation history with back button support
- Fullscreen mode for clinical settings
"""

import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import read_data as read


class DiabetesTwinGUI(tk.Tk):
    def __init__(self):
        """
        Initialize the Digital Twin for Diabetes GUI application.
        
        Sets up the main window in fullscreen mode, loads default XML data,
        and displays the patient selection menu.
        
        Key bindings:
            Tab: Toggle fullscreen mode
            Escape: Navigate back to previous page
        """
        super().__init__()
        self.title("Digital Twin for Diabetes")
        
        # Start in fullscreen mode (useful for clinical displays)
        self.attributes("-fullscreen", True)
        self.bind("<Tab>", self.toggle_fullscreen)

        # --- Initialize application state ---
        # Path to default patient data file
        self.selected_xml_file = r"C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\Dataset_XML\Training\575-ws-training.xml"
        self.data_roots = {}  # Dictionary to store extracted events by type (glucose, meal, etc.)
        self.current_patient = None  # Currently selected patient ID
        self.page_history = []  # Stack-based navigation history for back button
        self.glucose_unit = "mg/dL"  # Default glucose unit (can toggle to mmol/L)

        # Load default XML file to initialize data structures
        self.load_xml_data(self.selected_xml_file)

        # Display patient selection as the starting page
        self.patient_selection_menu()

    # ================================================================
    # WINDOW MANAGEMENT & NAVIGATION
    # ================================================================

    def toggle_fullscreen(self, event=None):
        """
        Toggle between fullscreen and windowed mode.
        
        When exiting fullscreen, sets window to 1280x720 for convenient viewing.
        Useful for switching between presentation and development modes.
        
        Args:
            event: Tkinter event object (from key binding)
        """
        # Get current fullscreen state
        fullscreen_state = self.attributes("-fullscreen")
        # Toggle it
        self.attributes("-fullscreen", not fullscreen_state)

        # Set reasonable window size when exiting fullscreen
        if fullscreen_state:  # If we're currently in fullscreen (about to exit)
            self.geometry("1280x720")  
            self.update_idletasks()  # Force immediate update

    def toggle_glucose_unit(self):
        """
        Toggle between mg/dL and mmol/L for glucose display.
        
        Conversion factor: 1 mmol/L = 18 mg/dL
        This is the standard conversion used in diabetes care worldwide.
        
        Automatically refreshes the current page to update all displayed values
        and button labels.
        """
        if self.glucose_unit == "mg/dL":
            self.glucose_unit = "mmol/L"
        else:
            self.glucose_unit = "mg/dL"
        
        # Refresh the current page to update button text and plots
        if hasattr(self, '_current_root_key'):
            self.show_tag_page(self._current_root_key)

    def convert_glucose_value(self, value_mg_dl):
        """
        Convert glucose value based on current unit setting.
        
        All glucose values in XML are stored in mg/dL (US standard).
        This function converts to mmol/L (international standard) when needed.
        
        Args:
            value_mg_dl (float): Glucose value in mg/dL
        
        Returns:
            float: Converted value (stays in mg/dL or converts to mmol/L)
        """
        if self.glucose_unit == "mmol/L":
            return value_mg_dl / 18.0  # Standard conversion factor
        return value_mg_dl

    def get_glucose_thresholds(self):
        """
        Get hypoglycemia and hyperglycemia thresholds in current unit.
        
        Clinical thresholds:
            - Hypoglycemia: 70 mg/dL (3.9 mmol/L) - dangerously low
            - Hyperglycemia: 180 mg/dL (10.0 mmol/L) - dangerously high
        
        Returns:
            tuple: (hypo_threshold, hyper_threshold) in current display unit
        """
        if self.glucose_unit == "mmol/L":
            return 3.9, 10.0  # mmol/L thresholds
        return 70, 180  # mg/dL thresholds

    def go_back(self, event=None):
        """
        Navigate back to the previous page in the navigation history.
        
        Implements stack-based navigation: pops the most recent page from
        history and calls it to redraw. Similar to browser back button.
        
        Args:
            event: Tkinter event object (from Escape key binding)
        """
        if self.page_history:
            previous_page = self.page_history.pop()  # Get last page
            previous_page()  # Call the page function to redraw it

    def clear_window(self):
        """
        Clear all widgets from the current window.
        
        Destroys all child widgets to prepare for drawing a new page.
        Rebinds the Escape key to ensure back navigation works on the new page.
        
        This is called at the start of every page-drawing function.
        """
        # Destroy all child widgets
        for widget in self.winfo_children():
            widget.destroy()
        
        # Rebind Escape key after clearing (in case it was unbound)
        self.bind("<Escape>", self.go_back)

    # ================================================================
    # DATA LOADING
    # ================================================================

    def load_xml_data(self, file_path):
        """
        Load XML data from the specified file path and extract all events.
        
        Reads patient data from XML file and extracts all event types
        (glucose, meals, insulin, exercise, sleep) into a structured dictionary.
        
        Args:
            file_path (str): Path to the XML file containing patient data
            
        Updates:
            self.selected_xml_file: Stores the loaded file path
            self.data_roots: Dictionary containing extracted event data by type
                Keys: 'glucose_level', 'bolus', 'basal', 'meal', 'exercise', 
                      'sleep', 'finger_stick', 'hypo_event'
                Values: Lists of dictionaries with event attributes
        
        Shows error dialog if loading fails.
        """
        self.selected_xml_file = file_path
        try:
            # Load and parse XML file
            root = read.load_xml(file_path)
            # Extract all event types (tags=None means extract all)
            self.data_roots = read.extract_events(root, tags=None)
        except Exception as e:
            # Show user-friendly error message
            messagebox.showerror("Error", f"Failed to load XML:\n{e}")
            self.data_roots = {}  # Empty dict to prevent crashes

    # ================================================================
    # PATIENT SELECTION MENU
    # ================================================================

    def patient_selection_menu(self):
        """
        Display the patient selection menu with buttons for all available patients.
        
        This is the root page of the application. Shows a vertical list of
        patient IDs (540-596) and an exit button.
        
        Navigation:
            - Clears history as this is the root page (no back button)
            - Clicking a patient ID loads that patient's data
        """
        self.clear_window()
        self.page_history = []  # Clear history - this is the root page
        
        ttk.Label(self, text="Select Patient", font=("Arial", 16)).pack(pady=20)

        # Available patient IDs from the dataset
        patients = [540, 544, 552, 559, 563, 567, 570, 575, 584, 588, 591, 596]

        # Frame to center buttons vertically
        button_frame = ttk.Frame(self)
        button_frame.pack(expand=True)

        # Create one button per patient
        for patient_id in patients:
            ttk.Button(
                button_frame,
                text=f"Patient {patient_id}",
                width=20,
                # Use lambda with default arg to capture patient_id correctly
                command=lambda pid=patient_id: self.select_patient(pid)
            ).pack(pady=5)

        # Exit button at the bottom
        ttk.Button(self, text="Exit", width=20, command=self.destroy).pack(side="bottom", pady=30)

    # ================================================================
    # PATIENT SELECTION & MAIN MENU
    # ================================================================

    def select_patient(self, patient_id):
        """
        Select a patient and load their XML data.
        
        Args:
            patient_id (int): The ID of the patient to select
            
        Updates:
            self.current_patient: Stores the selected patient ID
            Loads the corresponding training XML file
            Navigates to the selection page (History/Predict menu)
        """
        self.current_patient = patient_id
        
        # Construct path to patient's training data XML file
        xml_path = rf"C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\Dataset_XML\Training\{patient_id}-ws-training.xml"
        
        # Load patient data
        self.load_xml_data(xml_path)
        
        # Show main menu for this patient
        self.selection_page()

    def selection_page(self):
        """
        Display the main selection page for the current patient.
        
        Shows two main options:
            - History - View historical patient data
            - Predict - Make predictions (placeholder for future functionality)
        
        Navigation:
            - Back button returns to patient selection
            - Adds patient_selection_menu to history stack
        """
        self.clear_window()
        self.page_history.append(self.patient_selection_menu)

        # Back button to return to patient selection
        ttk.Button(self, text="← Back", command=self.patient_selection_menu).pack(anchor="w", padx=10, pady=10)

        # Display current patient ID
        ttk.Label(self, text=f"Patient {self.current_patient}", font=("Arial", 16)).pack(pady=20)

        # Center frame for main menu buttons
        button_frame = ttk.Frame(self)
        button_frame.pack(expand=True)

        # History button - view past data
        ttk.Button(
            button_frame,
            text="History",
            width=25,
            command=self.history_page
        ).pack(pady=10)

        # Predict button - future predictions
        ttk.Button(
            button_frame,
            text="Predict",
            width=25,
            command=self.predict_page
        ).pack(pady=10)

    # ================================================================
    # HISTORY PAGE - DATA TYPE SELECTION
    # ================================================================

    def history_page(self):
        """
        Display the history page with options to view different data types.
        
        Shows buttons for viewing all available data categories:
            - Glucose Level (CGM readings)
            - Insulin Bolus (mealtime insulin doses)
            - Basal Insulin (background insulin infusion rates)
            - Exercise (physical activity logs)
            - Meal (carbohydrate intake)
            - Finger Stick (manual blood glucose tests)
            - Sleep (sleep quality and duration)
        
        Navigation:
            - Back button returns to selection page
            - Adds selection_page to history stack
        """
        self.clear_window()
        self.page_history.append(self.selection_page)

        # Back button to main menu
        ttk.Button(self, text="← Back", command=self.selection_page).pack(anchor="w", padx=10, pady=10)

        ttk.Label(self, text="History", font=("Arial", 16)).pack(pady=20)

        # Define data types with display names and internal keys
        # Format: (User-friendly name, XML tag name)
        history_options = [
            ("Glucose Level", "glucose_level"),      # CGM data
            ("Insulin Bolus", "bolus"),              # Mealtime insulin
            ("Basal Insulin", "basal"),              # Background insulin
            ("Exercise", "exercise"),                 # Physical activity
            ("Meal", "meal"),                         # Carb intake
            ("Finger Stick", "finger_stick"),        # Manual BG tests
            ("Sleep", "sleep")                        # Sleep tracking
        ]

        # Frame to organize buttons
        button_frame = ttk.Frame(self)
        button_frame.pack(pady=20)

        # Create button for each data type
        for display_name, root_key in history_options:
            ttk.Button(
                button_frame,
                text=display_name,
                width=25,
                # Pass root_key to show_tag_page to display that data type
                command=lambda rk=root_key: self.show_tag_page(rk)
            ).pack(pady=5)

    # ================================================================
    # DATA DISPLAY PAGE
    # ================================================================

    def show_tag_page(self, root_key):
        """
        Display the data for a specific event type (tag).
        
        Behavior varies by data type:
        
        For glucose_level and finger_stick:
            - Groups data by day
            - Shows grid of date buttons to plot individual days
            - Provides "Show Full Timeline" button for complete view
            - Includes unit toggle button (mg/dL ↔ mmol/L)
            
        For other event types (bolus, basal, meal, exercise, sleep):
            - Displays all events in a scrollable formatted text table
            - Shows relevant attributes for each event type
        
        Args:
            root_key (str): The type of event to display 
                ('glucose_level', 'bolus', 'meal', etc.)
        
        Navigation:
            - Back button returns to history page
            - Adds history_page to navigation stack
        """
        self.clear_window()
        self.page_history.append(self.history_page)
        
        # Store current view for unit toggle refresh
        self._current_root_key = root_key
        
        # Back button
        ttk.Button(self, text="← Back", command=self.history_page).pack(anchor="w", padx=10, pady=10)
        
        # Page title with formatted event type name
        ttk.Label(self, text=f"{root_key.replace('_', ' ').title()} History", font=("Arial", 14)).pack(pady=10)

        # Get events for this data type
        events = self.data_roots.get(root_key, [])
        if not events:
            ttk.Label(self, text="No data available for this root.").pack(pady=20)
            return

        # ===== SPECIAL HANDLING: GLUCOSE AND FINGER STICK DATA =====
        if root_key in ["glucose_level", "finger_stick"]:
            # Convert to DataFrame for easier manipulation
            df = pd.DataFrame(events)
            df['ts'] = pd.to_datetime(df['ts'], errors='coerce', dayfirst=True)
            df = df.sort_values('ts').reset_index(drop=True)
            
            # Calculate relative time from first measurement
            df['minutes_from_start'] = (df['ts'] - df['ts'].iloc[0]).dt.total_seconds() / 60
            
            # Extract date for grouping by day
            df['date_only'] = df['ts'].dt.date
            
            # Prepare glucose values (stored as strings in XML)
            col2 = pd.to_numeric(df['value'], errors='coerce')
            col3 = df['minutes_from_start']
            
            # Get unique dates for button creation
            unique_dates = df['date_only'].unique()

            # Create grid of date buttons
            button_frame = ttk.Frame(self)
            button_frame.pack(pady=20)
            buttons_per_row = 6  # 6 buttons per row for compact display

            # Create one button per day with data
            for i, date in enumerate(unique_dates):
                row = i // buttons_per_row
                col = i % buttons_per_row
                ttk.Button(
                    button_frame,
                    text=date.strftime("%Y-%m-%d"),
                    # Pass day index to plotting function
                    command=lambda d=i: self.plot_day(df, col2, col3, d),
                    width=15
                ).grid(row=row, column=col, padx=5, pady=5, sticky="nsew")

            # Configure grid columns to expand evenly
            for c in range(buttons_per_row):
                button_frame.grid_columnconfigure(c, weight=1)

            # ===== FULL TIMELINE BUTTON =====
            full_btn_frame = ttk.Frame(self)
            full_btn_frame.pack(pady=10)
            
            ttk.Button(
                full_btn_frame,
                text="Show Full Timeline",
                command=lambda rk=root_key: self.show_full(rk),
                width=20
            ).pack()

            # ===== UNIT TOGGLE BUTTON =====
            ttk.Button(
                full_btn_frame,
                text=f"Setting: {self.glucose_unit}",
                command=self.toggle_glucose_unit,
                width=20
            ).pack(pady=5)

            return  # Skip text view for glucose data

        # ===== STANDARD HANDLING: OTHER EVENT TYPES =====
        # Display events in a formatted text table
        df = pd.DataFrame(events)
        
        # Create scrollable text widget
        text_frame = ttk.Frame(self)
        text_frame.pack(fill="both", expand=True, padx=20, pady=20)
        scrollbar = ttk.Scrollbar(text_frame)
        scrollbar.pack(side="right", fill="y")
        text_widget = tk.Text(text_frame, yscrollcommand=scrollbar.set, wrap="none", height=25)
        text_widget.pack(fill="both", expand=True)
        scrollbar.config(command=text_widget.yview)

        # Format varies by event type
        if root_key == "basal":
            # Basal insulin: timestamp and rate
            df['ts'] = pd.to_datetime(df['ts'], dayfirst=True, errors='coerce')
            text_widget.insert("end", f"{'Timestamp':<25} {'Value (U)':<10}\n")
            text_widget.insert("end", "-"*40 + "\n")
            for _, row in df.iterrows():
                ts = row['ts'].strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(row['ts']) else ''
                text_widget.insert("end", f"{ts:<25} {row['value']:<10}\n")

        elif root_key == "bolus":
            # Bolus insulin: start, end, dose, type, duration
            df['ts_begin'] = pd.to_datetime(df['ts_begin'], dayfirst=True, errors='coerce')
            df['ts_end'] = pd.to_datetime(df['ts_end'], dayfirst=True, errors='coerce')
            text_widget.insert("end", f"{'Begin':<20} {'End':<20} {'Dose':<8} {'Type':<20} {'Duration (min)':<15}\n")
            text_widget.insert("end", "-"*90 + "\n")
            for _, row in df.iterrows():
                begin = row['ts_begin'].strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(row['ts_begin']) else ''
                end = row['ts_end'].strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(row['ts_end']) else ''
                # Calculate dose duration
                duration = (row['ts_end'] - row['ts_begin']).total_seconds() / 60 if not pd.isna(row['ts_end']) and not pd.isna(row['ts_begin']) else 0
                text_widget.insert("end", f"{begin:<20} {end:<20} {row['dose']:<8} {row['type']:<20} {duration:<15.1f}\n")

        elif root_key == "meal":
            # Meals: timestamp, type, carbs
            df['ts'] = pd.to_datetime(df['ts'], dayfirst=True, errors='coerce')
            text_widget.insert("end", f"{'Timestamp':<25} {'Meal Type':<15} {'Carbs (g)':<10}\n")
            text_widget.insert("end", "-"*50 + "\n")
            for _, row in df.iterrows():
                ts = row['ts'].strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(row['ts']) else ''
                text_widget.insert("end", f"{ts:<25} {row['type']:<15} {row['carbs']:<10}\n")

        elif root_key == "exercise":
            # Exercise: timestamp, intensity, duration
            df['ts'] = pd.to_datetime(df['ts'], dayfirst=True, errors='coerce')
            text_widget.insert("end", f"{'Timestamp':<25} {'Intensity':<10} {'Duration (min)':<15}\n")
            text_widget.insert("end", "-"*50 + "\n")
            for _, row in df.iterrows():
                ts = row['ts'].strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(row['ts']) else ''
                text_widget.insert("end", f"{ts:<25} {row['intensity']:<10} {row['duration']:<15}\n")

        elif root_key == "sleep":
            # Sleep: start, end, quality, duration
            df['ts_begin'] = pd.to_datetime(df['ts_begin'], dayfirst=True, errors='coerce')
            df['ts_end'] = pd.to_datetime(df['ts_end'], dayfirst=True, errors='coerce')
            text_widget.insert("end", f"{'Begin':<20} {'End':<20} {'Quality':<10} {'Duration (h)':<12}\n")
            text_widget.insert("end", "-"*70 + "\n")
            for _, row in df.iterrows():
                begin = row['ts_begin']
                end = row['ts_end']
                # Fix overnight sleep (end time < begin time)
                if end < begin:
                    end += pd.Timedelta(days=1)
                begin_str = begin.strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(begin) else ''
                end_str = end.strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(end) else ''
                duration = (end - begin).total_seconds() / 3600  # Convert to hours
                text_widget.insert("end", f"{begin_str:<20} {end_str:<20} {row['quality']:<10} {duration:<12.2f}\n")

        # Make text read-only (can still scroll and select)
        text_widget.config(state="disabled")

    # ================================================================
    # VISUALIZATION - SINGLE DAY PLOT
    # ================================================================

    def plot_day(self, df, col2, col3, day_index):
        """
        Plot glucose levels for a specific day with hypoglycemic events highlighted.
        
        Creates a line plot showing glucose throughout the day with:
        - Blue line connecting glucose measurements
        - Red horizontal line at hypoglycemia threshold (70 mg/dL or 3.9 mmol/L)
        - Black horizontal line at hyperglycemia threshold (180 mg/dL or 10.0 mmol/L)
        - Green square markers for recorded hypoglycemic events
        
        Args:
            df (pd.DataFrame): Complete DataFrame with all glucose data
            col2 (pd.Series): Glucose values (currently unused, kept for API compatibility)
            col3 (pd.Series): Minutes from start (currently unused)
            day_index (int): Index of the day to plot in the unique dates array
            
        Display:
            - X-axis: Time of day in HH:MM format (00:00 to 24:00)
            - Y-axis: Glucose level in current unit (mg/dL or mmol/L)
            - Shows in matplotlib window
        """
        # Get the specific date to plot
        date = df['date_only'].unique()[day_index]
        
        # Filter DataFrame to this day only
        mask = df['date_only'] == date
        day_df = df[mask].reset_index(drop=True)

        # Get glucose values and convert to current unit
        day_col2_raw = pd.to_numeric(day_df['value'], errors='coerce')  # Raw mg/dL values
        day_col2 = day_col2_raw.apply(self.convert_glucose_value)  # Convert if needed
        day_times = day_df['ts'].dt.time  # Extract time of day

        # Convert times to datetime objects for plotting
        # Use arbitrary date (2025-01-01) since we only care about time of day
        plot_times = [datetime(2025, 1, 1, t.hour, t.minute, t.second) for t in day_times]

        # ===== FIND HYPOGLYCEMIC EVENTS FOR THIS DAY =====
        events_hypo = self.data_roots.get("hypo_event", [])
        if events_hypo:
            df_hypo = pd.DataFrame(events_hypo)
            df_hypo['ts'] = pd.to_datetime(df_hypo['ts'], errors='coerce', dayfirst=True)
            df_hypo = df_hypo.sort_values('ts').reset_index(drop=True)
            
            # Filter to this specific day
            df_hypo_day = df_hypo[df_hypo['ts'].dt.date == date]
            
            # Convert hypo event times to plot format
            hypo_times = [datetime(2025, 1, 1, t.hour, t.minute, t.second) for t in df_hypo_day['ts'].dt.time]
            
            # Find glucose values at hypo event times (nearest measurement)
            hypo_values = []
            for t in df_hypo_day['ts']:
                # Find closest glucose measurement to this hypo event
                idx = (day_df['ts'] - t).abs().idxmin()
                hypo_values.append(day_col2.iloc[idx])
        else:
            hypo_times, hypo_values = [], []

        # Get clinical thresholds in current unit
        hypo_threshold, hyper_threshold = self.get_glucose_thresholds()

        # ===== CREATE PLOT =====
        plt.figure(figsize=(10,5))
        
        # Main glucose line plot
        plt.plot(plot_times, day_col2, marker='o', markersize=3, label='Glucose', zorder=3)
        
        # Threshold lines
        plt.axhline(y=hypo_threshold, color='red', linestyle='--', linewidth=1.2, zorder=2)
        plt.axhline(y=hyper_threshold, color='black', linestyle='--', linewidth=1.2, zorder=2)

        # Hypo event markers
        if hypo_times:
            plt.scatter(hypo_times, hypo_values, marker='s', color='green', s=40, label='Hypo event', zorder=10)

        # Labels and formatting
        plt.title(f"Glucose Levels for {date}")
        plt.xlabel("Time of Day")
        plt.ylabel(f"Glucose ({self.glucose_unit})")
        plt.grid(True)
        plt.legend()

        # Format x-axis to show time (HH:MM)
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
        # Set x-axis limits to full day (00:00 to 24:00)
        plt.xlim([datetime(2025,1,1,0,0), datetime(2025,1,2,0,0)])

        plt.tight_layout()
        plt.show()

    # ================================================================
    # VISUALIZATION - FULL TIMELINE PLOT
    # ================================================================

    def show_full(self, root_key="glucose_level"):
        """
        Display the full timeline of glucose or finger stick measurements.
        
        Creates a continuous line plot showing all glucose measurements across
        the entire data collection period (typically several weeks or months).
        
        Features:
        - X-axis: minutes from first measurement (t=0)
        - Y-axis: glucose value in current unit
        - Red horizontal line at hypoglycemia threshold
        - Black horizontal line at hyperglycemia threshold
        - Green square markers for all hypoglycemic events
        
        Args:
            root_key (str): Type of measurement ('glucose_level' or 'finger_stick')
            
        Display:
            Shows an info message if no data is available.
            Opens matplotlib window with the full timeline plot.
        """
        # Get events for specified type
        events = self.data_roots.get(root_key, [])
        if not events:
            messagebox.showinfo("Info", f"No data available for {root_key}.")
            return

        # Convert to DataFrame and prepare data
        df = pd.DataFrame(events)
        df['ts'] = pd.to_datetime(df['ts'], errors='coerce', dayfirst=True)
        df = df.sort_values('ts').reset_index(drop=True)
        
        # Calculate time relative to first measurement
        df['minutes_from_start'] = (df['ts'] - df['ts'].iloc[0]).dt.total_seconds() / 60
        
        # Convert glucose values to current unit
        df['value_raw'] = pd.to_numeric(df['value'], errors='coerce')  # Raw mg/dL
        df['value'] = df['value_raw'].apply(self.convert_glucose_value)  # Convert

        x = df['minutes_from_start']
        y = df['value']

        # ===== FIND ALL HYPOGLYCEMIC EVENTS =====
        events_hypo = self.data_roots.get("hypo_event", [])
        if events_hypo:
            df_hypo = pd.DataFrame(events_hypo)
            df_hypo['ts'] = pd.to_datetime(df_hypo['ts'], errors='coerce', dayfirst=True)
            df_hypo = df_hypo.sort_values('ts').reset_index(drop=True)

            hypo_times = []
            hypo_values = []
            
            # For each hypo event, find corresponding glucose measurement
            for t in df_hypo['ts']:
                # Check if event is within glucose data timeframe
                if df['ts'].iloc[0] <= t <= df['ts'].iloc[-1]:
                    # Find nearest glucose measurement
                    idx = (df['ts'] - t).abs().idxmin()
                    hypo_times.append(df['minutes_from_start'].iloc[idx])
                    hypo_values.append(df['value'].iloc[idx])
        else:
            hypo_times, hypo_values = [], []

        # Get clinical thresholds in current unit
        hypo_threshold, hyper_threshold = self.get_glucose_thresholds()

        # ===== CREATE PLOT =====
        plt.figure(figsize=(12,6))
        
        # Main glucose line plot
        plt.plot(x, y, marker='o', markersize=3, label='Glucose', zorder=3)
        
        # Threshold lines
        plt.axhline(y=hypo_threshold, color='red', linestyle='--', linewidth=1.2, zorder=2)
        plt.axhline(y=hyper_threshold, color='black', linestyle='--', linewidth=1.2, zorder=2)

        # Hypo event markers
        if hypo_times:
            plt.scatter(hypo_times, hypo_values, marker='s', color='green', s=40, label='Hypo event', zorder=10)

        # Labels and formatting
        plt.title(f"Full {root_key.replace('_',' ').title()} Timeline")
        plt.xlabel("Minutes from start")
        plt.ylabel(f"Glucose ({self.glucose_unit})")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()

    # ================================================================
    # PREDICTION PAGE (PLACEHOLDER)
    # ================================================================

    def predict_page(self):
        """
        Display the prediction page (currently a placeholder).
        
        This page is intended for future functionality to:
        - Predict nighttime glucose levels
        - Estimate hypoglycemia/hyperglycemia risk
        - Recommend insulin dosing adjustments
        - Provide meal timing suggestions
        
        Currently shows only a title and back button.
        
        Navigation:
            - Back button returns to selection page
            - Adds selection_page to navigation stack
        """
        self.clear_window()
        self.page_history.append(self.selection_page)
        
        # Back button
        ttk.Button(self, text="← Back", command=self.selection_page).pack(anchor="w", padx=20, pady=20)
        
        # Placeholder title
        ttk.Label(self, text="Predict Page", font=("Arial", 20)).pack(pady=100)
    


# ================================================================
# APPLICATION ENTRY POINT
# ================================================================

if __name__ == "__main__":
    """
    Start the Digital Twin for Diabetes GUI application.
    
    Creates the main window and enters the Tkinter event loop.
    The application will run until the user closes the window or clicks Exit.
    """
    app = DiabetesTwinGUI()
    app.mainloop()