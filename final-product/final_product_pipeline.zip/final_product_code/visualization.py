"""
Visualization Module
Creates plots and figures for model evaluation and analysis.

This module provides utilities for:
- Visualizing glucose trajectory predictions with uncertainty bands
- Creating feature importance plots for XGBoost models
- Generating performance metrics visualizations (ROC, PR curves)
- Displaying confusion matrices with heatmaps
- Comparing model performance across different thresholds

All visualizations are saved to disk and optionally displayed based on
the SHOW_PLOTS configuration (config.py) setting.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.metrics import (
    roc_curve, precision_recall_curve, confusion_matrix,
    accuracy_score, precision_score, recall_score, f1_score
)

from config import SHOW_PLOTS, HYPO_THRESHOLD, HYPER_THRESHOLD


# ================================================================
# TRAJECTORY VISUALIZATION
# ================================================================

def plot_predicted_trajectory_with_actual(predicted_traj, actual_glucose, p_hypo, p_hyper, 
                                         true_hypo, true_hyper, date, night_start_time, 
                                         save_dir, patient_id):
    """
    Create enhanced visualization comparing predicted and actual glucose trajectories.
    
    Generates a comprehensive two-panel figure showing:
        - Top panel: Glucose trajectory over time with actual CGM readings vs ODE predictions,
          including uncertainty bands, risk zones, and event highlighting
        - Bottom panel: Horizontal bar chart of predicted hypoglycemia and hyperglycemia 
          probabilities with decision thresholds
    
    The visualization uses hour-based x-axis formatting for improved readability and includes
    multiple visual cues for risk assessment:
        - Red zone and threshold line for hypoglycemia (<70 mg/dL)
        - Orange zone and threshold line for hyperglycemia (>180 mg/dL)
        - Uncertainty band based on residual standard deviation
        - Special markers for actual hypoglycemic events (red X markers)
    
    Visual elements:
        - Blue line with circles: Actual CGM measurements
        - Green dashed line: ODE model predictions
        - Green shaded band: Model uncertainty (±1 std)
        - Red shaded area: Hypoglycemia risk zone (<70 mg/dL)
        - Orange shaded area: Hyperglycemia risk zone (>180 mg/dL)
        - Red X markers: Actual hypoglycemic events
    
    Parameters:
        predicted_traj (tuple): Predicted glucose trajectory as (times, glucose_values) where
            times is a list of datetime objects and glucose_values is a list of floats (mg/dL)
        actual_glucose (list of tuples): Actual CGM measurements as 
            [(timestamp, value_mg_dL), ...]
        p_hypo (float): Predicted hypoglycemia probability [0, 1]
        p_hyper (float): Predicted hyperglycemia probability [0, 1]
        true_hypo (int): Ground truth hypoglycemia label (0 or 1)
        true_hyper (int): Ground truth hyperglycemia label (0 or 1)
        date (datetime.date or str): Date of the night for plot title and filename
        night_start_time (datetime): Start time of the night period for time axis reference
        save_dir (str or Path): Directory to save the figure
        patient_id (str or int): Patient identifier for filename
        
    Returns:
        Saves figure to save_dir/{patient_id}_night_{date}.png and optionally displays
            based on SHOW_PLOTS flag
    """
    # Unpack predicted trajectory
    times_sim, G_sim = predicted_traj
    
    # Convert all timestamps to hours from night start for consistent x-axis
    # This makes the plot easier to read (e.g., "02:00" instead of absolute time)
    t_sim_hours = [(ts - night_start_time).total_seconds() / 3600.0 for ts in times_sim]
    t_actual_hours = [(ts - night_start_time).total_seconds() / 3600.0 for ts, _ in actual_glucose]
    G_actual = [val for _, val in actual_glucose]
    
    # Create figure with two panels (3:1 height ratio)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 9), height_ratios=[3, 1])
    
    # ===== TOP PANEL: GLUCOSE TRAJECTORY =====
    
    # Plot actual CGM measurements (blue line with circles)
    ax1.plot(t_actual_hours, G_actual, 'o-', label="Actual CGM", color='blue', 
             alpha=0.8, markersize=4, linewidth=2)
    
    # Plot predicted glucose trajectory (green dashed line)
    ax1.plot(t_sim_hours, G_sim, '--', label="Predicted (ODE)", color='green', linewidth=2.5)
    
    # Add uncertainty band based on prediction errors
    if len(t_actual_hours) > 5:
        # Interpolate actual glucose to prediction time points
        G_interp = np.interp(t_sim_hours, t_actual_hours, G_actual)
        # Calculate residuals (errors)
        residuals = G_interp - G_sim
        # Use standard deviation as uncertainty measure
        residual_std = np.std(residuals)
        # Plot ±1 std band around prediction
        ax1.fill_between(t_sim_hours, G_sim - residual_std, G_sim + residual_std, 
                        color='green', alpha=0.2, label=f'Uncertainty (±{residual_std:.1f} mg/dL)')
    
    # Add clinical threshold lines
    ax1.axhline(70, color='red', linestyle='--', linewidth=2.5, label="Hypo threshold (<70)")
    ax1.axhline(180, color='orange', linestyle='--', linewidth=2.5, label="Hyper threshold (>180)")
    
    # Add risk zone shading
    # Red zone below 70 mg/dL (hypoglycemia danger zone)
    ax1.fill_between(t_sim_hours, 0, 70, color='red', alpha=0.08)
    # Orange zone above 180 mg/dL (hyperglycemia danger zone)
    ax1.fill_between(t_sim_hours, 180, 400, color='orange', alpha=0.08)
    
    # Highlight actual hypoglycemic events with special markers
    actual_hypo = np.array(G_actual) < 70
    if np.any(actual_hypo):
        # Extract times and values of hypoglycemic events
        hypo_times = [t_actual_hours[i] for i in range(len(actual_hypo)) if actual_hypo[i]]
        hypo_values = [G_actual[i] for i in range(len(actual_hypo)) if actual_hypo[i]]
        # Plot as red X markers with dark red edges for visibility
        ax1.scatter(hypo_times, hypo_values, 
                   color='red', s=100, marker='X', zorder=5, 
                   label='Actual Hypo', edgecolors='darkred', linewidths=2)
    
    # Configure x-axis to show hours (00:00, 01:00, 02:00, etc.)
    max_hour = int(np.ceil(max(t_sim_hours)))
    hour_ticks = np.arange(0, max_hour + 1, 1)  # Every hour
    hour_labels = [f"{int(h):02d}:00" for h in hour_ticks]
    
    ax1.set_xticks(hour_ticks)
    ax1.set_xticklabels(hour_labels, fontsize=10)
    ax1.set_xlim(0, max(t_sim_hours))
    
    # Labels and title
    ax1.set_xlabel("Time (hours from midnight)", fontsize=13, fontweight='bold')
    ax1.set_ylabel("Glucose (mg/dL)", fontsize=13, fontweight='bold')
    ax1.set_title(
        f"Night Prediction: {date} | P(Hypo)={p_hypo:.1%} | P(Hyper)={p_hyper:.1%}\n"
        f"Actual: Hypo={bool(true_hypo)} | Hyper={bool(true_hyper)}", 
        fontsize=15, fontweight='bold'
    )
    
    # Legend and grid
    ax1.legend(loc='upper right', fontsize=10, framealpha=0.9)
    ax1.grid(True, alpha=0.3, linestyle=':', linewidth=1)
    ax1.set_ylim(40, 280)  # Focus on typical glucose range
    
    # ===== BOTTOM PANEL: RISK SCORE BARS =====
    
    # Horizontal bar chart showing predicted probabilities
    ax2.barh(0, p_hypo, color='red', alpha=0.8, height=0.4, 
            edgecolor='black', linewidth=1.5)
    ax2.barh(1, p_hyper, color='orange', alpha=0.8, height=0.4, 
            edgecolor='black', linewidth=1.5)
    
    # Add percentage labels on bars
    ax2.text(p_hypo + 0.02, 0, f'{p_hypo:.1%}', va='center', fontsize=11, fontweight='bold')
    ax2.text(p_hyper + 0.02, 1, f'{p_hyper:.1%}', va='center', fontsize=11, fontweight='bold')
    
    # Configure axes
    ax2.set_xlim(0, 1)
    ax2.set_yticks([0, 1])
    ax2.set_yticklabels(['Hypo Risk', 'Hyper Risk'], fontsize=11, fontweight='bold')
    ax2.set_xlabel('Predicted Probability', fontsize=12, fontweight='bold')
    
    # Add decision threshold lines
    ax2.axvline(HYPO_THRESHOLD, color='red', linestyle='--', linewidth=2, alpha=0.6, 
               label=f'Hypo threshold ({HYPO_THRESHOLD:.0%})')
    ax2.axvline(HYPER_THRESHOLD, color='orange', linestyle='--', linewidth=2, alpha=0.6, 
               label=f'Hyper threshold ({HYPER_THRESHOLD:.0%})')
    
    # Grid and legend
    ax2.grid(True, alpha=0.3, axis='x', linestyle=':', linewidth=1)
    ax2.legend(loc='lower right', fontsize=9)
    
    plt.tight_layout()

    # Save figure
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"{patient_id}_night_{date}.png")
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    # Display or close based on configuration
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()


# ================================================================
# FEATURE IMPORTANCE VISUALIZATION
# ================================================================

def plot_feature_importance(trained, feature_names=None, patient_id=None, save_dir=None):
    """
    Visualize XGBoost feature importance for hypo and hyper prediction models.
    
    Generates a two-panel horizontal bar chart showing the top 20 most important
    features for predicting hypoglycemia and hyperglycemia. Correctly handles
    feature selection by mapping selected feature indices back to original
    feature names for interpretability.
    
    Feature importance is measured by XGBoost's gain metric, which quantifies
    the average improvement in prediction accuracy when splitting on each feature.
    Higher values indicate features that are more critical to model decisions.
    
    Parameters:
        trained (dict): Dictionary of trained models, containing keys:
            'clf_hypo' (XGBClassifier): Trained hypoglycemia classifier
            'clf_hyper' (XGBClassifier): Trained hyperglycemia classifier
            'top_features_hypo' (numpy.ndarray or None): Indices of selected features for hypo
            'top_features_hyper' (numpy.ndarray or None): Indices of selected features for hyper
        feature_names (list of str, optional): Names for all features in order. If None,
            calls get_feature_names_with_residuals() to generate names. Default: None
        patient_id (str or int, optional): Patient identifier for filename and plot titles.
            If provided, creates patient-specific output. Default: None
        save_dir (str or Path, optional): Directory to save the plot. Default: None
        
    Returns:
        Saves figure to save_dir/feature_importance[_patient_{patient_id}].png,
            optionally displays based on SHOW_PLOTS flag, and prints confirmation message
    """
    # Import feature names generator if not provided
    from feature_engineering import get_feature_names_with_residuals
    
    if feature_names is None:
        feature_names = get_feature_names_with_residuals()
    
    # Create save directory
    os.makedirs(save_dir, exist_ok=True)
    
    # Generate filename (patient-specific if ID provided)
    if patient_id is not None:
        filename = f"feature_importance_patient_{patient_id}.png"
    else:
        filename = "feature_importance.png"
    
    save_path = os.path.join(save_dir, filename)
    
    # Create two-panel figure
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    
    # ===== LEFT PANEL: HYPOGLYCEMIA FEATURES =====
    importance_hypo = trained["clf_hypo"].feature_importances_
    
    # Handle case where feature selection was used
    if trained.get("top_features_hypo") is not None:
        # Get original feature indices from selected subset
        selected_indices = trained["top_features_hypo"]
        # Get top 20 features within selected subset (by relative importance)
        indices_hypo_relative = np.argsort(importance_hypo)[-20:]
        # Map back to original feature space
        original_indices_hypo = [selected_indices[i] for i in indices_hypo_relative]
        # Get feature names from original space
        names_to_plot_hypo = [feature_names[i] for i in original_indices_hypo]
        # Get importance values
        importance_to_plot_hypo = importance_hypo[indices_hypo_relative]
    else:
        # No feature selection: use all features
        indices_hypo_relative = np.argsort(importance_hypo)[-20:]
        names_to_plot_hypo = [feature_names[i] for i in indices_hypo_relative]
        importance_to_plot_hypo = importance_hypo[indices_hypo_relative]
    
    # Create horizontal bar chart
    axes[0].barh(range(20), importance_to_plot_hypo, color='red', alpha=0.7, 
                edgecolor='black', linewidth=1)
    axes[0].set_xlabel('Feature Importance', fontsize=12, fontweight='bold')
    
    # Add patient ID to title if provided
    title_hypo = 'Top 20 Features for Hypoglycemia Prediction'
    if patient_id is not None:
        title_hypo += f'\nPatient {patient_id}'
    axes[0].set_title(title_hypo, fontsize=14, fontweight='bold')
    
    # Set feature names as y-tick labels
    axes[0].set_yticks(range(20))
    axes[0].set_yticklabels(names_to_plot_hypo, fontsize=9)
    axes[0].grid(alpha=0.3, axis='x')
    
    # ===== RIGHT PANEL: HYPERGLYCEMIA FEATURES =====
    importance_hyper = trained["clf_hyper"].feature_importances_
    
    # Handle case where feature selection was used
    if trained.get("top_features_hyper") is not None:
        selected_indices = trained["top_features_hyper"]
        indices_hyper_relative = np.argsort(importance_hyper)[-20:]
        original_indices_hyper = [selected_indices[i] for i in indices_hyper_relative]
        names_to_plot_hyper = [feature_names[i] for i in original_indices_hyper]
        importance_to_plot_hyper = importance_hyper[indices_hyper_relative]
    else:
        indices_hyper_relative = np.argsort(importance_hyper)[-20:]
        names_to_plot_hyper = [feature_names[i] for i in indices_hyper_relative]
        importance_to_plot_hyper = importance_hyper[indices_hyper_relative]
    
    # Create horizontal bar chart
    axes[1].barh(range(20), importance_to_plot_hyper, color='orange', alpha=0.7, 
                edgecolor='black', linewidth=1)
    axes[1].set_xlabel('Feature Importance', fontsize=12, fontweight='bold')
    
    # Add patient ID to title if provided
    title_hyper = 'Top 20 Features for Hyperglycemia Prediction'
    if patient_id is not None:
        title_hyper += f'\nPatient {patient_id}'
    axes[1].set_title(title_hyper, fontsize=14, fontweight='bold')
    
    # Set feature names as y-tick labels
    axes[1].set_yticks(range(20))
    axes[1].set_yticklabels(names_to_plot_hyper, fontsize=9)
    axes[1].grid(alpha=0.3, axis='x')
    
    plt.tight_layout()
    
    # Save figure
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    # Display or close based on configuration
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()
    
    print(f"  Feature importance plot saved: {save_path}")


# ================================================================
# AGGREGATE PERFORMANCE VISUALIZATIONS
# ================================================================

def visualize_metrics(summary, save_dir):
    """
    Generate comprehensive visualization suite for model evaluation.
    
    Creates four key visualizations to assess model performance across
    all test nights:
        1. ROC curves for both hypoglycemia and hyperglycemia
        2. Precision-Recall curves for both conditions
        3. Bar chart comparing metrics (accuracy, precision, recall, F1)
        4. Confusion matrix heatmaps for both conditions
    
    All visualizations are saved to the specified directory and optionally
    displayed based on the SHOW_PLOTS configuration setting.
    
    Thresholds applied:
        - Hypoglycemia: HYPO_THRESHOLD from config (typically 0.2 = 20%)
        - Hyperglycemia: HYPER_THRESHOLD from config (typically 0.5 = 50%)
    
    Parameters:
        summary (list of dict): Evaluation results from evaluate_on_all_nights_with_residuals,
            each containing:
                'true_hypo' (int): Ground truth hypoglycemia label (0 or 1)
                'true_hyper' (int): Ground truth hyperglycemia label (0 or 1)
                'p_hypo' (float): Predicted hypoglycemia probability [0, 1]
                'p_hyper' (float): Predicted hyperglycemia probability [0, 1]
        save_dir (str or Path): Directory to save all visualization figures
        
    Returns:
        Saves all figures to save_dir, displays plots based on SHOW_PLOTS,
            and prints confirmation messages
    """
    # Extract predictions and ground truth from summary
    y_true_hypo = [r['true_hypo'] for r in summary]
    y_score_hypo = [r['p_hypo'] for r in summary]
    y_true_hyper = [r['true_hyper'] for r in summary]
    y_score_hyper = [r['p_hyper'] for r in summary]

    # Create save directory
    os.makedirs(save_dir, exist_ok=True)

    # ===== 1. ROC CURVES =====
    # ROC curve shows trade-off between true positive rate and false positive rate
    plt.figure(figsize=(10,5))
    
    # Compute ROC curves for both conditions
    fpr_hypo, tpr_hypo, _ = roc_curve(y_true_hypo, y_score_hypo)
    fpr_hyper, tpr_hyper, _ = roc_curve(y_true_hyper, y_score_hyper)

    # Plot both ROC curves
    plt.plot(fpr_hypo, tpr_hypo, label="Hypo ROC", linewidth=2)
    plt.plot(fpr_hyper, tpr_hyper, label="Hyper ROC", linewidth=2)
    # Add diagonal reference line (random classifier)
    plt.plot([0,1], [0,1], "k--", linewidth=2, label="Random")
    
    # Labels and formatting
    plt.xlabel("False Positive Rate", fontsize=12, fontweight='bold')
    plt.ylabel("True Positive Rate", fontsize=12, fontweight='bold')
    plt.title("ROC Curves", fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(alpha=0.3)

    # Save figure
    save_path = os.path.join(save_dir, "roc_curves.png")
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    
    # Display or close
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()

    # ===== 2. PRECISION-RECALL CURVES =====
    # PR curve is more informative for imbalanced datasets
    plt.figure(figsize=(10,5))
    
    # Compute PR curves for both conditions
    p_hypo, r_hypo, _ = precision_recall_curve(y_true_hypo, y_score_hypo)
    p_hyper, r_hyper, _ = precision_recall_curve(y_true_hyper, y_score_hyper)

    # Plot both PR curves
    plt.plot(r_hypo, p_hypo, label="Hypo PR curve", linewidth=2)
    plt.plot(r_hyper, p_hyper, label="Hyper PR curve", linewidth=2)
    
    # Labels and formatting
    plt.xlabel("Recall", fontsize=12, fontweight='bold')
    plt.ylabel("Precision", fontsize=12, fontweight='bold')
    plt.title("Precision-Recall Curves", fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(alpha=0.3)

    # Save figure
    save_path = os.path.join(save_dir, "precision_recall_curves.png")
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    
    # Display or close
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()

    # ===== 3. METRICS BAR CHART =====
    # Compare standard classification metrics side-by-side
    
    # Apply thresholds to convert probabilities to binary predictions
    y_pred_hypo = np.array(y_score_hypo) > HYPO_THRESHOLD
    y_pred_hyper = np.array(y_score_hyper) > HYPER_THRESHOLD
    
    # Compute metrics for both conditions
    metrics_names = ["Accuracy", "Precision", "Recall", "F1"]
    hypo_values = [
        accuracy_score(y_true_hypo, y_pred_hypo),
        precision_score(y_true_hypo, y_pred_hypo, zero_division=0),
        recall_score(y_true_hypo, y_pred_hypo, zero_division=0),
        f1_score(y_true_hypo, y_pred_hypo, zero_division=0)
    ]
    hyper_values = [
        accuracy_score(y_true_hyper, y_pred_hyper),
        precision_score(y_true_hyper, y_pred_hyper, zero_division=0),
        recall_score(y_true_hyper, y_pred_hyper, zero_division=0),
        f1_score(y_true_hyper, y_pred_hyper, zero_division=0)
    ]

    # Create grouped bar chart
    x = np.arange(len(metrics_names))
    width = 0.35

    plt.figure(figsize=(10,5))
    plt.bar(x - width/2, hypo_values, width=width, label="Hypo", edgecolor='black')
    plt.bar(x + width/2, hyper_values, width=width, label="Hyper", edgecolor='black')
    
    # Labels and formatting
    plt.xticks(x, metrics_names, fontsize=11)
    plt.ylabel("Score", fontsize=12, fontweight='bold')
    plt.title("Model Metrics Comparison", fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(axis="y", alpha=0.3)
    plt.ylim(0, 1)  # Metrics are all in [0, 1] range

    # Save figure
    save_path = os.path.join(save_dir, "metrics_comparison.png")
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    
    # Display or close
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()

    # ===== 4. CONFUSION MATRICES =====
    # Show classification performance in 2x2 matrix form
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))

    # Hypoglycemia confusion matrix
    cm_hypo = confusion_matrix(y_true_hypo, y_pred_hypo)
    sns.heatmap(cm_hypo, annot=True, fmt="d", cmap="Blues", ax=ax[0], 
               cbar_kws={'label': 'Count'})
    ax[0].set_title("Confusion Matrix – Hypo", fontsize=13, fontweight='bold')
    ax[0].set_xlabel("Predicted", fontsize=11)
    ax[0].set_ylabel("True", fontsize=11)

    # Hyperglycemia confusion matrix
    cm_hyper = confusion_matrix(y_true_hyper, y_pred_hyper)
    sns.heatmap(cm_hyper, annot=True, fmt="d", cmap="Oranges", ax=ax[1], 
               cbar_kws={'label': 'Count'})
    ax[1].set_title("Confusion Matrix – Hyper", fontsize=13, fontweight='bold')
    ax[1].set_xlabel("Predicted", fontsize=11)
    ax[1].set_ylabel("True", fontsize=11)

    plt.tight_layout()
    
    # Save figure
    save_path = os.path.join(save_dir, "confusion_matrices.png")
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    
    # Display or close
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()