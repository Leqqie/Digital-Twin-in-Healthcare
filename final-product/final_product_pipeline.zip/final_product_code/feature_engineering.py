"""
Feature Engineering Module
Generates comprehensive features from time-series glucose data for ML predictions.

This module provides utilities for:
- Computing insulin and carbohydrate on-board using pharmacokinetic models
- Extracting temporal patterns and glucose dynamics from time-series data
- Generating pre-night state features with ODE model quality metrics
- Computing residuals to assess physiological model accuracy
- Creating aggregate night-level features for prediction

Features are designed to capture:
- Physiological state (IOB, COB, glucose levels)
- Temporal patterns (time of day, circadian rhythms)
- Glucose dynamics (rate of change, volatility)
- Model quality (residuals, prediction errors)
- Time-in-range metrics and clinical thresholds
"""

import numpy as np
from datetime import datetime, timedelta

from config import GRID_MIN
from ode_models import predict_glucose_trajectory, estimate_parameters_from_data
from data_processing import extract_pre_night_data


# ================================================================
# TIME-SERIES FEATURES - INSULIN AND CARBOHYDRATE TRACKING
# ================================================================

def calculate_insulin_on_board(t_eval, bolus_min, basal_min):
    """
    Calculate insulin on board (IOB) at each time point using exponential decay.
    
    Models active insulin remaining in the body using pharmacokinetic decay.
    IOB is critical for predicting glucose response to insulin therapy.
    
    The calculation combines:
    1. Bolus insulin: Discrete doses with exponential decay (τ = 180 min)
    2. Basal insulin: Continuous background infusion as steady-state IOB
    
    Decay model:
        IOB(t) = dose * exp(-Δt / τ)
        where Δt = time since administration, τ = 180 minutes (3 hours)
    
    This 180-minute half-life approximates rapid-acting insulin pharmacokinetics.
    
    Parameters:
        t_eval (array): Time points for evaluation (minutes since t0)
        bolus_min (list of tuples): Bolus insulin events as [(time_min, dose_units), ...]
        basal_min (list of tuples): Basal rate changes as [(time_min, rate_units_per_hour), ...]
        
    Returns:
        array: Insulin on board (units) at each time in t_eval
    """
    IOB = np.zeros_like(t_eval, dtype=float)
    tau = 180.0  # Time constant for insulin decay (minutes)
    
    for i, t in enumerate(t_eval):
        # Sum contributions from all previous bolus doses
        for tm, dose in bolus_min:
            if t >= tm:  # Only count doses administered before this time
                dt = t - tm  # Time since dose
                IOB[i] += dose * np.exp(-dt / tau)  # Exponential decay
        
        # Add basal insulin contribution
        # Find the most recent basal rate change
        current_basal = 0.0
        for tm, rate in basal_min:
            if t >= tm:
                current_basal = rate  # Units per hour
        
        # Convert basal rate to steady-state IOB
        # At steady state: IOB = rate * τ / 60 (converting hours to minutes)
        IOB[i] += current_basal * tau / 60.0
    
    return IOB


def calculate_carbs_on_board(t_eval, meals_min):
    """
    Calculate carbohydrates on board (COB) at each time point using exponential decay.
    
    Models remaining carbohydrates still being absorbed from the gut using
    exponential decay to approximate gastric emptying and glucose appearance.
    
    COB helps predict future glucose rise from meals and is essential for
    meal-related hypoglycemia/hyperglycemia prediction.
    
    Decay model:
        COB(t) = carbs * exp(-Δt / τ)
        where Δt = time since meal, τ = 180 minutes (3 hours)
    
    This 180-minute time constant represents typical carbohydrate absorption,
    though actual rates vary by glycemic index and meal composition.
    
    Parameters:
        t_eval (array): Time points for evaluation (minutes since t0)
        meals_min (list of tuples): Meal events as [(time_min, carbs_grams), ...]
        
    Returns:
        array: Carbohydrates on board (grams) at each time in t_eval
    """
    COB = np.zeros_like(t_eval, dtype=float)
    tau = 180.0  # Time constant for carb absorption (minutes)
    
    for i, t in enumerate(t_eval):
        # Sum contributions from all previous meals
        for tm, carbs in meals_min:
            if t >= tm:  # Only count meals consumed before this time
                dt = t - tm  # Time since meal
                COB[i] += carbs * np.exp(-dt / tau)  # Exponential decay
    
    return COB


def calculate_recent_insulin(t_eval, bolus_min, basal_min, window=30.0):
    """
    Calculate total insulin administered within a recent time window.
    
    Sums all insulin delivered (both bolus and basal) within a sliding window
    before each evaluation point. This captures short-term insulin activity
    patterns distinct from the longer-term IOB metric.
    
    Useful for detecting:
    - Recent aggressive insulin corrections (hypoglycemia risk)
    - Insulin stacking patterns
    - Rapid changes in insulin therapy
    
    Parameters:
        t_eval (array): Time points for evaluation (minutes since t0)
        bolus_min (list of tuples): Bolus insulin events as [(time_min, dose_units), ...]
        basal_min (list of tuples): Basal rate changes as [(time_min, rate_units_per_hour), ...]
        window (float, optional): Look-back window in minutes (default: 30.0)
        
    Returns:
        array: Total insulin units delivered in the window before each time in t_eval
    """
    recent = np.zeros_like(t_eval, dtype=float)
    
    for i, t in enumerate(t_eval):
        # Sum all bolus doses within the window
        for tm, dose in bolus_min:
            # Check if dose falls within the time window
            if 0 <= (t - tm) <= window:
                recent[i] += dose
        
        # Add basal insulin delivered during the window
        # Find current basal rate
        current_basal = 0.0
        for tm, rate in basal_min:
            if t >= tm:
                current_basal = rate  # Units per hour
        
        # Convert basal rate to units delivered in the window
        recent[i] += (current_basal * window) / 60.0
    
    return recent


# ================================================================
# TIME-SERIES FEATURES - COMPREHENSIVE GLUCOSE DYNAMICS
# ================================================================

def create_features(t_eval, G_pred, IOB, COB, recent_insulin,
                    t0, meals_min, bolus_min):
    """
    Create comprehensive feature matrix for glucose prediction modeling.
    
    Generates 32 engineered features at each time point capturing multiple
    aspects of glucose dynamics and physiological state:
    
    Feature categories (indices):
        [0-2]:   Time of day (raw, sin, cos) - circadian patterns
        [3-6]:   Glucose lags (1, 3, 6, 12 steps) - temporal dependencies
        [7-9]:   Rate of change and acceleration - glucose momentum
        [10-12]: Statistical summaries (mean, std, range) - recent variability
        [13-16]: IOB, COB, recent insulin, IOB*ROC interaction - treatment effects
        [17-18]: Time since last meal and bolus - event timing
        [19-20]: Last meal size and weighted COB - meal impact
        [21-22]: Circadian indicators (dawn, night) - biological rhythms
        [23-25]: Glucose zone indicators (hypo, target, hyper) - clinical state
        [26-27]: Volatility and ROC sign - stability metrics
        [28-30]: Time in range metrics (TIR, below, above) - glycemic control
        [31]:    Normalized glucose - scaled value
    
    These features are designed to work with XGBoost and capture nonlinear
    relationships between glucose, insulin, meals, and time patterns.
    
    Parameters:
        t_eval (array): Time points for evaluation (minutes since t0)
        G_pred (array): Predicted glucose values (mg/dL) at each time
        IOB (array): Insulin on board (units) at each time
        COB (array): Carbohydrates on board (grams) at each time
        recent_insulin (array): Recent insulin administered (units) at each time
        t0 (datetime): Start time of the evaluation period (reference point)
        meals_min (list of tuples): Meal events as [(time_min, carbs_grams), ...]
        bolus_min (list of tuples): Bolus insulin events as [(time_min, dose_units), ...]
        
    Returns:
        array: Feature matrix of shape (len(t_eval), 32)
    """
    n = len(t_eval)
    F = np.zeros((n, 32), dtype=float)

    for i in range(n):
        # Calculate current absolute time
        current_time = t0 + timedelta(minutes=float(t_eval[i]))
        tod = current_time.hour + current_time.minute / 60.0  # Time of day in hours

        # ===== TEMPORAL FEATURES [0-2] =====
        # Encode time of day with trigonometric functions to capture circular nature
        F[i, 0] = tod  # Raw hour (0-24)
        F[i, 1] = np.sin(2 * np.pi * tod / 24.0)  # Sine encoding (24-hour cycle)
        F[i, 2] = np.cos(2 * np.pi * tod / 24.0)  # Cosine encoding (ensures continuity at midnight)

        # ===== GLUCOSE LAGS [3-6] =====
        # Historical glucose values at different time lags
        # These capture autoregressive patterns in glucose dynamics
        F[i, 3] = G_pred[max(0, i-1)]   # 1 step back (5 min ago)
        F[i, 4] = G_pred[max(0, i-3)]   # 3 steps back (15 min ago)
        F[i, 5] = G_pred[max(0, i-6)]   # 6 steps back (30 min ago)
        F[i, 6] = G_pred[max(0, i-12)]  # 12 steps back (60 min ago)

        # ===== GLUCOSE DYNAMICS [7-9] =====
        # Rate of change (ROC) and acceleration capture glucose momentum
        # ROC over 5 minutes (short-term trend)
        F[i, 7] = (G_pred[i] - G_pred[i-1]) / GRID_MIN if i > 0 else 0.0
        
        # ROC over 30 minutes (medium-term trend)
        F[i, 8] = (G_pred[i] - G_pred[i-6]) / 30.0 if i > 5 else 0.0
        
        # Acceleration (change in ROC) - captures whether glucose is accelerating or decelerating
        F[i, 9] = F[i, 7] - (G_pred[i-1] - G_pred[i-2]) / GRID_MIN if i > 1 else 0.0

        # ===== STATISTICAL SUMMARIES [10-12] =====
        # Statistics over last hour (up to 12 time steps)
        recent = G_pred[max(0, i-12):i+1]
        F[i, 10] = np.mean(recent)  # Average glucose
        F[i, 11] = np.std(recent)   # Variability
        F[i, 12] = np.max(recent) - np.min(recent) if len(recent) > 1 else 0.0  # Range

        # ===== TREATMENT EFFECTS [13-16] =====
        F[i, 13] = IOB[i]           # Insulin on board
        F[i, 14] = COB[i]           # Carbs on board
        F[i, 15] = recent_insulin[i]  # Recent insulin dose
        F[i, 16] = IOB[i] * F[i, 7]   # Interaction: IOB * ROC (captures insulin-glucose dynamics)

        # ===== TIME SINCE EVENTS [17-18] =====
        # Time since last meal (important for predicting meal-related glucose changes)
        tsm = 1000.0  # Initialize with large value
        last_size = 0.0
        for tm, carbs in meals_min:
            if t_eval[i] >= tm:
                dt = t_eval[i] - tm
                if dt < tsm:
                    tsm = dt
                    last_size = carbs
        F[i, 17] = tsm  # Minutes since last meal

        # Time since last bolus (important for insulin action timing)
        tsb = 1000.0
        for tm, dose in bolus_min:
            if t_eval[i] >= tm:
                dt = t_eval[i] - tm
                tsb = min(tsb, dt)
        F[i, 18] = tsb  # Minutes since last bolus

        # ===== MEAL IMPACT [19-20] =====
        F[i, 19] = last_size  # Size of last meal (grams of carbs)
        # Weighted COB: decays faster to capture recent meal impact
        F[i, 20] = COB[i] * np.exp(-tsm / 120.0) if tsm < 1000 else 0.0

        # ===== CIRCADIAN INDICATORS [21-22] =====
        # Binary indicators for known circadian patterns
        F[i, 21] = 1.0 if 4 <= current_time.hour < 8 else 0.0  # Dawn phenomenon (4am-8am)
        F[i, 22] = 1.0 if current_time.hour >= 22 or current_time.hour < 2 else 0.0  # Late night

        # ===== GLUCOSE ZONES [23-25] =====
        # Binary indicators for clinical glucose ranges
        F[i, 23] = 1.0 if G_pred[i] < 70 else 0.0        # Hypoglycemia (<70 mg/dL)
        F[i, 24] = 1.0 if 70 <= G_pred[i] <= 180 else 0.0  # Target range
        F[i, 25] = 1.0 if G_pred[i] > 180 else 0.0       # Hyperglycemia (>180 mg/dL)

        # ===== VOLATILITY [26] =====
        # Standard deviation of recent rates of change
        if i >= 6:
            recent_roc = [(G_pred[j] - G_pred[j-1]) / GRID_MIN for j in range(i-5, i+1)]
            F[i, 26] = np.std(recent_roc)  # Higher = more erratic glucose changes
        else:
            F[i, 26] = 0.0

        # ===== ROC SIGN [27] =====
        # Direction of glucose change: -1 (falling), 0 (stable), +1 (rising)
        F[i, 27] = np.sign(F[i, 7])

        # ===== TIME IN RANGE METRICS [28-30] =====
        # Proportion of recent measurements in each clinical range
        tir = np.mean((recent >= 70) & (recent <= 180))  # Time in range
        below = np.mean(recent < 70)                      # Time below range
        above = np.mean(recent > 180)                     # Time above range
        F[i, 28] = tir
        F[i, 29] = below
        F[i, 30] = above

        # ===== NORMALIZED GLUCOSE [31] =====
        # Scale glucose to approximately 0-1 range (dividing by typical target of 150)
        F[i, 31] = G_pred[i] / 150.0

    return F


# ================================================================
# AGGREGATE NIGHT-LEVEL FEATURES
# ================================================================

def night_level_features(t_eval, features, G_pred, cutoff_min=60):
    """
    Extract aggregate night-level features without data leakage.
    
    Computes summary statistics over a limited time window at the beginning
    of the night period to characterize overall night behavior. Uses only the
    first cutoff_min minutes to prevent data leakage (using future information
    to predict the past).
    
    This is critical for the prediction task: we want to predict nighttime
    glucose events using only information available at bedtime (t=0) plus
    a short initial period.
    
    Generates:
    - Mean and std of all 32 time-series features (64 features)
    - 8 additional night-specific glucose dynamics metrics
    Total: 72 features
    
    Parameters:
        t_eval (array): Time points for evaluation (minutes since t0)
        features (array): Time-varying feature matrix of shape (n_times, 32)
        G_pred (array): Predicted glucose values (mg/dL) at each time
        cutoff_min (float, optional): Maximum time window in minutes to use (default: 60)
            Only data from [0, cutoff_min] is used to prevent data leakage
        
    Returns:
        array: Flattened array of aggregate features with length 72
            Returns zeros if insufficient data (<5 samples)
    """
    # Create mask for allowed time window (prevents data leakage)
    mask = t_eval <= cutoff_min

    # Need at least 5 samples for stable statistics
    if mask.sum() < 5:
        # Return zero vector if insufficient data
        return np.zeros(features.shape[1] * 2 + 8)

    # Extract data from allowed time window only
    F = features[mask]  # Features from first cutoff_min minutes
    G = G_pred[mask]    # Glucose from first cutoff_min minutes

    # ===== FEATURE STATISTICS [0-63] =====
    # Mean and std of each of the 32 time-series features
    feat_mean = F.mean(axis=0)  # Average value of each feature
    feat_std = F.std(axis=0)    # Variability of each feature

    # ===== GLUCOSE DYNAMICS [64-71] =====
    # Additional night-specific metrics
    G_min = G.min()        # Minimum glucose during window
    G_max = G.max()        # Maximum glucose during window
    time_hypo = np.mean(G < 70)    # Fraction of time in hypoglycemia
    time_hyper = np.mean(G > 180)  # Fraction of time in hyperglycemia

    # Rate of change statistics
    roc = np.gradient(G) / GRID_MIN  # Compute ROC at each point
    roc_mean = roc.mean()  # Average ROC (overall trend)
    roc_std = roc.std()    # ROC variability (stability)

    # Acceleration statistics (second derivative)
    accel = np.gradient(roc) / GRID_MIN
    accel_mean = accel.mean()  # Average acceleration
    accel_std = accel.std()    # Acceleration variability

    # Concatenate all features into single vector
    return np.concatenate([
        feat_mean,      # 32 features
        feat_std,       # 32 features
        np.array([      # 8 additional features
            G_min, G_max,
            time_hypo, time_hyper,
            roc_mean, roc_std,
            accel_mean, accel_std
        ])
    ])


# ================================================================
# PRE-NIGHT FEATURES WITH ODE MODEL QUALITY METRICS
# ================================================================

def create_pre_night_features_with_residuals(glucose, meals, bolus, basal, historical_residuals=None):
    """
    Build comprehensive feature vector describing patient state before midnight.
    
    Generates a 26-dimensional feature vector combining physiological state,
    glucose dynamics, and ODE model prediction quality for nighttime risk
    prediction.
    
    Feature structure:
    - Original 14 features [0-13]: Physiological state before bedtime
    - Residual 12 features [14-25]: ODE model prediction quality metrics
    
    The residual features are novel and capture how well the physiological
    ODE model has been tracking this patient's glucose historically. This
    provides insight into model uncertainty and systematic biases.
    
    Original 14 features (indices 0-13):
        [0]  Last glucose value (mg/dL)
        [1]  Mean glucose over last hour (mg/dL)
        [2]  Standard deviation of glucose over last hour (mg/dL)
        [3]  Rate of change over last 5 minutes (mg/dL/min)
        [4]  Insulin on board (IOB, units)
        [5]  Carbohydrates on board (COB, grams)
        [6]  Time since last meal (hours)
        [7]  Time since last bolus (hours)
        [8]  Glucose drop over last 30 minutes (mg/dL/min)
        [9]  Minimum glucose over last hour (mg/dL)
        [10] Maximum glucose over last hour (mg/dL)
        [11] Time in range (70-180 mg/dL) for entire day (fraction)
        [12] Time below range (<70 mg/dL) for entire day (fraction)
        [13] Time above range (>180 mg/dL) for entire day (fraction)
    
    Residual-based 12 features (indices 14-25):
        [14] Mean residual - systematic bias (mg/dL)
             Negative = ODE overestimates (hypo risk), Positive = ODE underestimates
        [15] Residual standard deviation - uncertainty (mg/dL)
             High std = ODE is unreliable for this patient
        [16] Minimum residual - worst underestimation by ODE (mg/dL)
        [17] Maximum residual - worst overestimation by ODE (mg/dL)
        [18] 25th percentile residual (mg/dL)
        [19] 75th percentile residual (mg/dL)
        [20] Residual trend - temporal change pattern (mg/dL per sample)
             Negative = ODE increasingly overestimating
        [21] Count of large errors (|residual| > 20 mg/dL)
        [22] Recent residual bias over last hour (mg/dL)
        [23] Residual volatility - error variability (mg/dL)
        [24] Overestimation percentage (residual < -10 mg/dL)
        [25] Underestimation percentage (residual > 10 mg/dL)
    
    Parameters:
        glucose (list of tuples): Glucose measurements from the day before the night
            as [(timestamp, value), ...]
        meals (list of tuples): Meals from the day as [(timestamp, carbs), ...]
        bolus (list of tuples): Bolus doses from the day as [(timestamp, dose), ...]
        basal (list of tuples): Basal rates from the day as [(timestamp, rate), ...]
        historical_residuals (array or None, optional): Array of residuals
            (actual - predicted) from ODE simulation of this day. If None, residual
            features will be set to 0. Default: None
    
    Returns:
        array or None: Feature vector of shape (26,). Returns None if
            insufficient glucose data (< 5 measurements)
    """
    # Need at least 5 glucose measurements for reliable statistics
    if len(glucose) < 5:
        return None

    # Extract glucose values and timestamps
    glucose_vals = np.array([g for _, g in glucose])
    times = [ts for ts, _ in glucose]

    # ===== ORIGINAL 14 FEATURES =====
    
    # Feature 0: Last glucose value (most recent before bedtime)
    last_gluc = glucose_vals[-1]

    # Features 1-2: Statistics from last hour (if available)
    # Assuming 5-minute sampling: 12 samples = 60 minutes
    if len(glucose_vals) >= 12:
        last_hour_vals = glucose_vals[-12:]
    else:
        last_hour_vals = glucose_vals  # Use all available if less than 1 hour

    mean_gluc = last_hour_vals.mean()
    std_gluc = last_hour_vals.std()

    # Feature 3: Rate of change over last 5 minutes
    roc = (glucose_vals[-1] - glucose_vals[-2]) / 5.0 if len(glucose_vals) >= 2 else 0.0

    # Features 4-5: IOB and COB (exponential decay model)
    tau = 180  # Time constant (minutes) for both insulin and carb decay
    t_ref = times[-1]  # Reference time (last measurement)
    
    # Calculate IOB from bolus doses
    IOB = 0.0
    for ts, dose in bolus:
        dt = (t_ref - ts).total_seconds() / 60.0
        if dt > 0:  # Only count doses before reference time
            IOB += dose * np.exp(-dt / tau)
    
    # Calculate COB from meals
    COB = 0.0
    for ts, carbs in meals:
        dt = (t_ref - ts).total_seconds() / 60.0
        if dt > 0:  # Only count meals before reference time
            COB += carbs * np.exp(-dt / tau)

    # Features 6-7: Time since last meal and bolus (in hours)
    last_meal = (t_ref - meals[-1][0]).total_seconds() / 3600.0 if meals else 999.0
    last_bolus = (t_ref - bolus[-1][0]).total_seconds() / 3600.0 if bolus else 999.0

    # Feature 8: Drop over last 30 minutes (rate of change over longer window)
    # Assuming 5-minute sampling: 6 samples = 30 minutes
    if len(glucose_vals) >= 6:
        drop_30 = (glucose_vals[-1] - glucose_vals[-6]) / 30.0
    else:
        drop_30 = 0.0

    # Features 9-10: Min and max over last hour
    min_last_hour = float(last_hour_vals.min())
    max_last_hour = float(last_hour_vals.max())

    # Features 11-13: Time-in-range statistics for the entire day
    tir_day = np.mean((glucose_vals >= 70) & (glucose_vals <= 180))  # Target range
    below_day = np.mean(glucose_vals < 70)   # Hypoglycemia
    above_day = np.mean(glucose_vals > 180)  # Hyperglycemia

    # Combine original features into array
    F_original = np.array([
        last_gluc, mean_gluc, std_gluc, roc, IOB, COB,
        last_meal, last_bolus, drop_30, min_last_hour, max_last_hour,
        tir_day, below_day, above_day 
    ])

    # ===== 12 RESIDUAL-BASED FEATURES =====
    
    if historical_residuals is not None and len(historical_residuals) > 0:
        # Ensure we have a numpy array
        residuals = np.array(historical_residuals)
        
        # Take last 24 hours if available (288 samples at 5-min intervals)
        # Use whatever we have if less
        if len(residuals) > 288:
            recent_residuals = residuals[-288:]
        else:
            recent_residuals = residuals
        
        # Feature 14: Mean residual (systematic bias)
        # Negative = ODE overestimates (predicts high, actual low) → hypo risk
        # Positive = ODE underestimates (predicts low, actual high) → hyper risk
        residual_mean = np.mean(recent_residuals)
        
        # Feature 15: Standard deviation (uncertainty/volatility)
        # High std = ODE predictions are unreliable for this patient
        residual_std = np.std(recent_residuals)
        
        # Feature 16: Minimum residual (worst underestimation by ODE)
        # Large negative = ODE missed a low glucose event
        residual_min = np.min(recent_residuals)
        
        # Feature 17: Maximum residual (worst overestimation by ODE)
        # Large positive = ODE missed a high glucose event
        residual_max = np.max(recent_residuals)
        
        # Features 18-19: Quartiles (distribution shape)
        residual_q1 = np.percentile(recent_residuals, 25)
        residual_q3 = np.percentile(recent_residuals, 75)
        
        # Feature 20: Trend in residuals (is ODE getting better or worse?)
        # Negative slope = residuals becoming more negative = ODE increasingly overestimating
        if len(recent_residuals) > 1:
            residual_trend = np.polyfit(range(len(recent_residuals)), recent_residuals, 1)[0]
        else:
            residual_trend = 0.0
        
        # Feature 21: Count of large errors (how often does ODE fail badly?)
        large_error_count = np.sum(np.abs(recent_residuals) > 20)
        
        # Feature 22: Recent residual bias (last hour only)
        # More responsive to recent changes than overall mean
        if len(recent_residuals) >= 12:  # Last hour (12 * 5min = 60min)
            residual_last_hour = np.mean(recent_residuals[-12:])
        else:
            residual_last_hour = residual_mean
        
        # Feature 23: Volatility of residuals (how erratic are the errors?)
        # High volatility = ODE tracking is poor
        residual_volatility = np.mean(np.abs(np.diff(recent_residuals)))
        
        # Feature 24: Percentage of time ODE overestimates (by >10 mg/dL)
        # High percentage = systematic overestimation = hypo risk
        overestimation_pct = np.sum(recent_residuals < -10) / len(recent_residuals)
        
        # Feature 25: Percentage of time ODE underestimates (by >10 mg/dL)
        # High percentage = systematic underestimation = hyper risk
        underestimation_pct = np.sum(recent_residuals > 10) / len(recent_residuals)
        
        # Combine residual features into array
        F_residual = np.array([
            residual_mean, residual_std, residual_min, residual_max,
            residual_q1, residual_q3, residual_trend, large_error_count,
            residual_last_hour, residual_volatility,
            overestimation_pct, underestimation_pct
        ])
    else:
        # No residuals available: fill with zeros
        F_residual = np.zeros(12)
    
    # ===== COMBINE ALL FEATURES =====
    return np.concatenate([F_original, F_residual])


# ================================================================
# RESIDUAL COMPUTATION FOR HISTORICAL DATA
# ================================================================

def compute_residual_history(glucose_events, meals, bolus, basal, night_segments):
    """
    Compute ODE prediction residuals for all historical day periods.
    
    For each night in the provided segments, simulates the preceding day using
    the physiological ODE model and computes residuals (actual - predicted)
    between CGM measurements and model predictions.
    
    This enables residual-based feature engineering by providing a history of
    how well the ODE model has tracked each patient's glucose, which improves
    nighttime risk prediction.
    
    The simulation process for each day:
        1. Extract pre-night data for the day
        2. Estimate physiological parameters from all data BEFORE this day
        3. Simulate glucose trajectory for the entire day
        4. Compute residuals by comparing simulation to actual CGM readings
        5. Store residuals indexed by night date
    
    Key feature: Parameters estimated from past data only (prevents data leakage)
    
    Parameters:
        glucose_events (list of tuples): All glucose measurements as
            [(timestamp, value_mg_dL), ...]
        meals (list of tuples): All meal events as [(timestamp, carbs_grams), ...]
        bolus (list of tuples): All bolus doses as [(timestamp, dose_units), ...]
        basal (list of tuples): All basal rate changes as
            [(timestamp, rate_units_per_hour), ...]
        night_segments (list of dict): List of night segment dictionaries, each
            containing at minimum a 'date' key
        
    Returns:
        dict: Mapping from datetime.date to array of residuals (mg/dL).
            Keys are night dates, values are arrays of residuals for the
            preceding day. Dates with insufficient data or simulation errors
            are omitted from the dictionary.
    """
    residual_history = {}
    
    # Process each night in the dataset
    for night in night_segments:
        date = night['date']
        
        # Get data from the day before this night
        glucose_day, meals_day, bolus_day, basal_day = extract_pre_night_data(
            glucose_events, meals, bolus, basal, date
        )
        
        # Skip if insufficient glucose data
        if len(glucose_day) < 10:
            continue
        
        # Define time span: previous midnight to current midnight
        # This captures the full day before the night
        t0 = datetime.combine(date - timedelta(days=1), datetime.min.time())
        t_end = datetime.combine(date, datetime.min.time())
        
        if not glucose_day:
            continue
        
        # Initial glucose value for simulation
        G0 = glucose_day[0][1]
        
        # ===== ESTIMATE PARAMETERS FROM PAST DATA ONLY (prevents data leakage) =====
        # Only use data from BEFORE this day to estimate parameters
        glucose_hist = [
            {"time": ts, "value": val} 
            for ts, val in glucose_events if ts < t0
        ]
        meals_hist = [
            {"time": ts, "carbs": c, "gi": 55.0, "type": "unknown"} 
            for ts, c in meals if ts < t0
        ]
        bolus_hist = [
            {"time": ts, "dose": d, "type": "rapid"} 
            for ts, d in bolus if ts < t0
        ]
        
        # If no historical data, use default parameters
        if not glucose_hist:
            from config import PHYSIOLOGICAL_DEFAULTS
            physio_params = PHYSIOLOGICAL_DEFAULTS.copy()
        else:
            # Estimate patient-specific parameters from historical data
            physio_params = estimate_parameters_from_data(
                glucose_hist, meals_hist, bolus_hist
            )
        
        # Format meals and bolus for ODE simulator
        meals_day_formatted = [
            {"time": ts, "carbs": c, "gi": 55.0, "type": "unknown"} 
            for ts, c in meals_day
        ]
        bolus_day_formatted = [
            {"time": ts, "dose": d, "type": "rapid"} 
            for ts, d in bolus_day
        ]
        
        # ===== SIMULATE THE DAY AND COMPUTE RESIDUALS =====
        try:
            # Run ODE simulation for the entire day
            times_sim, G_sim = predict_glucose_trajectory(
                t0, t_end, G0, 
                meals_day_formatted, bolus_day_formatted, 
                physio_params, dt_min=5.0
            )
            
            # Convert timestamps to minutes for interpolation
            t_actual = np.array([(ts - t0).total_seconds() / 60 for ts, _ in glucose_day])
            G_actual = np.array([val for _, val in glucose_day])
            t_sim_min = np.array([(ts - t0).total_seconds() / 60 for ts in times_sim])
            
            # Interpolate simulation to match actual CGM timestamps
            G_pred_interp = np.interp(t_actual, t_sim_min, G_sim)
            
            # Compute residuals: actual - predicted
            # Positive residual = ODE underestimated (predicted too low)
            # Negative residual = ODE overestimated (predicted too high)
            residuals = G_actual - G_pred_interp
            
            # Store residuals for this date
            residual_history[date] = residuals
            
        except Exception as e:
            # Log warning but continue processing other dates
            print(f"    Warning: Could not compute residuals for {date}: {e}")
            continue
    
    return residual_history


# ================================================================
# FEATURE NAMING
# ================================================================

def get_feature_names_with_residuals():
    """
    Generate complete list of feature names including residual-based features.
    
    Constructs human-readable names for all 98 features used in the hybrid
    prediction model. Features are organized into three groups:
    
    1. Pre-night features (26 total):
       - Original 14 physiological state features
       - New 12 residual-based ODE prediction quality features
    
    2. Time-series base features (32 total):
       - Temporal patterns (time of day, glucose lags)
       - Glucose dynamics (ROC, acceleration, statistics)
       - Treatment effects (IOB, COB, recent insulin)
       - Event timing and circadian indicators
       - Glucose zones and volatility metrics
    
    3. Night simulation features (72 total):
       - Mean and standard deviation for each of 32 base features
       - 8 additional night-level glucose dynamics metrics
    
    This naming scheme enables interpretation of feature importance plots and
    helps identify which aspects of patient physiology and ODE model behavior
    drive predictions.
    
    Returns:
        list of str: Ordered list of 98 feature names corresponding to the feature
            matrix columns generated by create_pre_night_features_with_residuals()
            and night_level_features()
    """
    # ===== PRE-NIGHT FEATURES (26) =====
    pre_names = [
        # Original physiological features (14)
        "Last_Glucose", "Mean_Glucose_LastHour", "Std_Glucose_LastHour",
        "ROC_5min", "IOB", "COB", "Time_Since_LastMeal", "Time_Since_LastBolus",
        "Drop_30min", "Min_LastHour", "Max_LastHour", 
        "TIR_Day", "Below_Range_Day", "Above_Range_Day",
        # Residual-based features (12)
        "Residual_Mean", "Residual_Std", "Residual_Min", "Residual_Max",
        "Residual_Q1", "Residual_Q3", "Residual_Trend",
        "Residual_LargeErrors_Count", "Residual_LastHour_Mean",
        "Residual_Volatility", "Residual_Overestimation_Pct", "Residual_Underestimation_Pct"
    ]
    
    # ===== TIME-SERIES BASE FEATURES (32) =====
    ts_base = [
        "TOD", "TOD_sin", "TOD_cos",                    # Temporal
        "G_lag1", "G_lag3", "G_lag6", "G_lag12",        # Glucose history
        "ROC_5min", "ROC_30min", "Accel",               # Dynamics
        "Mean_1hr", "Std_1hr", "Range_1hr",             # Statistics
        "IOB", "COB", "Recent_Insulin", "IOB_ROC_interaction",  # Treatment
        "Time_Since_Meal", "Time_Since_Bolus",          # Event timing
        "Last_Meal_Size", "COB_decay",                  # Meal impact
        "Dawn_effect", "Night_effect",                  # Circadian
        "Zone_Hypo", "Zone_Normal", "Zone_Hyper",       # Clinical zones
        "Volatility", "ROC_sign",                       # Stability
        "TIR", "Below", "Above",                        # Time in range
        "G_normalized"                                   # Scaled glucose
    ]
    
    # ===== NIGHT SIMULATION FEATURES (72) =====
    night_names = []
    
    # Mean of each base feature (32 features)
    for name in ts_base:
        night_names.append(f"{name}_mean")
    
    # Standard deviation of each base feature (32 features)
    for name in ts_base:
        night_names.append(f"{name}_std")
    
    # Additional night-specific metrics (8 features)
    night_names += [
        "Night_G_min", "Night_G_max",
        "Night_Time_Hypo", "Night_Time_Hyper",
        "Night_ROC_mean", "Night_ROC_std",
        "Night_Accel_mean", "Night_Accel_std"
    ]
    
    # Total: 26 + 72 = 98 features
    return pre_names + night_names