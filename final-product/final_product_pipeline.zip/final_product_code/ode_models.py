"""
ODE Models Module
Physiological glucose-insulin dynamics models and parameter estimation.

This module provides utilities for:
- Estimating patient-specific physiological parameters from time-series data
- Simulating glucose-insulin dynamics using compartmental ODE models
- Modeling carbohydrate absorption from meals (Ra functions)
- Modeling subcutaneous insulin absorption and pharmacokinetics
- Predicting glucose trajectories given meals, insulin, and parameters

The models are based on the minimal model framework extended with:
- Four-compartment dynamics (glucose, remote insulin, plasma insulin, SC depot)
- Gamma-distributed carbohydrate absorption
- Multi-exponential subcutaneous insulin kinetics
- Patient-specific parameter estimation from real data
"""

import numpy as np
import math
from datetime import timedelta


# ================================================================
# PARAMETER ESTIMATION FROM TIME-SERIES DATA
# ================================================================

def estimate_Gb(glucose_events):
    """
    Estimate the basal glucose level (Gb) for a patient.
    
    Computes the typical baseline glucose concentration when the patient is in a
    relatively stable metabolic state. This represents the patient's typical 
    glucose level in the absence of recent meals or insulin perturbations.
    
    Strategy:
    1. Preferentially uses nighttime values (02:00-06:00) when available
    2. Nighttime periods typically have minimal meal and insulin effects
    3. Falls back to median of all values if insufficient nighttime data
    4. Constrains result to physiologically plausible range [60, 200] mg/dL
    
    Parameters:
        glucose_events (list of dict): Glucose measurements, each containing:
            - time (datetime): Timestamp of the measurement
            - value (float): Glucose concentration in mg/dL
            
    Returns:
        float: Estimated basal glucose level in mg/dL, constrained to [60, 200] range.
            Returns 100.0 mg/dL if no data is available (typical healthy baseline).
    """
    # Handle empty data
    if not glucose_events:
        return 100.0
    
    # Extract nighttime values (2am-6am) when metabolism is most stable
    night_vals = [e["value"] for e in glucose_events if 2 <= e["time"].hour <= 6]
    
    # Use nighttime median if we have at least 3 measurements
    if len(night_vals) >= 3:
        Gb_loc = float(np.median(night_vals))
    else:
        # Fallback: use median of all available data
        Gb_loc = float(np.median([e["value"] for e in glucose_events]))
    
    # Constrain to physiologically plausible range
    # 60 mg/dL = severe hypoglycemia threshold
    # 200 mg/dL = upper bound for basal estimation
    Gb_loc = max(60.0, min(Gb_loc, 200.0))
    
    return Gb_loc


def estimate_SG(glucose_events, meals, boluses, Gb_loc):
    """
    Estimate the glucose effectiveness parameter (SG) from time-series data.
    
    SG represents the rate at which glucose returns to baseline in the absence
    of insulin action. Physiologically, this captures the effectiveness of 
    glucose in promoting its own disposal (e.g., via GLUT1 transporters).
    
    Algorithm:
    1. Searches for quasi-steady-state periods (30-120 min windows)
    2. Identifies periods where glucose is declining toward baseline
    3. Excludes windows near meals/insulin (±30 min buffer)
    4. Fits exponential decay: G(t) - Gb = A * exp(-SG * t)
    5. Takes median SG across multiple windows for robustness
    
    The algorithm is conservative, only using periods with:
    - At least 4 measurements
    - No recent meals or insulin (±30 min)
    - Declining glucose (negative mean derivative)
    - Glucose sufficiently above baseline (>5 mg/dL)
    
    Parameters:
        glucose_events (list of dict): Glucose measurements with 'time' and 'value' keys
        meals (list of dict): Meal events with 'time' key (used to exclude post-meal periods)
        boluses (list of dict): Bolus events with 'time' key (used to exclude post-bolus periods)
        Gb_loc (float): Basal glucose level in mg/dL, typically from estimate_Gb()
        
    Returns:
        float: Estimated glucose effectiveness (min^-1), constrained to [0.001, 0.2] range.
            Returns 0.02 min^-1 if insufficient data or no valid decay periods are found.
            Typical range: 0.01-0.05 min^-1 (half-life of 14-70 minutes).
    """
    if not glucose_events:
        return 0.02
    
    # Convert timestamps to minutes from start
    times = np.array([(e["time"] - glucose_events[0]["time"]).total_seconds() / 60.0 
                      for e in glucose_events])
    vals = np.array([e["value"] for e in glucose_events])
    start = glucose_events[0]["time"]
    
    # Collect all meal and bolus times (to exclude these periods)
    event_times_min = []
    for m in meals:
        if m.get("time"):
            event_times_min.append((m["time"] - start).total_seconds() / 60.0)
    for b in boluses:
        if b.get("time"):
            event_times_min.append((b["time"] - start).total_seconds() / 60.0)
    event_times_min = np.array(sorted(event_times_min)) if event_times_min else np.array([])

    # Collect SG estimates from multiple windows
    sg_candidates = []
    n = len(times)
    
    # Try different window sizes to capture various decay patterns
    for i in range(n):
        for window_min in [30, 45, 60, 90, 120]:
            # Find end of window
            j = i
            while j < n and times[j] - times[i] <= window_min:
                j += 1
            
            # Need at least 4 points for reliable fit
            if j - i < 4:
                continue
            
            # Extract time segment (relative to window start)
            t_segment = times[i:j] - times[i]
            g_segment = vals[i:j]
            t_abs_start = times[i]
            t_abs_end = times[j - 1]
            
            # Skip if any meal/bolus within ±30 min of this window
            if event_times_min.size > 0:
                near_events = (event_times_min >= t_abs_start - 30) & \
                             (event_times_min <= t_abs_end + 30)
                if np.any(near_events):
                    continue
            
            # Skip if glucose is rising (we want decay periods only)
            if np.mean(np.diff(g_segment)) > 0.5:
                continue
            
            # Compute difference from baseline
            diff = g_segment - Gb_loc
            
            # Only use points sufficiently above baseline (>5 mg/dL)
            mask = diff > 5.0
            if mask.sum() < 4:
                continue
            
            # Fit exponential decay: ln(G - Gb) = ln(A) - SG * t
            lnvals = np.log(diff[mask])
            t_for_fit = t_segment[mask]
            
            try:
                # Linear fit in log space: slope = -SG
                a, _ = np.polyfit(t_for_fit, lnvals, 1)
            except Exception:
                continue
            
            # Extract SG estimate (negative of slope)
            sg_est = -a
            
            # Only accept physiologically plausible values
            if 0 < sg_est < 1.0:
                sg_candidates.append(sg_est)
    
    # Return median if we found valid estimates
    if len(sg_candidates) == 0:
        return 0.02  # Default value
    
    sg_median = float(np.median(sg_candidates))
    
    # Constrain to reasonable physiological range
    # 0.001 min^-1 = very slow (half-life ~700 min)
    # 0.2 min^-1 = very fast (half-life ~3.5 min)
    sg_median = max(0.001, min(sg_median, 0.2))
    
    return sg_median


def estimate_k_abs(glucose_events, boluses):
    """
    Estimate the subcutaneous insulin absorption rate (k_abs) from bolus response data.
    
    k_abs determines how quickly injected insulin is absorbed from the subcutaneous
    depot into the bloodstream. This is estimated by measuring the time delay 
    between bolus administration and the nadir (minimum) glucose response.
    
    Algorithm:
    1. For each bolus, find the minimum glucose in the following 4 hours
    2. Calculate time from bolus to nadir (delay)
    3. Estimate k_abs = 1 / delay (inverse relationship)
    4. Take median across all boluses for robustness
    
    Rationale: Faster absorption → earlier nadir → shorter delay → higher k_abs
    
    Parameters:
        glucose_events (list of dict): Glucose measurements with 'time' and 'value' keys
        boluses (list of dict): Bolus insulin events with 'time' and optional other keys
        
    Returns:
        float: Estimated insulin absorption rate constant (min^-1), constrained to
            [0.005, 0.2] range. Returns 0.03 min^-1 if insufficient data.
            Typical range: 0.02-0.05 min^-1 (half-life of 14-35 minutes).
    """
    if not boluses:
        return 0.03  # Default value for rapid-acting insulin
    
    delays = []
    
    for b in boluses:
        if b.get("time") is None:
            continue
        
        # Look for glucose minimum within 4 hours after bolus
        window_end = b["time"] + timedelta(minutes=240)
        post = [e for e in glucose_events if b["time"] <= e["time"] <= window_end]
        
        # Need at least 3 points to find a meaningful minimum
        if len(post) < 3:
            continue
        
        # Find time of glucose nadir (minimum)
        min_idx = int(np.argmin([p["value"] for p in post]))
        t_min = post[min_idx]["time"]
        
        # Calculate delay from bolus to nadir
        delay = (t_min - b["time"]).total_seconds() / 60.0
        
        # Only accept physiologically plausible delays (5-240 minutes)
        if 5 <= delay <= 240:
            delays.append(delay)
    
    if len(delays) == 0:
        return 0.03  # Default value
    
    # Take median delay for robustness
    median_delay = float(np.median(delays))
    
    # Convert delay to absorption rate (inverse relationship)
    k_abs = 1.0 / median_delay
    
    # Constrain to reasonable physiological range
    # 0.005 min^-1 = very slow absorption (half-life ~140 min)
    # 0.2 min^-1 = very fast absorption (half-life ~3.5 min)
    k_abs = max(0.005, min(k_abs, 0.2))
    
    return k_abs


def estimate_kI(glucose_events, meals, boluses, Gb_loc):
    """
    Estimate the plasma insulin clearance rate (kI) from post-bolus glucose recovery.
    
    kI represents the rate at which active insulin is cleared from the plasma
    compartment. This is estimated by measuring how quickly glucose returns to
    baseline after reaching its nadir following a bolus dose.
    
    Algorithm:
    1. For each bolus, find the glucose nadir (minimum)
    2. Extract post-nadir recovery period (returning toward baseline)
    3. Fit exponential recovery: G(t) - Gb = A x exp(-k_return x t)
    4. Take median k_return across boluses
    5. Use k_return as estimate of kI (they're related)
    
    Rationale: Faster insulin clearance → faster glucose recovery → higher k_return
    
    Parameters:
        glucose_events (list of dict): Glucose measurements with 'time' and 'value' keys
        meals (list of dict): Meal events (currently not used but included for consistency)
        boluses (list of dict): Bolus insulin events with 'time' key
        Gb_loc (float): Basal glucose level in mg/dL
        
    Returns:
        float: Estimated insulin clearance rate (min^-1), constrained to [0.001, 0.5] range.
            Returns ln(2)/60 ≈ 0.0116 min^-1 (60-minute half-life) if insufficient data.
            Typical range: 0.01-0.02 min^-1 (half-life of 35-70 minutes).
    """
    k_returns = []
    
    for b in boluses:
        if b.get("time") is None:
            continue
        
        # Look for recovery period within 6 hours after bolus
        window_end = b["time"] + timedelta(minutes=360)
        post = [e for e in glucose_events if b["time"] <= e["time"] <= window_end]
        
        # Need at least 6 points for reliable fit
        if len(post) < 6:
            continue
        
        # Extract glucose values and times
        values = np.array([p["value"] for p in post])
        times_min = np.array([(p["time"] - post[0]["time"]).total_seconds() / 60.0 
                             for p in post])
        
        # Find nadir (minimum glucose)
        min_idx = int(np.argmin(values))
        
        # Extract post-nadir recovery period
        return_vals = values[min_idx:]
        return_times = times_min[min_idx:]
        
        # Find where glucose returns close to baseline (within 5 mg/dL)
        within_idx = np.where(return_vals <= Gb_loc + 5.0)[0]
        
        if len(within_idx) > 0:
            # Use recovery up to baseline crossing
            stop_idx = within_idx[0] + min_idx
            return_vals = np.array([p["value"] for p in post[min_idx:stop_idx + 1]])
            return_times = np.array([(p["time"] - post[min_idx]["time"]).total_seconds() / 60.0 
                                    for p in post[min_idx:stop_idx + 1]])
        else:
            # Use first 3 hours of recovery if baseline not reached
            mask = return_times <= 180
            if mask.sum() < 4:
                continue
            return_vals = return_vals[mask]
            return_times = return_times[mask]
        
        # Compute difference from baseline
        diff = return_vals - Gb_loc
        
        # Only use points sufficiently above baseline (>5 mg/dL)
        mask2 = diff > 5.0
        if mask2.sum() < 4:
            continue
        
        # Fit exponential recovery: ln(G - Gb) = ln(A) - k_return x t
        lnvals = np.log(diff[mask2])
        t_for_fit = return_times[mask2]
        
        try:
            # Linear fit in log space: slope = -k_return
            a, _ = np.polyfit(t_for_fit, lnvals, 1)
        except Exception:
            continue
        
        # Extract k_return estimate (negative of slope)
        k_return = -a
        
        # Only accept physiologically plausible values
        if 0.0005 < k_return < 1.0:
            k_returns.append(k_return)
    
    # Return median if we found valid estimates
    if len(k_returns) == 0:
        # Default: 60-minute half-life
        return float(np.log(2.0) / 60.0)
    
    k_med = float(np.median(k_returns))
    
    # Constrain to reasonable physiological range
    # 0.001 min^-1 = very slow clearance (half-life ~700 min)
    # 0.5 min^-1 = very fast clearance (half-life ~1.4 min)
    k_med = max(0.001, min(k_med, 0.5))
    
    return k_med


def estimate_parameters_from_data(glucose_events, meals, boluses):
    """
    Estimate all physiological model parameters from time-series data.
    
    Combines individual parameter estimation functions to produce a complete set of
    patient-specific parameters for the glucose-insulin dynamics model. This function
    orchestrates the full parameter estimation pipeline.
    
    Estimated parameters (patient-specific):
        - Gb: Basal glucose level (mg/dL)
        - SG: Glucose effectiveness (min^-1)
        - k_abs: Subcutaneous insulin absorption rate (min^-1)
        - kI: Plasma insulin clearance rate (min^-1)
    
    Fixed parameters (population defaults):
        - kX: Insulin action rate constant (0.01 min^-1)
        - p2: Remote insulin disappearance rate (0.03 min^-1)
        - p3: Insulin action transfer rate (0.0005)
        - Ib: Basal insulin concentration (10.0 mU/L)
    
    If insufficient data is available, returns default parameter values that
    represent typical population-average physiology.
    
    Parameters:
        glucose_events (list of dict): Glucose measurements with 'time' and 'value' keys
        meals (list of dict): Meal events with 'time' key
        boluses (list of dict): Bolus insulin events with 'time' key
        
    Returns:
        dict: Dictionary of physiological parameters containing:
            - Gb (float): Basal glucose level (mg/dL)
            - SG (float): Glucose effectiveness (min^-1)
            - k_abs (float): Subcutaneous insulin absorption rate (min^-1)
            - kI (float): Plasma insulin clearance rate (min^-1)
            - kX (float): Insulin action rate constant (min^-1) [fixed at 0.01]
            - p2 (float): Remote insulin disappearance rate (min^-1) [fixed at 0.03]
            - p3 (float): Insulin action transfer rate [fixed at 0.0005]
            - Ib (float): Basal insulin concentration (mU/L) [fixed at 10.0]
    """
    # Handle case with no data: return population defaults
    if not glucose_events:
        return {
            "Gb": 100.0,        # Typical healthy baseline
            "SG": 0.02,         # Moderate glucose effectiveness
            "k_abs": 0.03,      # Typical rapid-acting insulin absorption
            "kI": float(np.log(2.0) / 60.0),  # 60-minute insulin half-life
            "kX": 0.01,         # Standard insulin action rate
            "p2": 0.03,         # Standard remote insulin disappearance
            "p3": 0.0005,       # Standard insulin action transfer
            "Ib": 10.0          # Typical basal insulin concentration
        }
    
    # Estimate patient-specific parameters
    Gb_loc = estimate_Gb(glucose_events)
    SG = estimate_SG(glucose_events, meals, boluses, Gb_loc)
    k_abs = estimate_k_abs(glucose_events, boluses)
    kI = estimate_kI(glucose_events, meals, boluses, Gb_loc)
    
    # Combine into parameter dictionary
    params = {
        "Gb": Gb_loc,
        "SG": SG,
        "k_abs": k_abs,
        "kI": kI,
        "kX": 0.01,      # Fixed: insulin action rate
        "p2": 0.03,      # Fixed: remote insulin disappearance
        "p3": 0.0005,    # Fixed: insulin action transfer
        "Ib": 10.0       # Fixed: basal insulin concentration
    }
    
    return params


# ================================================================
# ODE MODEL - GLUCOSE-INSULIN DYNAMICS
# ================================================================

def diabetes_model_extended(t_min, y, Ra_t, u_t_sc, params):
    """
    Extended glucose-insulin dynamics model (ODE system).
    
    Implements a four-compartment model of glucose-insulin dynamics:
    
    1. Glucose (G): Plasma glucose concentration (mg/dL)
       - Increases from meal absorption (Ra)
       - Decreases from glucose effectiveness (SG) and insulin action (kX * X * G)
    
    2. Remote insulin (X): Delayed insulin action compartment (dimensionless)
       - Represents insulin in interstitial space acting on glucose disposal
       - Increases when plasma insulin exceeds baseline
       - Provides delay between insulin appearance and glucose lowering
    
    3. Plasma insulin (I): Active insulin concentration (mU/L)
       - Increases from subcutaneous absorption (k_abs * Isc)
       - Decreases from clearance (kI)
    
    4. Subcutaneous depot (Isc): Insulin awaiting absorption (units)
       - Increases from bolus doses (u_sc)
       - Decreases from absorption into plasma (k_abs)
    
    Model equations:
        dG/dt = Ra - SG(G - Gb) - kX * X * G
        dX/dt = -p2 * X + p3 * (I - Ib)
        dI/dt = -kI(I - Ib) + k_abs * Isc
        dIsc/dt = -k_abs * Isc + u_sc
    
    This is based on the minimal model framework with subcutaneous insulin kinetics.
    
    Parameters:
        t_min (float): Current time in minutes (relative to simulation start)
        y (list of float): State vector [G, X, I, Isc] containing:
            - G: Glucose concentration (mg/dL)
            - X: Remote insulin effect (dimensionless)
            - I: Plasma insulin concentration (mU/L)
            - Isc: Subcutaneous insulin depot (units)
        Ra_t (callable): Function returning glucose appearance rate at time t (mg/dL/min)
        u_t_sc (callable): Function returning subcutaneous insulin input rate at time t (units/min)
        params (dict): Model parameters (see estimate_parameters_from_data for details)
        
    Returns:
        list of float: Time derivatives [dG/dt, dX/dt, dI/dt, dIsc/dt]
    """
    # Unpack state vector
    G, X, I, Isc = y
    
    # Extract parameters (with defaults if missing)
    SG = params.get("SG", 0.025)        # Glucose effectiveness
    Gb_loc = params.get("Gb", 100.0)    # Basal glucose
    kX = params.get("kX", 0.037)        # Insulin action rate
    p2 = params.get("p2", 0.014)        # Remote insulin disappearance
    p3 = params.get("p3", 0.88)         # Insulin action transfer
    Ib_loc = params.get("Ib", 10.0)     # Basal insulin
    kI = params.get("kI", 0.14)         # Insulin clearance
    k_abs = params.get("k_abs", 0.03)   # Insulin absorption

    # Evaluate input functions at current time
    Ra = Ra_t(t_min)     # Glucose appearance from meals (mg/dL/min)
    u_sc = u_t_sc(t_min) # Insulin input to SC depot (units/min)

    # Compute derivatives
    # Glucose: increases from meals, decreases from effectiveness and insulin action
    dGdt = Ra - SG * (G - Gb_loc) - kX * X * G
    
    # Remote insulin: delayed response to plasma insulin above baseline
    dXdt = -p2 * X + p3 * (I - Ib_loc)
    
    # Subcutaneous depot: decreases from absorption, increases from boluses
    dIscdt = -k_abs * Isc + u_sc
    
    # Plasma insulin: increases from absorption, decreases from clearance
    dIdt = -kI * (I - Ib_loc) + k_abs * Isc

    return [dGdt, dXdt, dIdt, dIscdt]


def rk4_integrate_extended(y0, t_array, Ra_t, u_t_sc, params):
    """
    Integrate the extended glucose-insulin ODE system using 4th-order Runge-Kutta.
    
    Numerically solves the system of differential equations defined by
    diabetes_model_extended() over the specified time array. Uses the classical
    RK4 method which provides a good balance of accuracy and computational cost.
    
    RK4 is a 4th-order method, meaning the error per step is O(h^5) where h is
    the time step. This provides excellent accuracy for smooth ODE systems like
    glucose-insulin dynamics.
    
    The RK4 algorithm:
    1. Evaluate derivative at current point: k1
    2. Evaluate at midpoint using k1: k2
    3. Evaluate at midpoint using k2: k3
    4. Evaluate at endpoint using k3: k4
    5. Weighted average: y_next = y + (dt/6)(k1 + 2k2 + 2k3 + k4)
    
    Parameters:
        y0 (list of float): Initial state vector [G0, X0, I0, Isc0]
        t_array (list of float): Time points for integration (minutes)
        Ra_t (callable): Glucose appearance rate function (mg/dL/min at time t)
        u_t_sc (callable): Subcutaneous insulin input function (units/min at time t)
        params (dict): Model parameters dictionary
        
    Returns:
        list of lists: State trajectories, where each element is a state vector
            [G, X, I, Isc] at the corresponding time point in t_array
    """
    ys = [y0]  # Initialize with initial condition
    
    # Integrate step by step using RK4
    for i in range(1, len(t_array)):
        t0, t1 = t_array[i - 1], t_array[i]
        dt = t1 - t0
        y = ys[-1]  # Current state
        
        # RK4 stages
        # k1: derivative at current point
        k1 = diabetes_model_extended(t0, y, Ra_t, u_t_sc, params)
        
        # k2: derivative at midpoint using k1
        y2 = [y[j] + 0.5 * dt * k1[j] for j in range(4)]
        k2 = diabetes_model_extended(t0 + 0.5 * dt, y2, Ra_t, u_t_sc, params)
        
        # k3: derivative at midpoint using k2
        y3 = [y[j] + 0.5 * dt * k2[j] for j in range(4)]
        k3 = diabetes_model_extended(t0 + 0.5 * dt, y3, Ra_t, u_t_sc, params)
        
        # k4: derivative at endpoint using k3
        y4 = [y[j] + dt * k3[j] for j in range(4)]
        k4 = diabetes_model_extended(t1, y4, Ra_t, u_t_sc, params)
        
        # Weighted average for next state
        y_next = [
            y[j] + (dt / 6.0) * (k1[j] + 2 * k2[j] + 2 * k3[j] + k4[j])
            for j in range(4)
        ]
        
        ys.append(y_next)
    
    return ys


# ================================================================
# INPUT FUNCTIONS - MEAL AND INSULIN ABSORPTION
# ================================================================

def single_Ra_function(meal_time, carbs, gi, start_time):
    """
    Create a glucose appearance rate function for a single meal event.
    
    Models carbohydrate absorption from a meal using a gamma-like distribution.
    This captures the delayed and gradual rise in glucose appearance following
    ingestion, which is more realistic than instantaneous absorption.
    
    The absorption profile:
    - Delayed onset (no immediate glucose rise)
    - Gradual increase to peak
    - Gradual decline back to zero
    - Total area under curve = carbs * conversion factor
    
    The time scale is modulated by glycemic index (GI):
    - Low GI (30): slower absorption (tau = 80 min)
    - High GI (100): faster absorption (tau = 25 min)
    
    Uses a gamma distribution with shape parameter n=3, which produces
    a realistic absorption profile with moderate skew.
    
    Parameters:
        meal_time (datetime or None): Timestamp when the meal was consumed
        carbs (float or None): Carbohydrate content of the meal in grams
        gi (float or None): Glycemic index of the meal (30-100). Lower GI = slower absorption
        start_time (datetime): Reference time for the simulation (t=0)
        
    Returns:
        callable: Function Ra(t) that returns glucose appearance rate (mg/dL/min) at time t.
            Returns a function that always returns 0.0 if meal is invalid (None/zero carbs).
    """
    # Handle invalid meals
    if carbs is None or carbs == 0 or meal_time is None:
        return lambda t: 0.0

    # Convert meal time to minutes from start
    t_rel = (meal_time - start_time).total_seconds() / 60.0

    # Determine absorption time scale based on glycemic index
    gi_eff = gi if gi is not None else 55.0  # Default: medium GI
    # Linear interpolation: GI 30 → tau=80, GI 100 → tau=25
    tau = np.interp(gi_eff, [30, 100], [80, 25])

    # Gamma distribution parameters
    n = 3  # Shape parameter (3 gives realistic meal profile)
    fact = math.factorial(n - 1)  # Normalization factor
    
    # Conversion factor: grams of carbs → mg/dL glucose
    # This is a simplified population-average value
    conv_factor = 10.0

    def Ra_t(t_min):
        """
        Evaluate glucose appearance rate at time t.
        
        Gamma distribution PDF:
        f(t) = (1/(tau * (n-1)!)) * (t/tau)^(n-1) * exp(-t/tau)
        
        Parameters:
            t_min (float): Time in minutes from simulation start
            
        Returns:
            float: Glucose appearance rate in mg/dL/min
        """
        # Time since meal
        t_since = t_min - t_rel
        
        # No absorption before meal
        if t_since <= 0:
            return 0.0
        
        # Gamma distribution PDF
        pdf = (1.0 / (tau * fact)) * ((t_since / tau) ** (n - 1)) * math.exp(-t_since / tau)
        
        # Scale by carb content and conversion factor
        return carbs * conv_factor * pdf

    return Ra_t


def single_u_function_subcut(ins_time, dose, insulin_type, start_time):
    """
    Create a subcutaneous insulin input function for a single bolus event.
    
    Models the absorption of subcutaneously injected insulin using a multi-exponential
    pharmacokinetic model. This is based on the Hovorka model and captures the
    delayed and prolonged absorption from the subcutaneous depot into plasma.
    
    The three-exponential model represents:
    - Fast component (60%, ka1=0.004): Initial rapid absorption
    - Medium component (30%, ka2=0.028): Main absorption phase
    - Slow component (10%, ka3=0.010): Tail of absorption
    
    This profile is characteristic of rapid-acting insulin analogs (NovoLog, Humalog)
    with peak action at ~60-90 minutes and duration of ~4-6 hours.
    
    Parameters:
        ins_time (datetime or None): Timestamp when the bolus was administered
        dose (float or None): Insulin dose in units
        insulin_type (str): Type of insulin (currently not used but included for extensibility)
        start_time (datetime): Reference time for the simulation (t=0)
        
    Returns:
        callable: Function u(t) that returns subcutaneous insulin release rate (units/min)
            at time t. Returns a function that always returns 0.0 if bolus is invalid.
    """
    # Handle invalid bolus
    if dose is None or dose == 0 or ins_time is None:
        return lambda t: 0.0

    # Convert bolus time to minutes from start
    t_rel = (ins_time - start_time).total_seconds() / 60.0

    # Absorption rate constants (min^-1) for three-exponential model
    ka1 = 0.004  # Slow component (60%)
    ka2 = 0.028  # Medium component (30%)
    ka3 = 0.010  # Fast component (10%)

    def u_sc(t_min):
        """
        Evaluate subcutaneous insulin release rate at time t.
        
        Three-exponential pharmacokinetic model:
        u(t) = dose * (0.6 * exp(-ka1*t) + 0.3 * exp(-ka2*t) + 0.1 * exp(-ka3*t))
        
        The sum of coefficients (0.6 + 0.3 + 0.1 = 1.0) ensures that the
        total absorbed insulin equals the administered dose.
        
        Parameters:
            t_min (float): Time in minutes from simulation start
            
        Returns:
            float: Insulin release rate in units/min
        """
        # Time since bolus
        t_since = t_min - t_rel
        
        # No absorption before bolus
        if t_since < 0:
            return 0.0
        
        # Three-exponential absorption model
        val = dose * (
            0.6 * math.exp(-ka1 * t_since) +
            0.3 * math.exp(-ka2 * t_since) +
            0.1 * math.exp(-ka3 * t_since)
        )
        
        return val

    return u_sc


def combine_functions(funcs):
    """
    Combine multiple time-dependent functions into a single aggregate function.
    
    Creates a function that returns the sum of all input functions at any given time.
    This is essential for simulating multiple meals or boluses: the total glucose
    appearance rate is the sum of all individual meal absorption curves, and the
    total insulin input is the sum of all individual bolus profiles.
    
    Mathematical operation:
        f_combined(t) = f1(t) + f2(t) + ... + fn(t)
    
    Parameters:
        funcs (list of callables): List of functions, each taking time t and returning
            a scalar value
        
    Returns:
        callable: Combined function that returns sum of all input functions at time t
    """
    return lambda t: sum(f(t) for f in funcs)


# ================================================================
# TRAJECTORY PREDICTION
# ================================================================

def predict_glucose_trajectory(start_time, end_time, G0, meals, boluses, params, dt_min=1.0):
    """
    Simulate glucose trajectory over a time period given meals and insulin inputs.
    
    Integrates the glucose-insulin ODE system forward in time, incorporating the
    effects of all meal and bolus events within the specified period. This is the
    main interface function for glucose prediction.
    
    The simulation pipeline:
    1. Create glucose appearance (Ra) functions for all meals
    2. Create insulin input (u_sc) functions for all boluses
    3. Combine into single Ra and u_sc functions
    4. Set up time grid and initial conditions
    5. Integrate ODE system using RK4
    6. Extract glucose trajectory from state history
    
    Returns the complete simulated glucose trajectory at regular time intervals
    (default: 1 minute resolution).
    
    Parameters:
        start_time (datetime): Beginning of simulation period
        end_time (datetime): End of simulation period
        G0 (float): Initial glucose concentration (mg/dL)
        meals (list of dict): Meal events, each containing:
            - time (datetime): When the meal was consumed
            - carbs (float): Carbohydrate content (grams)
            - gi (float, optional): Glycemic index (default: 55.0)
            - type (str): Meal type (used for tracking)
        boluses (list of dict): Bolus events, each containing:
            - time (datetime): When the bolus was administered
            - dose (float): Insulin dose (units)
            - type (str): Insulin type (e.g., 'rapid')
        params (dict): Model parameters from estimate_parameters_from_data()
        dt_min (float, optional): Integration time step in minutes. Default: 1.0
            Smaller steps = more accurate but slower
        
    Returns:
        tuple: Two-element tuple containing:
            - times (list of datetime): Timestamp for each simulation point
            - G_traj (array): Simulated glucose concentrations (mg/dL)
    """
    # Create glucose appearance functions for all meals
    Ra_funcs = [
        single_Ra_function(m["time"], m["carbs"], m.get("gi", 55.0), start_time)
        for m in meals
    ]
    
    # Create insulin input functions for all boluses
    u_funcs = [
        single_u_function_subcut(b["time"], b["dose"], b["type"], start_time)
        for b in boluses
    ]
    
    # Combine into single functions (sum of all individual contributions)
    Ra_t = combine_functions(Ra_funcs)
    u_t_sc = combine_functions(u_funcs)

    # Set up time grid for integration
    duration_minutes = (end_time - start_time).total_seconds() / 60.0
    steps = max(1, int(duration_minutes / dt_min))
    t_array = [i * dt_min for i in range(steps + 1)]
    
    # Initial conditions: [G0, X0, I0, Isc0]
    # Start with baseline insulin, no remote insulin action, no SC depot
    y0 = [float(G0), 0.0, params.get("Ib", 10.0), 0.0]
    
    # Integrate ODE system
    ys = rk4_integrate_extended(y0, t_array, Ra_t, u_t_sc, params)
    
    # Convert time array back to datetime objects
    times = [start_time + timedelta(minutes=m) for m in t_array]
    
    # Extract glucose trajectory (first component of state vector)
    G_traj = [y[0] for y in ys]
    
    return times, np.array(G_traj)