"""
Data processing utilities for diabetes XML data
Handles loading, parsing, and segmenting nighttime data
"""

import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from config import NIGHT_START_HOUR, NIGHT_END_HOUR
import numpy as np
from feature_engineering import process_night_segment
# ================================================================
# XML PROCESSING
# ================================================================
def load_xml(file_path):
    """
    Load and parse an XML file containing diabetes data.
    
    Parameters:
        file_path (str): Path to the XML file
        
    Returns:
        xml.etree.ElementTree.Element: Root element of the parsed XML tree
    """
    tree = ET.parse(file_path)
    return tree.getroot()
    
def extract_events(root):
    """
    Extract glucose, meal, insulin, and basal rate events from XML data.
    
    Parses XML structure to retrieve timestamped events for glucose readings,
    carbohydrate intake, insulin boluses, and basal rates.
    
    Parameters:
        root (xml.etree.ElementTree.Element): Root element of the XML tree
        
    Returns:
        tuple: Four lists containing:
            - glucose_events: List of (datetime, glucose_mg/dL) tuples
            - meals: List of (datetime, carb_grams) tuples
            - bolus: List of (datetime, insulin_units) tuples
            - basal: List of (datetime, rate_U/hr) tuples
    """
    glucose_events = []
    for e in root.findall("glucose_level/event"):
        ts = datetime.strptime(e.attrib["ts"], "%d-%m-%Y %H:%M:%S")
        glucose_events.append((ts, float(e.attrib["value"])))
    glucose_events.sort()

    meals = []
    for e in root.findall("meal/event"):
        ts = datetime.strptime(e.attrib["ts"], "%d-%m-%Y %H:%M:%S")
        meals.append((ts, float(e.attrib["carbs"])))

    bolus = []
    for e in root.findall("bolus/event"):
        ts = datetime.strptime(e.attrib["ts_begin"], "%d-%m-%Y %H:%M:%S")
        bolus.append((ts, float(e.attrib["dose"])))

    basal = []
    for e in root.findall("basal/event"):
        ts = datetime.strptime(e.attrib["ts"], "%d-%m-%Y %H:%M:%S")
        basal.append((ts, float(e.attrib["value"])))
    
    return glucose_events, meals, bolus, basal

def extract_night_segments(glucose_events, meals, bolus, basal, night_start_hour=NIGHT_START_HOUR, night_end_hour=NIGHT_END_HOUR):
    """
    Extract all nighttime segments from continuous diabetes monitoring data.
    
    Groups glucose readings and related events (meals, insulin) that occur
    during nighttime hours (default 00:00-08:00) for each date in the dataset.
    
    Parameters:
        glucose_events (list): List of (datetime, glucose_value) tuples
        meals (list): List of (datetime, carb_grams) tuples
        bolus (list): List of (datetime, insulin_units) tuples
        basal (list): List of (datetime, rate_U/hr) tuples
        night_start_hour (int, optional): Start hour for night period (default: 0)
        night_end_hour (int, optional): End hour for night period (default: 8)
        
    Returns:
        list: List of dictionaries, one per night, each containing:
            - date: The date of the night segment
            - start_time: First glucose timestamp of the night
            - end_time: Last glucose timestamp of the night
            - glucose: List of (datetime, value) tuples for the night
            - meals: List of meals during the night
            - bolus: List of insulin boluses during the night
            - basal: List of basal rates active during the night
    """
    if not glucose_events:
        return []
    
    # Group events by date
    nights = {}
    
    for ts, val in glucose_events:
        date = ts.date()
        hour = ts.hour
        
        # Check if this is nighttime
        if night_start_hour <= hour < night_end_hour:
            if date not in nights:
                nights[date] = {
                    'glucose': [],
                    'meals': [],
                    'bolus': [],
                    'basal': []
                }
            nights[date]['glucose'].append((ts, val))
    
    # Add corresponding meals, bolus, basal for each night
    for date in nights.keys():
        night_start = datetime.combine(date, datetime.min.time().replace(hour=night_start_hour))
        night_end = datetime.combine(date, datetime.min.time().replace(hour=night_end_hour))
        
        for ts, carbs in meals:
            if night_start <= ts < night_end:
                nights[date]['meals'].append((ts, carbs))
        
        for ts, dose in bolus:
            if night_start <= ts < night_end:
                nights[date]['bolus'].append((ts, dose))
        
        # For basal, get the rate active during the night
        for ts, rate in basal:
            if ts <= night_start:
                nights[date]['basal'].append((ts, rate))
    
    # Convert to list and sort by date
    night_segments = []
    for date in sorted(nights.keys()):
        if len(nights[date]['glucose']) > 10:  # At least some data points
            night_segments.append({
                'date': date,
                'start_time': nights[date]['glucose'][0][0],
                'end_time': nights[date]['glucose'][-1][0],
                **nights[date]
            })
    
    return night_segments


def process_all_nights_for_visualization(xml_file, bergman_params, meal_params):
    """
    Process all nighttime segments with physiological modeling and event detection.
    
    Loads XML data, extracts all night segments, runs physiological simulations,
    and detects hypoglycemic and hyperglycemic events for each night.
    
    Parameters:
        xml_file (str): Path to XML file containing diabetes data
        bergman_params (array): Parameters for Bergman model [Sg, Si, p2, n]
        meal_params (dict): Parameters for Dalla Man meal model
        
    Returns:
        list: List of dictionaries, one per night, each containing:
            - All data from process_night_segment (glucose, predictions, etc.)
            - hypo_mask: Boolean array indicating glucose < 70 mg/dL
            - hyper_mask: Boolean array indicating glucose > 180 mg/dL
            - hypo_duration_hours: Total hours spent in hypoglycemia
            - hyper_duration_hours: Total hours spent in hyperglycemia
    """
    root = load_xml(xml_file)
    glucose_events, meals, bolus, basal = extract_events(root)
    night_segments = extract_night_segments(glucose_events, meals, bolus, basal)
    
    all_nights_data = []
    previous_night_summary = None
    
    for night in night_segments:
        night_data = process_night_segment(
            night,
            bergman_params=bergman_params,
            meal_params=meal_params,
            fit_params=False,
            previous_night_summary=previous_night_summary
        )
        
        # Detect hypo/hyper events
        hypo_mask = night_data['G_cgm'] < 70
        hyper_mask = night_data['G_cgm'] > 180
        hypo_duration = np.sum(hypo_mask) * 5 / 60  # hours
        hyper_duration = np.sum(hyper_mask) * 5 / 60  # hours
        
        night_data['hypo_mask'] = hypo_mask
        night_data['hyper_mask'] = hyper_mask
        night_data['hypo_duration_hours'] = hypo_duration
        night_data['hyper_duration_hours'] = hyper_duration
        
        all_nights_data.append(night_data)
        previous_night_summary = night_data['night_summary']
    
    return all_nights_data