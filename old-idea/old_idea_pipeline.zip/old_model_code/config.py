"""
Configuration file for glucose modeling
Contains all physiological parameters and model defaults
"""

# ================================================================
# PHYSIOLOGICAL PARAMETERS
# ================================================================
BODY_WEIGHT = 99.0  # kg

# ----- Dalla Man Meal Model (defaults, will be fitted per patient) -----
k_gri_default = 0.055
k_empt_min_default = 0.008
k_empt_max_default = 0.055
k_abs_default = 0.057
f_default = 0.9

# ----- Dalla Man Meal Model (defaults, not fitted) -----
b = 0.61
c = 0.26
alpha = 0.81
beta = 0.67

# Conversion factors
G2MMOL = 1000.0 / 180.0
MMOL2MGDL = 18.0

# ----- Bergman Minimal Model Parameters (defaults, will be fitted) -----
Sg_default = 0.01
Si_default = 0.0001
p2_default = 0.025
n_default = 0.2
Vg = 1.5

# Basal values
Gb = 100.0  # mg/dL
Ib = 10.0   # mU/L

# Feature engineering constants
IOB_TAU = 180.0  # Insulin on board decay time constant (minutes)
COB_TAU = 180.0  # Carbs on board decay time constant (minutes)
RECENT_INSULIN_WINDOW = 30.0  # Recent insulin window (minutes)

# Glucose thresholds
HYPO_THRESHOLD = 70    # mg/dL
HYPER_THRESHOLD = 180  # mg/dL
TARGET_RANGE = (70, 180)  # mg/dL

# Night time definition
NIGHT_START_HOUR = 0   # 00:00
NIGHT_END_HOUR = 8     # 08:00