"""
Machine learning model training and testing
Handles XGBoost ensemble training and evaluation
"""

import numpy as np
import xgboost as xgb
from sklearn.metrics import mean_squared_error, mean_absolute_error
from pathlib import Path

from data_processing import load_xml, extract_events, extract_night_segments
from config import *
from visualization import analyze_feature_importance
from feature_engineering import process_night_segment

# ================================================================
# PATIENT-SPECIFIC SIMULATION
# ================================================================
def train_patient_specific_models(training_file, nr_features=25):
    """
    Train patient-specific hybrid models using parameter averaging and ensemble learning.
    
    Implements a multi-stage training pipeline: (1) fits physiological parameters on multiple
    nights and averages them for robustness, (2) processes all nights with averaged parameters,
    (3) trains ensemble XGBoost models with automatic feature selection, and (4) analyzes
    feature importance. Uses previous night context to improve predictions.
    
    Parameters:
        training_file (str): Path to XML file containing patient's training data with
            glucose readings, meals, insulin doses, and basal rates
            
    Returns:
        dict or None: Dictionary containing trained models and parameters, or None if error.
            When successful, returns:
            - residual_models (list): Trained XGBoost models for residual prediction
            - direct_models (list): Trained XGBoost models for direct glucose prediction
            - bergman_params (array): Averaged Bergman model parameters [Sg, Si, p2, n]
            - meal_params (dict): Averaged Dalla Man meal absorption parameters
            - night_segments (list): All night segments from training data
            - top_features (array): Indices of selected features for predictions
            - feature_names (list): Names of all features
    """
        
 
    print(f"\nProcessing training file: {Path(training_file).name}")
    
    root = load_xml(training_file)
    glucose_events, meals, bolus, basal = extract_events(root)
    
    if not glucose_events:
        print("  ERROR: No glucose data found!")
        return None
    
    # Extract all night segments
    night_segments = extract_night_segments(glucose_events, meals, bolus, basal)
    
    if not night_segments:
        print("  ERROR: No nighttime data (00:00-08:00) found!")
        return None
    
    print(f"  Found {len(night_segments)} night segments")
    
    # Fit parameters on 10 nights, then average
    print(f"\n  Fitting parameters on 10 nights...")
    all_bergman_params = []
    all_meal_params = []
    
    for i, night in enumerate(night_segments[:min(10, len(night_segments))]):
        print(f"    Fitting night {i+1}...")
        night_data = process_night_segment(night, fit_params=True)
        all_bergman_params.append(night_data['params'])
        all_meal_params.append(night_data['meal_params'])
    
    # Average the parameters
    avg_bergman_params = np.mean(all_bergman_params, axis=0)
    avg_meal_params = {
        'k_gri': np.mean([p['k_gri'] for p in all_meal_params]),
        'k_abs': np.mean([p['k_abs'] for p in all_meal_params]),
        'k_empt_min': np.mean([p['k_empt_min'] for p in all_meal_params]),
        'k_empt_max': np.mean([p['k_empt_max'] for p in all_meal_params]),
        'f': np.mean([p['f'] for p in all_meal_params])
    }
    
    print(f"\n  Averaged Parameters:")
    print(f"    Bergman: Sg={avg_bergman_params[0]:.4f}, Si={avg_bergman_params[1]:.6f}, "
          f"p2={avg_bergman_params[2]:.4f}, n={avg_bergman_params[3]:.4f}")
    print(f"    Meal: k_gri={avg_meal_params['k_gri']:.4f}, k_abs={avg_meal_params['k_abs']:.4f}")
    
    # Process all nights with averaged parameters 
    print(f"\n  Processing all nights with averaged parameters...")
    all_features = []
    all_residuals = []
    all_glucose = []
    previous_night_summary = None
    
    for i, night in enumerate(night_segments):  
        night_data = process_night_segment(
            night, 
            bergman_params=avg_bergman_params,
            meal_params=avg_meal_params, 
            fit_params=False,
            previous_night_summary=previous_night_summary
        )
        
        all_features.append(night_data['features'])
        all_residuals.append(night_data['residuals'])
        all_glucose.append(night_data['G_cgm'])
        
        # Save summary for next night
        previous_night_summary = night_data['night_summary']
    
    # Combine all night data
    X_train = np.vstack(all_features)
    y_residuals = np.concatenate(all_residuals)
    y_glucose = np.concatenate(all_glucose)
    
    print(f"\n  Total training samples: {X_train.shape[0]}")
    print(f"  Number of features: {X_train.shape[1]}")
    
    # Train ensemble models with feature selection 
    print(f"\n  Training ensemble models with feature selection...")
    
    # Train with top 25 features (this number can be changed, depending on how many features you want to take in account)
    residual_models, direct_models, selected_features = retrain_with_top_features(
        X_train, y_residuals, y_glucose, top_n=nr_features
    )

    # Print which features were selected
    feature_names = [
        'Hour', 'Sin_time', 'Cos_time',
        'G_5m', 'G_15m', 'G_30m', 'G_60m', 'G_120m',
        'ROC_5m', 'ROC_30m', 'ROC_60m', 'Accel',
        'Mean_1h', 'Std_1h', 'Std_30m', 'CV', 'Range_1h',
        'IOB', 'Recent_insulin', 'COB', 'IOB_COB', 'IOB_ROC', 'Weighted_insulin',
        'Time_since_meal', 'Time_since_bolus',
        'Last_meal_size', 'Glycemic_load', 'Total_carbs_3h',
        'Dawn_phenomenon', 'Early_night', 'Sin_12h',
        'TIR_70_180', 'Time_below_70', 'Time_above_180',
        'Direction', 'Trend_consistency', 'Volatility',
        'Is_hypo', 'Is_in_range', 'Is_hyper',
        'Prev_mean_G', 'Prev_std_G', 'Prev_TIR', 'Prev_hypo_events', 'Prev_final_G'
    ]
    
    print(f"\n  Selected features:")
    for idx in selected_features:
        print(f"    - {feature_names[idx]}")
    
    # Analyze feature importance
    top_features_idx, feature_names = analyze_feature_importance(
        {'residual_models': residual_models}
    )
    
    return {
        'residual_models': residual_models,
        'direct_models': direct_models,
        'bergman_params': avg_bergman_params,
        'meal_params': avg_meal_params,
        'night_segments': night_segments,
        'top_features': selected_features,
        'feature_names': feature_names
    }

def retrain_with_top_features(X_train, y_residuals, y_glucose, top_n=25):
    """
    Retrain XGBoost ensemble using only the most important features.
    
    Performs feature selection by training a temporary model to identify importance,
    then retrains full ensemble on reduced feature set for improved efficiency and
    potentially better generalization.
    
    Parameters:
        X_train (array): Training feature matrix of shape (n_samples, n_features)
        y_residuals (array-like): Target residuals (CGM - physiological model predictions)
        y_glucose (array-like): Target glucose values (direct CGM measurements)
        top_n (int, optional): Number of top features to retain (default: 25)
        
    Returns:
        tuple: Three elements:
            - residual_models (list): List of 2 trained XGBoost models for residual prediction
            - direct_models (list): List of 2 trained XGBoost models for direct glucose prediction
            - top_idx (array): Indices of selected features in sorted order

    """
    
    print(f"\n  Identifying top {top_n} features...")
    
    # Train temporary model on all features first, to get importance
    temp_model = xgb.XGBRegressor(n_estimators=50, max_depth=5, random_state=42)
    temp_model.fit(X_train, y_residuals)
    
    # Get top N feature indices
    top_idx = np.argsort(temp_model.feature_importances_)[-top_n:]
    top_idx = np.sort(top_idx)  # Sort for consistency
    
    X_train_reduced = X_train[:, top_idx]
    
    print(f"  Retraining ensemble with {top_n} selected features...")
    print(f"  Reduced feature matrix shape: {X_train_reduced.shape}")
    
    # Train ensemble on reduced features
    xgb_residual_1 = xgb.XGBRegressor(
        n_estimators=150, max_depth=6, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=42
    )
    xgb_residual_2 = xgb.XGBRegressor(
        n_estimators=200, max_depth=5, learning_rate=0.03,
        subsample=0.9, colsample_bytree=0.9, random_state=123
    )
    
    xgb_direct_1 = xgb.XGBRegressor(
        n_estimators=200, max_depth=8, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=42
    )
    xgb_direct_2 = xgb.XGBRegressor(
        n_estimators=250, max_depth=7, learning_rate=0.03,
        subsample=0.9, colsample_bytree=0.9, random_state=123
    )
    
    # Train all models
    xgb_residual_1.fit(X_train_reduced, y_residuals)
    xgb_residual_2.fit(X_train_reduced, y_residuals)
    xgb_direct_1.fit(X_train_reduced, y_glucose)
    xgb_direct_2.fit(X_train_reduced, y_glucose)
    
    residual_models = [xgb_residual_1, xgb_residual_2]
    direct_models = [xgb_direct_1, xgb_direct_2]
    
    print(f"  Retraining complete with {top_n} features!")
    
    return residual_models, direct_models, top_idx

def test_patient_specific_model_all_nights(test_file, trained_models):
    """
    Test trained ensemble models on all nights in patient's test file with sequential context.
    
    Processes each nighttime segment sequentially, using the previous night's summary
    statistics to inform predictions for the current night. Compares three prediction
    approaches: mechanistic-only, hybrid (mechanistic + ML residual), and direct ML.
    Detects and tracks hypoglycemic and hyperglycemic events.
    
    Parameters:
        test_file (str): Path to XML file containing patient's test data
        trained_models (dict): Dictionary from train_patient_specific_models containing:
            - bergman_params: Physiological model parameters
            - meal_params: Meal absorption parameters
            - residual_models: Trained XGBoost ensemble for residuals
            - direct_models: Trained XGBoost ensemble for direct prediction
            - top_features: Indices of selected features
            
    Returns:
        dict or None: Dictionary containing test results, or None if error.
            When successful, returns:
            - all_nights (list): List of dictionaries, one per night, each containing:
                - night_idx: Sequential index of night
                - date: Date of night segment
                - night_data: Full processed night data
                - hybrid_pred: Hybrid model predictions (mg/dL)
                - direct_pred: Direct ML predictions (mg/dL)
                - hypo_events: Hypoglycemia detection results
                - hyper_events: Hyperglycemia detection results
                - metrics: RMSE and MAE for all three approaches
            - aggregate_metrics (dict): Overall performance metrics:
                - avg_rmse_mech/hybrid/direct: Average RMSE across nights
                - avg_mae_mech/hybrid/direct: Average MAE across nights
                - total_hypo_hours: Total time in hypoglycemia
                - total_hyper_hours: Total time in hyperglycemia
    """
    print(f"\nTesting on file: {Path(test_file).name}")
    
    if trained_models is None:
        print("ERROR: No trained models available!")
        return None
    
    root = load_xml(test_file)
    glucose_events, meals, bolus, basal = extract_events(root)
    
    if not glucose_events:
        print("ERROR: No glucose data found in test file!")
        return None
    
    # Extract all night segments
    night_segments = extract_night_segments(glucose_events, meals, bolus, basal)
    
    if not night_segments:
        print("ERROR: No nighttime data (00:00-08:00) found in test file!")
        return None
    
    print(f"Found {len(night_segments)} night segments, starting to test on these nights.")
    
    # Process all nights
    all_night_results = []
    previous_night_summary = None
    
    for night_idx, night in enumerate(night_segments):
        print(f"\n  Processing night {night_idx + 1}/{len(night_segments)}: {night['date']}")
        
        # Process this night
        night_data = process_night_segment(
            night,
            bergman_params=trained_models['bergman_params'],
            meal_params=trained_models['meal_params'],
            fit_params=False,
            previous_night_summary=previous_night_summary
        )
        
        # Extract only selected features for prediction
        features_full = night_data['features']
        features_selected = features_full[:, trained_models['top_features']]
        
        # Make ensemble predictions with selected features
        residual_preds = [model.predict(features_selected) 
                         for model in trained_models['residual_models']]
        direct_preds = [model.predict(features_selected) 
                       for model in trained_models['direct_models']]
        
        # Average ensemble predictions
        residual_pred = np.mean(residual_preds, axis=0)
        direct_pred = np.mean(direct_preds, axis=0)
        hybrid_pred = night_data['G_pred'] + residual_pred
        
        # Calculate metrics
        rmse_mech = np.sqrt(mean_squared_error(night_data['G_cgm'], night_data['G_pred']))
        rmse_hybrid = np.sqrt(mean_squared_error(night_data['G_cgm'], hybrid_pred))
        rmse_direct = np.sqrt(mean_squared_error(night_data['G_cgm'], direct_pred))
        
        mae_mech = mean_absolute_error(night_data['G_cgm'], night_data['G_pred'])
        mae_hybrid = mean_absolute_error(night_data['G_cgm'], hybrid_pred)
        mae_direct = mean_absolute_error(night_data['G_cgm'], direct_pred)
        
        print(f"    Mechanistic - RMSE: {rmse_mech:.2f} mg/dL, MAE: {mae_mech:.2f} mg/dL")
        print(f"    Hybrid      - RMSE: {rmse_hybrid:.2f} mg/dL, MAE: {mae_hybrid:.2f} mg/dL")
        print(f"    Direct ML   - RMSE: {rmse_direct:.2f} mg/dL, MAE: {mae_direct:.2f} mg/dL")
        
        # Detect hypo/hyper events
        hypo_mask = night_data['G_cgm'] < 70
        hyper_mask = night_data['G_cgm'] > 180
        hypo_duration = np.sum(hypo_mask) * 5 / 60  # hours
        hyper_duration = np.sum(hyper_mask) * 5 / 60  # hours
        
        # Predict hypo/hyper for ML models
        hybrid_hypo_mask = hybrid_pred < 70
        hybrid_hyper_mask = hybrid_pred > 180
        direct_hypo_mask = direct_pred < 70
        direct_hyper_mask = direct_pred > 180
        
        # Store results for this night
        night_result = {
            'night_idx': night_idx,
            'date': night['date'],
            'night_data': night_data,
            'hybrid_pred': hybrid_pred,
            'direct_pred': direct_pred,
            'hypo_events': {
                'cgm_mask': hypo_mask,
                'hybrid_mask': hybrid_hypo_mask,
                'direct_mask': direct_hypo_mask,
                'cgm_duration_hours': hypo_duration
            },
            'hyper_events': {
                'cgm_mask': hyper_mask,
                'hybrid_mask': hybrid_hyper_mask,
                'direct_mask': direct_hyper_mask,
                'cgm_duration_hours': hyper_duration
            },
            'metrics': {
                'rmse_mech': rmse_mech,
                'rmse_hybrid': rmse_hybrid,
                'rmse_direct': rmse_direct,
                'mae_mech': mae_mech,
                'mae_hybrid': mae_hybrid,
                'mae_direct': mae_direct
            }
        }
        
        all_night_results.append(night_result)
        
        # Update previous night summary for next iteration
        previous_night_summary = night_data['night_summary']
    
    # Calculate total performance
    print(f"\n  {'='*70}")
    print(f"  TOTAL PERFORMANCE ACROSS {len(all_night_results)} NIGHTS")
    print(f"  {'='*70}")
    
    avg_rmse_mech = np.mean([r['metrics']['rmse_mech'] for r in all_night_results])
    avg_rmse_hybrid = np.mean([r['metrics']['rmse_hybrid'] for r in all_night_results])
    avg_rmse_direct = np.mean([r['metrics']['rmse_direct'] for r in all_night_results])
    
    avg_mae_mech = np.mean([r['metrics']['mae_mech'] for r in all_night_results])
    avg_mae_hybrid = np.mean([r['metrics']['mae_hybrid'] for r in all_night_results])
    avg_mae_direct = np.mean([r['metrics']['mae_direct'] for r in all_night_results])
    
    print(f"  Average Mechanistic - RMSE: {avg_rmse_mech:.2f}, MAE: {avg_mae_mech:.2f}")
    print(f"  Average Hybrid      - RMSE: {avg_rmse_hybrid:.2f}, MAE: {avg_mae_hybrid:.2f}")
    print(f"  Average Direct ML   - RMSE: {avg_rmse_direct:.2f}, MAE: {avg_mae_direct:.2f}")
    
    total_hypo_hours = sum([r['hypo_events']['cgm_duration_hours'] for r in all_night_results])
    total_hyper_hours = sum([r['hyper_events']['cgm_duration_hours'] for r in all_night_results])
    
    print(f"\n  Total Hypoglycemia (<70):  {total_hypo_hours:.1f} hours")
    print(f"  Total Hyperglycemia (>180): {total_hyper_hours:.1f} hours")
    
    return {
        'all_nights': all_night_results,
        'aggregate_metrics': {
            'avg_rmse_mech': avg_rmse_mech,
            'avg_rmse_hybrid': avg_rmse_hybrid,
            'avg_rmse_direct': avg_rmse_direct,
            'avg_mae_mech': avg_mae_mech,
            'avg_mae_hybrid': avg_mae_hybrid,
            'avg_mae_direct': avg_mae_direct,
            'total_hypo_hours': total_hypo_hours,
            'total_hyper_hours': total_hyper_hours
        }
    }