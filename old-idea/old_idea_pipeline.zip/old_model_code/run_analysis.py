"""
Main execution script for predicting glucose trends
"""

import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt

from model_training import train_patient_specific_models, test_patient_specific_model_all_nights
from visualization import plot_all_nights_with_predictions

def main(data_dir='data', results_dir='results', n_features=25):
    """Main execution function for patient-specific modeling
    
    Parameters:
    -----------
    data_dir : str
        Directory containing the XML files (default: 'data')
    results_dir : str
        Directory to save result plots (default: 'results')
    """
    
    # Patient IDs
    patient_ids = ['540', '544', '552', '559', '563', '567', '570', '575', '584', '588', '591', '596']
    
    # Convert to Path objects
    data_path = Path(data_dir)
    
    # Check if data directory exists
    if not data_path.exists():
        print(f"ERROR: Data directory '{data_dir}' not found!")
        print(f"Please specify the correct directory containing XML files.")
        return
    
    print(f"Looking for XML files in: {data_path.absolute()}")
    
    results_summary = []
    
    for patient_id in patient_ids:
        print("\n" + "="*70)
        print(f"PROCESSING PATIENT {patient_id}")
        print("="*70)
        
        # Define file paths
        training_file = data_path / f"Training/{patient_id}-ws-training.xml"
        testing_file = data_path / f"Testing/{patient_id}-ws-testing.xml"
        
        # Check if files exist
        if not training_file.exists():
            print(f"  ERROR: Training file not found: {training_file}")
            continue
        
        if not testing_file.exists():
            print(f"  ERROR: Testing file not found: {testing_file}")
            continue
        
        # Train on all nights from training file, change nr_features if you want more or less features taken into account
        trained_models = train_patient_specific_models(str(training_file), nr_features=n_features)
        
        if trained_models is None:
            print(f"  Skipping patient {patient_id} due to training errors")
            continue
        
        # Save feature importance plot
        Path(results_dir).mkdir(parents=True, exist_ok=True)
        plt.savefig(f'{results_dir}/patient_{patient_id}_feature_importance.png', 
                    dpi=300, bbox_inches='tight')
        print(f"  Feature importance plot saved!")
        plt.close()
        
        # Test on all possible nights
        test_results = test_patient_specific_model_all_nights(str(testing_file), trained_models)
        
        if test_results is None:
            print(f"  Skipping patient {patient_id} due to testing errors")
            continue
        
        # Plot all nights with predictions
        plot_all_nights_with_predictions(test_results, patient_id, save_dir=results_dir)
        
        # Store summary
        results_summary.append({
            'patient_id': patient_id,
            'aggregate_metrics': test_results['aggregate_metrics'],
            'n_nights': len(test_results['all_nights'])
        })
    
    # Print summary
    print("\n" + "="*70)
    print("SUMMARY OF ALL PATIENTS")
    print("="*70)
    
    if results_summary:
        print(f"\n{'Patient':<10} {'N Nights':<10} {'Avg Hybrid RMSE':<18} {'Total Hypo (h)':<15} {'Total Hyper (h)':<15}")
        print("-" * 70)
        
        for result in results_summary:
            pid = result['patient_id']
            n = result['n_nights']
            agg = result['aggregate_metrics']
            print(f"{pid:<10} {n:<10} {agg['avg_rmse_hybrid']:<18.2f} "
                  f"{agg['total_hypo_hours']:<15.1f} {agg['total_hyper_hours']:<15.1f}")
        
        # Calculate overall average
        overall_avg_hybrid = np.mean([r['aggregate_metrics']['avg_rmse_hybrid'] for r in results_summary])
        overall_total_hypo = sum([r['aggregate_metrics']['total_hypo_hours'] for r in results_summary])
        overall_total_hyper = sum([r['aggregate_metrics']['total_hyper_hours'] for r in results_summary])
        
        print("-" * 70)
        print(f"{'OVERALL':<10} {'':<10} {overall_avg_hybrid:<18.2f} "
              f"{overall_total_hypo:<15.1f} {overall_total_hyper:<15.1f}")
    else:
        print("No results to display")


if __name__ == "__main__":
    # Change data_dir variable to the file path of your XML files, the code assumes this structure: Dataset_XML (or something similar) split into Testing and Training folders.
    DATA_DIR = r'C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\Dataset_XML'
    # Change results_dir variable to the name you want for the folder containing images of plotting and feature analysis results.
    RESULTS_DIR = r'C:\School\_BMT_3.2\2 Digital twin in HC 8BE070\25feat_results'
    # Change number of features, maximum of 45
    N_FEATURES = 25

    main(data_dir=DATA_DIR, results_dir=RESULTS_DIR, n_features=N_FEATURES)
