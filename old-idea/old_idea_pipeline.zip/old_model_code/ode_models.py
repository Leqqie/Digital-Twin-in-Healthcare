"""
Physiological models for glucose-insulin dynamics
Includes Bergman Minimal Model and Dalla Man meal absorption model
"""

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, differential_evolution
from config import *
import warnings
warnings.filterwarnings('ignore')

# ================================================================
# DALLA MAN MEAL ABSORPTION MODEL
# ================================================================
class MealSchedule:
    """
    Manages meal timing and carbohydrate intake scheduling.
    
    This class maintains a sorted list of meals and provides time-based
    carbohydrate input for physiological simulations.
    
    Attributes:
        meals (list): Sorted list of tuples (time_min, grams) representing meals
        index (int): Current position in the meal schedule
    """
    
    def __init__(self, meals_min):
        """
        Initialize meal schedule with sorted meal events.
        
        Parameters:
            meals_min (list): List of tuples (time_minutes, carb_grams) where
                            time_minutes is the meal time and carb_grams is the
                            amount of carbohydrates consumed
        """
        self.meals = sorted(meals_min, key=lambda x: x[0])
        self.index = 0

    def get_input(self, t):
        """
        Get carbohydrate input at a specific time point.
        
        Parameters:
            t (float): Current time in minutes
            
        Returns:
            float: Carbohydrate intake in grams at time t, or 0.0 if no meal
        """
        if self.index < len(self.meals):
            tm, grams = self.meals[self.index]
            if t >= tm:
                self.index += 1
                return grams
        return 0.0

def gastric_emptying_rate(Qsto, meal_params):
    """
    Calculate gastric emptying rate based on stomach glucose content.
    
    Uses a nonlinear function to model how quickly the stomach empties
    based on its current glucose load, following the Dalla Man model.
    
    Parameters:
        Qsto (float): Total glucose amount in stomach (mg)
        meal_params (dict): Dictionary containing:
            - k_empt_min (float): Minimum emptying rate constant
            - k_empt_max (float): Maximum emptying rate constant
            
    Returns:
        float: Gastric emptying rate constant (1/min)
    """
    k_empt_min, k_empt_max = meal_params['k_empt_min'], meal_params['k_empt_max']
    q = Qsto / BODY_WEIGHT
    return k_empt_min + (k_empt_max - k_empt_min) / 2 * (
        np.tanh(alpha * (q - b)) - np.tanh(beta * (q - c)) + 2
    )

def dalla_man_ode(t, x, meal_schedule, meal_params):
    """
    Ordinary differential equations for the Dalla Man meal absorption model.
    
    Models the flow of glucose through the gastrointestinal tract using
    a three-compartment system: solid stomach, liquid stomach, and gut.
    
    Parameters:
        t (float): Current time in minutes
        x (array): State vector [Qsto1, Qsto2, Qgut] where:
            - Qsto1: Glucose in solid stomach phase (mg)
            - Qsto2: Glucose in liquid stomach phase (mg)
            - Qgut: Glucose in gut compartment (mg)
        meal_schedule (MealSchedule): Object managing meal inputs
        meal_params (dict): Dictionary containing:
            - k_gri (float): Grinding rate constant (1/min)
            - k_abs (float): Intestinal absorption rate constant (1/min)
            - k_empt_min (float): Minimum emptying rate
            - k_empt_max (float): Maximum emptying rate
            
    Returns:
        list: Derivatives [dQsto1/dt, dQsto2/dt, dQgut/dt]
    """
    Qsto1, Qsto2, Qgut = x
    D = meal_schedule.get_input(t)
    Qsto = Qsto1 + Qsto2
    kempt = gastric_emptying_rate(Qsto, meal_params)
    
    k_gri = meal_params['k_gri']
    k_abs = meal_params['k_abs']

    dQsto1 = -k_gri * Qsto1 + D
    dQsto2 = k_gri * Qsto1 - kempt * Qsto2
    dQgut = kempt * Qsto2 - k_abs * Qgut
    return [dQsto1, dQsto2, dQgut]

def simulate_dalla_man(meals_min, t_span, t_eval, meal_params):
    """
    Simulate glucose absorption from meals using the Dalla Man model.
    
    Integrates the three-compartment meal absorption model over time
    and converts gut glucose to rate of appearance (Ra) in blood.
    
    Parameters:
        meals_min (list): List of tuples (time_minutes, carb_grams)
        t_span (tuple): Time span for simulation (t_start, t_end) in minutes
        t_eval (array): Specific time points to evaluate (minutes)
        meal_params (dict): Meal model parameters containing:
            - k_gri, k_abs, k_empt_min, k_empt_max (rate constants)
            - f (float): Fraction of intestinal absorption (0-1)
            
    Returns:
        array: Rate of glucose appearance (Ra) in mg/dL/min at each t_eval point
    """
    meal_schedule = MealSchedule(meals_min)
    x0 = [0, 0, 0]
    sol = solve_ivp(
        lambda t, x: dalla_man_ode(t, x, meal_schedule, meal_params),
        t_span, x0, t_eval=t_eval, rtol=1e-6, atol=1e-8
    )
    Qgut = sol.y[2]
    f = meal_params['f']
    k_abs = meal_params['k_abs']
    Ra = f * k_abs * (Qgut * G2MMOL)  # mmol/min
    Ra_mgdl = Ra * MMOL2MGDL / (Vg * BODY_WEIGHT)
    return Ra_mgdl

# ================================================================
# INSULIN INPUT PROCESSING
# ================================================================
def create_insulin_profile(t_eval, basal_min, bolus_min):
    """
    Create insulin concentration profile from basal and bolus inputs.
    
    Combines continuous basal insulin delivery with discrete bolus injections,
    modeling fast absorption kinetics for bolus insulin.
    
    Parameters:
        t_eval (array): Time points in minutes to evaluate
        basal_min (list): List of tuples (time_minutes, rate_U/hr) for basal rates
        bolus_min (list): List of tuples (time_minutes, dose_units) for bolus doses
        
    Returns:
        array: Insulin concentration profile in mU/L at each time point
    """
    I_input = np.zeros_like(t_eval)
    
    # Basal insulin (continuous)
    for i, t in enumerate(t_eval):
        current_basal = 0.0
        for tm, rate in basal_min:
            if t >= tm:
                current_basal = rate
        I_input[i] = (current_basal * 1000 / 60) / 10.0
    
    # Bolus insulin (fast absorption over ~30 min)
    for tm, dose in bolus_min:
        idx = np.argmin(np.abs(t_eval - tm))
        for i in range(len(t_eval)):
            if t_eval[i] >= tm:
                dt = t_eval[i] - tm
                if dt <= 60:
                    ka = 0.05
                    I_input[i] += (dose * 1000 * ka * np.exp(-ka * dt)) / 10.0
    
    return I_input

# ================================================================
# BERGMAN MINIMAL MODEL
# ================================================================
def bergman_ode(t, y, I_func, Ra_func, params):
    """
    Ordinary differential equations for the Bergman minimal model.
    
    Models glucose-insulin dynamics using a three-compartment system:
    glucose, remote insulin, and plasma insulin.
    
    Parameters:
        t (float): Current time in minutes
        y (array): State vector [G, X, I] where:
            - G: Plasma glucose concentration (mg/dL)
            - X: Remote insulin effect (1/min)
            - I: Plasma insulin concentration (mU/L)
        I_func (callable): Function returning insulin input at time t
        Ra_func (callable): Function returning glucose appearance rate at time t
        params (array): Model parameters [Sg, Si, p2, n] where:
            - Sg: Glucose effectiveness (1/min)
            - Si: Insulin sensitivity (1/min per mU/L)
            - p2: Rate of insulin action decay (1/min)
            - n: Rate of insulin clearance (1/min)
            
    Returns:
        list: Derivatives [dG/dt, dX/dt, dI/dt]
    """
    G, X, I = y
    Sg, Si, p2, n = params
    
    Ra = Ra_func(t)
    I_in = I_func(t)
    
    dG = -Sg * (G - Gb) - X * G + Ra
    dX = -p2 * X + Si * (I - Ib)
    dI = -n * (I - Ib) + I_in
    
    return [dG, dX, dI]

def simulate_bergman(Ra, I_input, t_eval, G0, params):
    """
    Simulate glucose dynamics using the Bergman minimal model.
    
    Integrates the Bergman model equations given glucose appearance rate (Ra)
    and insulin input profiles over time.
    
    Parameters:
        Ra (array): Rate of glucose appearance (mg/dL/min) at each time point
        I_input (array): Insulin concentration (mU/L) at each time point
        t_eval (array): Time points in minutes for evaluation
        G0 (float): Initial glucose concentration (mg/dL)
        params (array): Bergman model parameters [Sg, Si, p2, n]
        
    Returns:
        array: Predicted glucose concentrations (mg/dL) at each time point
    """
    y0 = [G0, 0.0, Ib]
    
    Ra_func = lambda t: np.interp(t, t_eval, Ra)
    I_func = lambda t: np.interp(t, t_eval, I_input)
    
    sol = solve_ivp(
        lambda t, y: bergman_ode(t, y, I_func, Ra_func, params),
        (t_eval[0], t_eval[-1]),
        y0,
        t_eval=t_eval,
        rtol=1e-6,
        atol=1e-8
    )
    
    return sol.y[0]

# ================================================================
# PARAMETER FITTING
# ================================================================
def fit_meal_parameters(meals_min, t_eval, G_cgm, I_input, G0, bergman_params):
    """
    Fit meal absorption model parameters to observed glucose data.
    
    Optimizes Dalla Man meal model parameters by minimizing RMSE between
    predicted and observed glucose concentrations.
    
    Parameters:
        meals_min (list): List of (time_minutes, carb_grams) tuples
        t_eval (array): Time points in minutes for evaluation
        G_cgm (array): Observed glucose concentrations (mg/dL)
        I_input (array): Insulin input profile (mU/L)
        G0 (float): Initial glucose concentration (mg/dL)
        bergman_params (array): Fixed Bergman model parameters [Sg, Si, p2, n]
        
    Returns:
        dict: Optimized meal parameters containing:
            - k_gri: Grinding rate constant (1/min)
            - k_abs: Absorption rate constant (1/min)
            - k_empt_min: Minimum emptying rate (1/min)
            - k_empt_max: Maximum emptying rate (1/min)
            - f: Fraction of intestinal absorption (0.5-1.0)
    """
    
    def objective(meal_params_array):
        meal_params = {
            'k_gri': abs(meal_params_array[0]),
            'k_abs': abs(meal_params_array[1]),
            'k_empt_min': abs(meal_params_array[2]),
            'k_empt_max': abs(meal_params_array[3]),
            'f': min(max(abs(meal_params_array[4]), 0.5), 1.0)
        }
        
        try:
            T = t_eval[-1]
            Ra = simulate_dalla_man(meals_min, (0, T), t_eval, meal_params)
            G_pred = simulate_bergman(Ra, I_input, t_eval, G0, bergman_params)
            rmse = np.sqrt(np.mean((G_pred - G_cgm)**2))
            return rmse
        except:
            return 1e10
    
    x0 = [k_gri_default, k_abs_default, k_empt_min_default, k_empt_max_default, f_default]
    bounds = [
        (0.02, 0.1),
        (0.02, 0.15),
        (0.001, 0.02),
        (0.02, 0.1),
        (0.5, 1.0)
    ]
    
    result = minimize(objective, x0, method='L-BFGS-B', bounds=bounds, options={'maxiter': 30})
    
    fitted_meal_params = {
        'k_gri': abs(result.x[0]),
        'k_abs': abs(result.x[1]),
        'k_empt_min': abs(result.x[2]),
        'k_empt_max': abs(result.x[3]),
        'f': min(max(abs(result.x[4]), 0.5), 1.0)
    }
    
    return fitted_meal_params

def fit_bergman_parameters(Ra, I_input, t_eval, G0, G_cgm):
    """
    Fit Bergman minimal model parameters to CGM glucose data.
    
    Uses differential evolution optimization to find parameters that minimize
    the RMSE between model predictions and observed glucose values.
    
    Parameters:
        Ra (array): Rate of glucose appearance (mg/dL/min)
        I_input (array): Insulin input profile (mU/L)
        t_eval (array): Time points in minutes
        G0 (float): Initial glucose concentration (mg/dL)
        G_cgm (array): Observed CGM glucose concentrations (mg/dL)
        
    Returns:
        array: Optimized Bergman parameters [Sg, Si, p2, n] where:
            - Sg: Glucose effectiveness (1/min)
            - Si: Insulin sensitivity (1/min per mU/L)
            - p2: Rate of insulin action decay (1/min)
            - n: Rate of insulin clearance (1/min)
    """
    
    def objective(params):
        params = np.abs(params)
        try:
            G_pred = simulate_bergman(Ra, I_input, t_eval, G0, params)
            rmse = np.sqrt(np.mean((G_pred - G_cgm)**2))
            return rmse
        except:
            return 1e10
    
    bounds = [(0.001, 0.05), (0.00001, 0.001), (0.01, 0.1), (0.05, 0.5)]
    
    result = differential_evolution(
        objective,
        bounds,
        maxiter=100,
        seed=42,
        workers=1,
        atol=0.01,
        tol=0.01
    )
    
    fitted_params = np.abs(result.x)
    return fitted_params