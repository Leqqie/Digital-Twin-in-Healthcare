"""
Visualization utilities for glucose predictions and model analysis
Creates plots for feature importance and prediction results
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from config import HYPO_THRESHOLD, HYPER_THRESHOLD

def analyze_feature_importance(trained_models, feature_names=None):
    """
    Analyze and visualize feature importance across ensemble of XGBoost models.
    
    Computes average feature importance from multiple models, identifies top features,
    and creates a visualization showing which features contribute most to predictions.
    
    Parameters:
        trained_models (dict): Dictionary containing:
            - 'residual_models': List of trained XGBoost models for residual prediction
        feature_names (list, optional): List of descriptive names for all 45 features.
            If None, default descriptive names are generated automatically.
            
    Returns:
        tuple: Two elements:
            - sorted_idx (array): Indices of top 25 features sorted by importance
            - feature_names (list): List of all feature names used
    """
    if feature_names is None:
        # Create descriptive feature names
        feature_names = [
            'Hour', 'Sin_time', 'Cos_time',  # 0-2
            'G_5m', 'G_15m', 'G_30m', 'G_60m', 'G_120m',  # 3-7
            'ROC_5m', 'ROC_30m', 'ROC_60m', 'Accel',  # 8-11
            'Mean_1h', 'Std_1h', 'Std_30m', 'CV', 'Range_1h',  # 12-16
            'IOB', 'Recent_insulin', 'COB', 'IOB_COB', 'IOB_ROC', 'Weighted_insulin',  # 17-22
            'Time_since_meal', 'Time_since_bolus',  # 23-24
            'Last_meal_size', 'Glycemic_load', 'Total_carbs_3h',  # 25-27
            'Dawn_phenomenon', 'Early_night', 'Sin_12h',  # 28-30
            'TIR_70_180', 'Time_below_70', 'Time_above_180',  # 31-33
            'Direction', 'Trend_consistency', 'Volatility',  # 34-36
            'Is_hypo', 'Is_in_range', 'Is_hyper',  # 37-39
            'Prev_mean_G', 'Prev_std_G', 'Prev_TIR', 'Prev_hypo_events', 'Prev_final_G'  # 40-44
        ]
    
    # Average importance across residual models
    importances = []
    for model in trained_models['residual_models']:
        importances.append(model.feature_importances_)
    
    avg_importance = np.mean(importances, axis=0)
    
    # Sort by importance
    sorted_idx = np.argsort(avg_importance)[::-1]
    
    # Print top 25 features
    print("\n" + "="*70)
    print("TOP 25 MOST IMPORTANT FEATURES")
    print("="*70)
    print(f"{'Rank':<6} {'Feature':<25} {'Importance':<12} {'Cumulative':<12}")
    print("-"*70)
    
    cumulative = 0
    for rank, idx in enumerate(sorted_idx[:25], 1):
        cumulative += avg_importance[idx]
        print(f"{rank:<6} {feature_names[idx]:<25} {avg_importance[idx]:<12.4f} {cumulative:<12.2%}")
    
    print(f"\nTop 25 features explain {cumulative:.1%} of total importance")
    
    # Visualize
    plt.figure(figsize=(12, 8))
    top_n = 25
    y_pos = np.arange(top_n)
    
    plt.barh(y_pos, avg_importance[sorted_idx[:top_n]], color='steelblue')
    plt.yticks(y_pos, [feature_names[i] for i in sorted_idx[:top_n]])
    plt.xlabel('Feature Importance', fontsize=12)
    plt.title('Top 25 Most Important Features', fontsize=14, fontweight='bold')
    plt.gca().invert_yaxis()
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    
    return sorted_idx[:top_n], feature_names

def plot_all_nights_with_predictions(test_results, patient_id, save_dir='results'):
    """
    Create comprehensive visualization of all nights with predictions and event detection.
    
    Generates a multi-panel figure showing glucose predictions and actual CGM readings
    for all nighttime segments. Visualizes hypoglycemic and hyperglycemic events with
    color-coded shading and displays performance metrics for each night. Includes
    aggregate statistics in the figure title.
    
    Parameters:
        test_results (dict): Dictionary from test_patient_specific_model_all_nights containing:
            - all_nights: List of night results with predictions and events
            - aggregate_metrics: Overall performance statistics
        patient_id (str or int): Patient identifier for labeling and filename
        save_dir (str, optional): Directory to save output plot (default: 'results')
    """
    if not test_results or 'all_nights' not in test_results:
        print("ERROR: No test results to plot")
        return
    
    all_nights = test_results['all_nights']
    Path(save_dir).mkdir(parents=True, exist_ok=True)
    
    n_nights = len(all_nights)
    n_cols = 3
    n_rows = int(np.ceil(n_nights / n_cols))
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 4 * n_rows))
    axes = axes.flatten() if n_nights > 1 else [axes]
    
    for idx, night_result in enumerate(all_nights):
        ax = axes[idx]
        night_data = night_result['night_data']
        time_hours = night_data['t_eval'] / 60.0
        
        # Plot CGM data
        ax.plot(time_hours, night_data['G_cgm'], 'ko-', 
                label='CGM Data', linewidth=2, markersize=3, zorder=5)
        
        # Plot mechanistic baseline
        ax.plot(time_hours, night_data['G_pred'], 'b--', 
                label='Mechanistic', linewidth=1.5, alpha=0.6, zorder=3)
        
        # Plot ML predictions
        ax.plot(time_hours, night_result['hybrid_pred'], 'r-', 
                label='Hybrid Prediction', linewidth=2, alpha=0.8, zorder=4)
        ax.plot(time_hours, night_result['direct_pred'], 'g-', 
                label='Direct ML', linewidth=2, alpha=0.7, zorder=4)
        
        # Shade hypo (red) and hyper (yellow) zones for CGM
        ax.fill_between(time_hours, 0, 70, 
                       where=night_result['hypo_events']['cgm_mask'],
                       color='red', alpha=0.3, label='Hypo (<70)', zorder=1)
        ax.fill_between(time_hours, 180, 400, 
                       where=night_result['hyper_events']['cgm_mask'],
                       color='yellow', alpha=0.3, label='Hyper (>180)', zorder=1)
        
        # Shade predicted hypo/hyper (lighter shading)
        ax.fill_between(time_hours, 0, 70, 
                       where=night_result['hypo_events']['hybrid_mask'],
                       color='orange', alpha=0.15, label='Pred Hypo', zorder=2)
        ax.fill_between(time_hours, 180, 400, 
                       where=night_result['hyper_events']['hybrid_mask'],
                       color='lightgreen', alpha=0.15, label='Pred Hyper', zorder=2)
        
        # Reference lines
        ax.axhline(y=HYPO_THRESHOLD, color='purple', linestyle='--', alpha=0.5, linewidth=1)
        ax.axhline(y=HYPER_THRESHOLD, color='blue', linestyle='--', alpha=0.5, linewidth=1)
        ax.fill_between(time_hours, HYPO_THRESHOLD, HYPER_THRESHOLD, alpha=0.05, color='green', zorder=0)
        
        # Title with date, metrics, and durations
        title = f"{night_result['date']} (Night {idx+1})\n"
        title += f"RMSE: Mech={night_result['metrics']['rmse_mech']:.1f}, "
        title += f"Hybrid={night_result['metrics']['rmse_hybrid']:.1f}\n"
        title += f"Hypo: {night_result['hypo_events']['cgm_duration_hours']:.1f}h | "
        title += f"Hyper: {night_result['hyper_events']['cgm_duration_hours']:.1f}h"
        ax.set_title(title, fontsize=9, fontweight='bold')
        
        ax.set_xlabel('Time (hours)', fontsize=9)
        ax.set_ylabel('Glucose (mg/dL)', fontsize=9)
        ax.set_ylim([0, max(300, night_data['G_cgm'].max() + 20)])
        ax.grid(True, alpha=0.3)
        
        if idx == 0:  # Only show legend on first plot
            ax.legend(loc='best', fontsize=7, ncol=2)
    
    # Hide empty subplots
    for idx in range(n_nights, len(axes)):
        axes[idx].axis('off')
    
    # Add aggregate metrics to title
    agg = test_results['aggregate_metrics']
    suptitle = f"Patient {patient_id} - All {n_nights} Night Segments with Predictions\n"
    suptitle += f"Avg RMSE: Mech={agg['avg_rmse_mech']:.1f}, Hybrid={agg['avg_rmse_hybrid']:.1f}, Direct={agg['avg_rmse_direct']:.1f} | "
    suptitle += f"Total Hypo: {agg['total_hypo_hours']:.1f}h, Hyper: {agg['total_hyper_hours']:.1f}h"
    
    plt.suptitle(suptitle, fontsize=14, fontweight='bold', y=0.995)
    plt.tight_layout(rect=[0, 0, 1, 0.985])
    
    output_file = Path(save_dir) / f'patient_{patient_id}_all_nights_predictions.png'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"\n  Plot saved to: {output_file}")
    
    plt.show()
    plt.close()