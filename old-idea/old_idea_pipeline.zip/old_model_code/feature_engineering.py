"""
Feature engineering for machine learning models
Calculates IOB, COB, glucose statistics, and derived features
"""

import numpy as np
from datetime import timedelta
from config import *
from ode_models import simulate_bergman, simulate_dalla_man, fit_bergman_parameters, fit_meal_parameters, create_insulin_profile

# ================================================================
# FEATURE ENGINEERING
# ================================================================
def calculate_insulin_on_board(t_eval, bolus_min, basal_min):
    """
    Calculate insulin on board (IOB) using exponential decay model.
    
    Estimates active insulin remaining in the body at each time point,
    accounting for both bolus injections and continuous basal delivery.
    Uses a 180-minute decay time constant.
    
    Parameters:
        t_eval (array): Time points in minutes for evaluation
        bolus_min (list): List of (time_minutes, dose_units) tuples
        basal_min (list): List of (time_minutes, rate_U/hr) tuples
        
    Returns:
        array: Insulin on board (units) at each time point
    """
    IOB = np.zeros_like(t_eval)
    tau = IOB_TAU
    
    for i, t in enumerate(t_eval):
        for tm, dose in bolus_min:
            if t >= tm:
                dt = t - tm
                IOB[i] += dose * np.exp(-dt / tau)
        
        current_basal = 0.0
        for tm, rate in basal_min:
            if t >= tm:
                current_basal = rate
        IOB[i] += current_basal * tau / 60.0
    
    return IOB

def calculate_carbs_on_board(t_eval, meals_min):
    """
    Calculate carbohydrates on board (COB) using exponential decay model.
    
    Estimates active carbohydrates still being absorbed at each time point
    following meal intake. Uses a 180-minute decay time constant.
    
    Parameters:
        t_eval (array): Time points in minutes for evaluation
        meals_min (list): List of (time_minutes, carb_grams) tuples
        
    Returns:
        array: Carbohydrates on board (grams) at each time point
    """
    COB = np.zeros_like(t_eval)
    tau = COB_TAU
    
    for i, t in enumerate(t_eval):
        for tm, carbs in meals_min:
            if t >= tm:
                dt = t - tm
                COB[i] += carbs * np.exp(-dt / tau)
    
    return COB

def calculate_recent_insulin(t_eval, bolus_min, basal_min):
    """
    Calculate total insulin delivered in the last 30 minutes.
    
    Sums all bolus doses and basal insulin delivered within a 30-minute
    rolling window prior to each time point.
    
    Parameters:
        t_eval (array): Time points in minutes for evaluation
        bolus_min (list): List of (time_minutes, dose_units) tuples
        basal_min (list): List of (time_minutes, rate_U/hr) tuples
        
    Returns:
        array: Recent insulin (units) delivered in past 30 minutes at each time point
    """
    recent_insulin = np.zeros_like(t_eval)
    window = RECENT_INSULIN_WINDOW
    
    for i, t in enumerate(t_eval):
        for tm, dose in bolus_min:
            if 0 <= (t - tm) <= window:
                recent_insulin[i] += dose
        
        current_basal = 0.0
        for tm, rate in basal_min:
            if t >= tm:
                current_basal = rate
        recent_insulin[i] += (current_basal * window) / 60.0
    
    return recent_insulin

def create_enhanced_features(t_eval, G_pred, IOB, COB, recent_insulin, t0, meals_min, bolus_min, previous_night_data=None):
    """
    Create comprehensive feature matrix for machine learning with 45 engineered features.
    
    Generates a rich set of features for XGBoost modeling including time-based features,
    glucose dynamics, insulin/carb tracking, circadian patterns, and statistical measures.
    Incorporates previous night's data for context-aware predictions.
    
    Parameters:
        t_eval (array): Time points in minutes for evaluation
        G_pred (array): Predicted glucose concentrations (mg/dL) from physiological model
        IOB (array): Insulin on board (units) at each time point
        COB (array): Carbohydrates on board (grams) at each time point
        recent_insulin (array): Recent insulin doses (units) at each time point
        t0 (datetime): Reference start time for the time series
        meals_min (list): List of (time_minutes, carb_grams) tuples
        bolus_min (list): List of (time_minutes, insulin_units) tuples
        previous_night_data (dict, optional): Summary statistics from previous night containing:
            - mean_glucose: Average glucose from previous night
            - glucose_std: Standard deviation from previous night
            - time_in_range: Fraction of time in 70-180 mg/dL
            - hypo_events: Number of hypoglycemic events
            - final_glucose: Last glucose reading from previous night
            
    Returns:
        array: Feature matrix of shape (n_timepoints, 45) containing:
            [0-2]: Time features (hour, sin/cos encoding)
            [3-7]: Glucose lags (5, 15, 30, 60, 120 minutes)
            [8-11]: Rate of change and acceleration
            [12-16]: Glucose statistics (mean, std, CV, range)
            [17-22]: Insulin features (IOB, recent, weighted)
            [23-24]: Time since last meal/bolus
            [25-27]: Meal features (size, glycemic load, total carbs)
            [28-30]: Circadian features (dawn phenomenon, night periods)
            [31-33]: Time in range metrics
            [34-36]: Trend features (direction, consistency, volatility)
            [37-39]: Glucose level categories (hypo/in-range/hyper)
            [40-44]: Previous night context features
    """
    n = len(t_eval)
    features = np.zeros((n, 45))
    
    for i in range(n):
        current_time = t0 + timedelta(minutes=float(t_eval[i]))
        
        # ===== Time features (0-2) =====
        features[i, 0] = current_time.hour + current_time.minute / 60.0
        features[i, 1] = np.sin(2 * np.pi * features[i, 0] / 24)
        features[i, 2] = np.cos(2 * np.pi * features[i, 0] / 24)
        
        # ===== Glucose lags (3-7) =====
        features[i, 3] = G_pred[max(0, i-1)]   # 5 min ago
        features[i, 4] = G_pred[max(0, i-3)]   # 15 min ago
        features[i, 5] = G_pred[max(0, i-6)]   # 30 min ago
        features[i, 6] = G_pred[max(0, i-12)]  # 60 min ago
        features[i, 7] = G_pred[max(0, i-24)] if i >= 24 else G_pred[i]  # 120 min ago
        
        # ===== Rate of change (8-11) =====
        if i > 0:
            features[i, 8] = (G_pred[i] - G_pred[i-1]) / 5.0
        else:
            features[i, 8] = 0.0
            
        if i > 5:
            features[i, 9] = (G_pred[i] - G_pred[i-6]) / 30.0
        else:
            features[i, 9] = 0.0
            
        if i > 11:
            features[i, 10] = (G_pred[i] - G_pred[i-12]) / 60.0
        else:
            features[i, 10] = 0.0
            
        # Acceleration (second derivative)
        if i > 1:
            prev_roc = (G_pred[i-1] - G_pred[i-2]) / 5.0 if i > 1 else 0.0
            features[i, 11] = (features[i, 8] - prev_roc)
        else:
            features[i, 11] = 0.0
        
        # ===== Glucose statistics (12-16) =====
        recent_1h = G_pred[max(0, i-12):i+1]
        recent_30m = G_pred[max(0, i-6):i+1]
        
        features[i, 12] = np.mean(recent_1h)  # Mean glucose 1h
        features[i, 13] = np.std(recent_1h)   # Std 1h
        features[i, 14] = np.std(recent_30m)  # Std 30min
        
        if features[i, 12] > 0:
            features[i, 15] = features[i, 13] / features[i, 12]  # Coefficient of variation
        else:
            features[i, 15] = 0.0
            
        features[i, 16] = np.max(recent_1h) - np.min(recent_1h)  # Range 1h
        
        # ===== Insulin features (17-22) =====
        features[i, 17] = IOB[i]
        features[i, 18] = recent_insulin[i]
        features[i, 19] = COB[i]
        features[i, 20] = IOB[i] * COB[i]  # Interaction
        features[i, 21] = IOB[i] * features[i, 8]  # IOB * ROC
        
        # Weighted insulin action (emphasize recent insulin)
        weighted_insulin = 0.0
        for tm, dose in bolus_min:
            if t_eval[i] >= tm:
                dt = t_eval[i] - tm
                weighted_insulin += dose * np.exp(-dt / 180.0) * (1 - dt/360.0) if dt < 360 else 0
        features[i, 22] = weighted_insulin
        
        # ===== Time since events (23-24) =====
        time_since_meal = 1000.0
        last_meal_size = 0.0
        for tm, carbs in meals_min:
            if t_eval[i] >= tm:
                dt = t_eval[i] - tm
                if dt < time_since_meal:
                    time_since_meal = dt
                    last_meal_size = carbs
        features[i, 23] = time_since_meal
        
        time_since_bolus = 1000.0
        for tm, dose in bolus_min:
            if t_eval[i] >= tm:
                time_since_bolus = min(time_since_bolus, t_eval[i] - tm)
        features[i, 24] = time_since_bolus
        
        # ===== Meal features (25-27) =====
        features[i, 25] = last_meal_size
        features[i, 26] = COB[i] * np.exp(-time_since_meal / 120.0) if time_since_meal < 1000 else 0.0  # Glycemic load
        
        # Total carbs in last 3 hours
        total_recent_carbs = sum([carbs for tm, carbs in meals_min 
                                  if 0 <= (t_eval[i] - tm) <= 180])
        features[i, 27] = total_recent_carbs
        
        # ===== Dawn phenomenon & circadian (28-30) =====
        features[i, 28] = 1.0 if 4 <= current_time.hour < 8 else 0.0  # Dawn phenomenon
        features[i, 29] = 1.0 if 22 <= current_time.hour or current_time.hour < 2 else 0.0  # Early night
        features[i, 30] = np.sin(2 * np.pi * current_time.hour / 12)  # 12-hour cycle
        
        # ===== Time in range features (31-33) =====
        tir_70_180 = np.mean((recent_1h >= 70) & (recent_1h <= 180))
        time_below_70 = np.mean(recent_1h < 70)
        time_above_180 = np.mean(recent_1h > 180)
        
        features[i, 31] = tir_70_180
        features[i, 32] = time_below_70
        features[i, 33] = time_above_180
        
        # ===== Trend features (34-36) =====
        features[i, 34] = np.sign(features[i, 8])  # Direction: -1, 0, 1
        
        # Trend strength (how consistent is the direction)
        if i >= 6:
            recent_rocs = np.array([features[j, 8] for j in range(max(0, i-5), i+1)])
            trend_consistency = np.sum(np.sign(recent_rocs) == features[i, 34]) / len(recent_rocs)
            features[i, 35] = trend_consistency
        else:
            features[i, 35] = 0.5
            
        # Volatility (changes in direction)
        if i >= 12:
            direction_changes = 0
            for j in range(i-11, i):
                if np.sign(features[j+1, 8]) != np.sign(features[j, 8]):
                    direction_changes += 1
            features[i, 36] = direction_changes / 11.0
        else:
            features[i, 36] = 0.0
        
        # ===== Glucose level categories (37-39) =====
        features[i, 37] = 1.0 if G_pred[i] < HYPO_THRESHOLD else 0.0   # Hypoglycemia
        features[i, 38] = 1.0 if HYPO_THRESHOLD <= G_pred[i] <= HYPER_THRESHOLD else 0.0  # In range
        features[i, 39] = 1.0 if G_pred[i] > HYPER_THRESHOLD else 0.0  # Hyperglycemia
        
        # ===== Previous night features (40-44) =====
        if previous_night_data is not None:
            features[i, 40] = previous_night_data.get('mean_glucose', 120.0)
            features[i, 41] = previous_night_data.get('glucose_std', 20.0)
            features[i, 42] = previous_night_data.get('time_in_range', 0.7)
            features[i, 43] = previous_night_data.get('hypo_events', 0.0)
            features[i, 44] = previous_night_data.get('final_glucose', 120.0)
        else:
            features[i, 40] = 120.0  # Default mean
            features[i, 41] = 20.0   # Default std
            features[i, 42] = 0.7    # Default TIR
            features[i, 43] = 0.0    # Default hypo events
            features[i, 44] = 120.0  # Default final glucose
    
    return features

def extract_night_summary(G_cgm):
    """
    Extract summary statistics from a night's continuous glucose monitoring data.
    
    Computes key metrics that characterize glucose control during a nighttime period,
    useful for tracking patterns and providing context to subsequent nights.
    
    Parameters:
        G_cgm (array): Array of CGM glucose values (mg/dL) for the night
        
    Returns:
        dict: Dictionary containing five summary metrics:
            - mean_glucose (float): Average glucose concentration (mg/dL)
            - glucose_std (float): Standard deviation of glucose (mg/dL)
            - time_in_range (float): Fraction of time with glucose in 70-180 mg/dL range (0-1)
            - hypo_events (int): Number of time points with glucose < 70 mg/dL
            - final_glucose (float): Last glucose reading of the night (mg/dL)
    """
    return {
        'mean_glucose': np.mean(G_cgm),
        'glucose_std': np.std(G_cgm),
        'time_in_range': np.mean((G_cgm >= 70) & (G_cgm <= 180)),
        'hypo_events': np.sum(G_cgm < 70),
        'final_glucose': G_cgm[-1]
    }

def process_night_segment(night_data, bergman_params=None, meal_params=None, 
                         fit_params=False, previous_night_summary=None):
    """
    Process a single nighttime segment with physiological modeling and feature engineering.
    
    Comprehensive pipeline that: (1) converts datetime events to relative time, (2) interpolates
    CGM data, (3) creates insulin profiles, (4) optionally fits or uses provided physiological
    parameters, (5) simulates glucose dynamics, (6) engineers features for ML, and (7) computes
    model residuals and summary statistics.
    
    Parameters:
        night_data (dict): Dictionary containing nighttime segment data:
            - start_time (datetime): Beginning of night segment
            - end_time (datetime): End of night segment
            - glucose (list): List of (datetime, glucose_mg/dL) tuples
            - meals (list): List of (datetime, carb_grams) tuples
            - bolus (list): List of (datetime, insulin_units) tuples
            - basal (list): List of (datetime, rate_U/hr) tuples
            - date (date): Date of the night segment
        bergman_params (array, optional): Fixed Bergman model parameters [Sg, Si, p2, n].
            If None and fit_params=False, uses default parameters.
        meal_params (dict, optional): Fixed Dalla Man meal parameters. If None and 
            fit_params=False, uses default parameters.
        fit_params (bool, optional): If True, fit physiological parameters to CGM data.
            If False, use provided or default parameters (default: False)
        previous_night_summary (dict, optional): Summary statistics from previous night
            for context-aware feature engineering
            
    Returns:
        dict: Comprehensive results dictionary containing:
            - t_eval (array): Time points in minutes
            - t0 (datetime): Reference start time
            - G_cgm (array): Interpolated CGM glucose values (mg/dL)
            - G_pred (array): Physiological model predictions (mg/dL)
            - features (array): Feature matrix (n_timepoints, 45)
            - residuals (array): Prediction errors (CGM - model)
            - params (array): Bergman model parameters used
            - meal_params (dict): Meal absorption parameters used
            - meals_min (list): Meals in relative minutes
            - bolus_min (list): Boluses in relative minutes
            - basal_min (list): Basal rates in relative minutes
            - I_input (array): Insulin concentration profile
            - Ra (array): Rate of glucose appearance
            - date (date): Date of segment
            - night_summary (dict): Summary statistics for this night
    """
    t0 = night_data['start_time']
    t_end = night_data['end_time']
    duration_min = (t_end - t0).total_seconds() / 60
    
    t_eval = np.arange(0, duration_min + 1, 5)
    
    # Convert to minutes from start
    meals_min = [((tm - t0).total_seconds() / 60, carbs) for tm, carbs in night_data['meals']]
    bolus_min = [((tm - t0).total_seconds() / 60, dose) for tm, dose in night_data['bolus']]
    basal_min = [((tm - t0).total_seconds() / 60, rate) for tm, rate in night_data['basal']]
    
    if not basal_min:
        basal_min = [(0, 1.0)]
    
    # Initial glucose
    G0 = night_data['glucose'][0][1]
    
    # Interpolate CGM
    t_cgm = np.array([(ts - t0).total_seconds() / 60 for ts, val in night_data['glucose']])
    G_cgm_vals = np.array([val for ts, val in night_data['glucose']])
    G_cgm = np.interp(t_eval, t_cgm, G_cgm_vals)
    
    # Create insulin profile
    I_input = create_insulin_profile(t_eval, basal_min, bolus_min)
    
    # Fit or use provided parameters
    if fit_params:
        meal_params_default = {
            'k_gri': k_gri_default,
            'k_abs': k_abs_default,
            'k_empt_min': k_empt_min_default,
            'k_empt_max': k_empt_max_default,
            'f': f_default
        }
        Ra_initial = simulate_dalla_man(meals_min, (0, duration_min), t_eval, meal_params_default)
        bergman_params = fit_bergman_parameters(Ra_initial, I_input, t_eval, G0, G_cgm)
        meal_params = fit_meal_parameters(meals_min, t_eval, G_cgm, I_input, G0, bergman_params)
        Ra = simulate_dalla_man(meals_min, (0, duration_min), t_eval, meal_params)
    else:
        if bergman_params is None:
            bergman_params = [Sg_default, Si_default, p2_default, n_default]
        if meal_params is None:
            meal_params = {
                'k_gri': k_gri_default,
                'k_abs': k_abs_default,
                'k_empt_min': k_empt_min_default,
                'k_empt_max': k_empt_max_default,
                'f': f_default
            }
        Ra = simulate_dalla_man(meals_min, (0, duration_min), t_eval, meal_params)
    
    # Simulate Bergman
    G_pred = simulate_bergman(Ra, I_input, t_eval, G0, bergman_params)
    
    # Calculate features
    IOB = calculate_insulin_on_board(t_eval, bolus_min, basal_min)
    COB = calculate_carbs_on_board(t_eval, meals_min)
    recent_insulin = calculate_recent_insulin(t_eval, bolus_min, basal_min)
    
    # Use enhanced features with previous night context
    features = create_enhanced_features(t_eval, G_pred, IOB, COB, recent_insulin, 
                                       t0, meals_min, bolus_min, previous_night_summary)
    
    # Calculate residuals
    residuals = G_cgm - G_pred
    
    # Extract night summary for next night
    night_summary = extract_night_summary(G_cgm)
    
    return {
        't_eval': t_eval,
        't0': t0,
        'G_cgm': G_cgm,
        'G_pred': G_pred,
        'features': features,
        'residuals': residuals,
        'params': bergman_params,
        'meal_params': meal_params,
        'meals_min': meals_min,
        'bolus_min': bolus_min,
        'basal_min': basal_min,
        'I_input': I_input,
        'Ra': Ra,
        'date': night_data['date'],
        'night_summary': night_summary
    }